# Real Context removal witness

**READY / STOPPED, temporary test-only candidate.** No Cargo, compilation, test, native smoke, benchmark, timing, repository/fork/cache write, dependency change or Git write was performed. “GREEN base” identifies common's complete proposed runtime-plus-consumed-wake source condition; it does not claim that either source condition has been executed successfully.

## Exact base and artifacts

Base: `/tmp/physical-smoke-ci/candidate/egui/tree/crates/egui_inspection/src/plugin.rs`.

Base SHA-256: `9242d6d1c5a0062c2a062d3c708234a17fd73887580cbd6c9ce6964d068abb6a`, 38,264 bytes. This is the exact source named `green_source_sha256` in common's `candidate/red-green-source.json`, associated with the complete `egui-pending-target.patch` SHA-256 `19754736ae971fbbc5e90556b56e912083fc3c059bbae922c4da50d8b3c28ab7`.

| Artifact | SHA-256 | Size |
| --- | --- | --- |
| `context-removal.patch` | `3ab38096964af22c58bad82b3054227b9c1626b267113bca9c3685aa7b770513` | 4,638 bytes |
| `tree/crates/egui_inspection/src/plugin.rs` | `0150f73b1a7f769d97757749bb63d8a02cff87cfcbe969bdfd0d9b4cf1098acd` | 42,438 bytes |
| `base/crates/egui_inspection/src/plugin.rs` | `9242d6d1c5a0062c2a062d3c708234a17fd73887580cbd6c9ce6964d068abb6a` | 38,264 bytes |
| `context-removal-test.rs` | `568cd09b81927b39abb05aafc60e6e2cbe29549fdd60748f8e790b351211fc33` | Standalone test fragment, not a separate test module |

The incremental patch contains one insertion hunk, +96/-0 lines, in the existing registered `plugin::tests` module. It adds exactly one registered test:

`plugin::tests::pending_child_tree_removal_uses_real_context_and_does_not_resurrect`

Deleting that single insertion restores the complete common GREEN source byte-for-byte. All runtime bytes, imports, existing helpers, tests and the complete 115-line consumed-wake witness are preserved. The latter's exact preexisting block, including its trailing separator, has SHA-256 `7164637ada82e6c83d1ae701829a5ddbf789092cce52d266e86a17ddb5f1d7a2` (4,794 bytes).

## What the witness exercises

One local closure drives actual `Context::run_ui` passes, reuses the existing `input`/`TestViewport` fixture shape, and controls whether ROOT calls `show_viewport_deferred` for the selected child. An unrelated deferred child remains declared throughout. The test reuses the existing `submit` helper through the registered plugin handle; it never edits a request phase or fabricates FullOutput.

The sequence is:

1. Actual ROOT declares selected and unrelated children; an actual selected-child pass runs.
2. Submit `GetViewportTree(selected)`. ROOT still declares the child and produces output. The channel remains empty and the selected child is woken, establishing a pending child request without substituting cached output.
3. Acknowledge the child's consumed wake without running its pass. ROOT omits the selected child's declaration and updates its raw viewport inventory accordingly. The actual returned FullOutput must exclude selected, retain unrelated, and cause exactly one typed Removed reply.
4. Clear the observed wake callbacks and run another real ROOT pass. The actual output must still exclude selected and retain unrelated, with no selected callback. This catches an output-hook command recreating state after the first removal output was already collected.
5. Submit one fresh tree request for the retired ID. It must return exactly one typed Unknown reply, without adding the child to actual output or issuing a selected wake. This is the sole optional follow-up check; no duplicate ListViewports sequence is added.

No callback-absence assertion is made during the removal pass itself: its input hook legitimately still sees the already pending request before Context discovers the omission. No `ctx.viewport_for` absence read is used, because that Interface would create missing viewport state. Complete real output inventories are the absence oracle. `.drop_without_applying_deltas()` is used for owned egui outputs, as in common's existing witness.

## Static source review and unverified behavior

The witness follows the pinned Context ordering: a paint request does not set `used`, ROOT end-pass removes unused direct children before collecting output, inspection prunes its cache and removes the request before its final scheduler call, and later actual ROOT output detects any post-output resurrection. It uses no sleeps, deadline changes, transport loop, native window simulation or new testing framework. The unrelated declaration checks that removal is target-specific.

Performed only:

- Exact frozen base/source-hash checks.
- Formatting/parsing of the new temporary fragment, then `rustfmt --check` on the complete temporary candidate, using the already installed direct Rust 1.95.0 formatter with `edition=2024, skip_children=true`.
- Exact insertion reversal, runtime-prefix byte comparison, preserved consumed-wake block comparison, one-added-`#[test]` count and in-memory patch reconstruction with exact hunk context/counts.

This is source-reviewed, not type-checked or behavior-tested. It does not prove native window destruction, renderer settlement, or the unique cause of the historical CI failure. Root owns every execution and final qualification.

## Root integration order

Root's current fork state is intentionally old runtime plus common's consumed-wake test, pending its causal red run. This patch is based on the complete GREEN source, not that red state. First finish root's intended red run, then compose common's `egui-runtime-after-red.patch` to reach the exact GREEN base hash above. Only then apply `context-removal.patch`. Do not apply the original complete egui patch on top of an already test-augmented checkout; do not overwrite later fork changes with the supplied full source copy.

One possible root-owned focused command after exact composition, **not run in this lane**:

```text
cargo nextest run --manifest-path /path/to/egui-fix/Cargo.toml --package egui_inspection --lib --features plugin --locked --test-threads=1 -E 'test(pending_child_tree_removal_uses_real_context_and_does_not_resurrect)'
```

Keep common's consumed-wake witness and the complete package/native qualification in root's serial validation. The source test is expected to preserve removal under the proposed GREEN runtime; no red/green outcome is asserted here.
