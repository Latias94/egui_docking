# Independent source review: pending selected-viewport inspection paint

Verdict: **no confirmed correctness or scope blocker in the two frozen source patches**. The pending request now maintains the selected child's existing paint obligation, while ROOT continues to make inventory/removal progress. Source review supports root-owned causal red/green checks and native qualification. One narrow qualification gap remains: the existing Removed test fabricates FullOutput and does not exercise actual Context removal. A minimal registered witness is proposed below. This review neither reproduces nor uniquely attributes the historical CI failure.

Only this report was written. No repository, Cargo checkout, fork, candidate source, dependency, lockfile or workflow was edited; no Cargo, compiler, test, benchmark, timing, CI rerun, Git write, network request or sub-agent was used.

## Exact reviewed artifacts

| Artifact | SHA-256 |
| --- | --- |
| `egui-pending-target.patch` | `19754736ae971fbbc5e90556b56e912083fc3c059bbae922c4da50d8b3c28ab7` |
| `dockspace-inspection-diagnostics.patch` | `6654b2a5fabe06e189a67215c7e7eb03e5c16ef09c3b17c713f73c0cc545eef6` |
| `README.md` | `0de6cc252685d75e3d4ecfc77ee9216ccea8e9cf32f35905fa950c7949bb5af6` |
| `receipt.json` | `fe7340ec3c3c6535e520e79002b8db766cee112289e0a0e4b9bd0cf7b2933cfe` |

Both patches were reconstructed from their saved exact bases in memory, checking hunk context and line counts. Their results match all three declared candidate files and their byte lengths/hashes. No patch was applied. The egui base is the custom pin `60c40304dab75305d2ac0f54a1cabfc354669006`; dockspace source capture is `02df1e42ba793721c7cc37332ad2b10b9ed05ab2`. Later unrelated repository changes are not candidate drift.

The reviewed production egui change is confined to `crates/egui_inspection/src/plugin.rs`. The local patch changes only `driver/inspection.rs` and `driver/scenario.rs`. The optional test-only patch is an alternative red witness, not an additional patch to apply on top of the combined egui patch.

## Pending obligation and preserved response rules

`InspectionPlugin::maybe_repaint` (`plugin.rs:161`) retains the previous ROOT request whenever any non-Settle request is pending. It additionally requests only the non-root viewport named by an existing `AwaitViewportTree` phase. The old initial child `request_repaint_of` is folded into this same scheduler. There is no new request state, response shortcut, transport retry, thread or broadcast inventory traversal.

| Concern | Source conclusion |
| --- | --- |
| ROOT inventory and removal | ROOT is still requested at `plugin.rs:168`; `cache_viewport_output` still refreshes/removes inventory from the actual output before requests are completed. The target loop does not replace ROOT scheduling. |
| Unknown target | `known_viewports` remains the cached/raw-input roster union; a truly absent ID replies Unknown and is removed at `plugin.rs:320` before `maybe_repaint`. Such a request never enters target scheduling. Known means observed inventory, not an eternal lifetime guarantee. |
| Removed target | The output cache is pruned at `plugin.rs:181`, then a pending request whose target is absent replies Removed at `:415` and is removed. The final `maybe_repaint` at `:473` therefore does not re-arm that completed request. |
| Fresh target output | A pending child cannot reply from ROOT or an earlier cached child tree: `current_viewport` must equal the requested target at `:425`, after that output refreshed its cached step/tree. The patch does not alter this condition. |
| Exactly one response | Completion takes the FnOnce reply and removes the in-flight entry. Repeated scheduling does not duplicate the request or its callback. |
| Settle | A Settle-only request neither triggers ROOT scheduling nor matches `AwaitViewportTree`. Mixed Settle and active work continues to observe the existing work until it settles or reaches its existing limit. The initial server ROOT wake is unchanged. |
| No unrelated wake | The new loop names only selected targets. `RequestPaintWhileHidden::requires_parent_repaint()` is false; only Close requires that propagation in the pinned command implementation. ROOT is an explicit preserved wake, not a sibling broadcast. The registered new test checks the unrelated child has no new callback or paint command. |

Repeated calls are scheduling obligations, not a promise that every call emits a distinct callback. Context coalesces immediate repaint requests until they are consumed. The candidate test deliberately acknowledges a consumed child repaint without producing a child pass, then requires a new callback from a later ROOT pass. This transition corresponds to a real production Seam: pinned `eframe/src/native/host_seam.rs:2609` calls `ctx.acknowledge_repaint_request(viewport_id)` before application output admission, which may return Defer without executing an egui pass. It is not solely a test-invented transition. The plugin still cannot guarantee output if the integration never admits the selected viewport.

The hidden-paint command is also meaningful beyond a plain repaint: pinned `egui-winit/src/lib.rs:2179` records `ActionRequested::PaintWhileHidden`; Glow includes `ActionRequested::wants_paint` in its visibility decision (`glow_integration.rs:803`). No focus, pointer movement, window visibility mutation or fabricated OS input is introduced. Native output admission remains in place.

## Can the command create or resurrect a removed child?

**The Context command Interface can create missing viewport state.** It must not be described as a lookup-only operation. Pinned `Context::send_viewport_cmd_to` (`context.rs:4921`) first calls `request_repaint_of(id)`; its internal path uses `viewports.entry(id).or_default()` (`:170`). It then appends through `viewport_for`, which also inserts a default entry (`:758`). Calling it with an arbitrary stale ID is not inherently lifecycle-neutral.

For the ordinary direct-child removal path reviewed here, the candidate's hook ordering prevents that mechanism from preserving/recreating the removed child:

1. The request's target wake runs during input hooks, before Context begins the actual pass (`context.rs:1307`). At this point a pending child can still be a previously known child.
2. A ROOT pass that stops calling `show_viewport_deferred(child, ...)` leaves that child's `used` flag false. Neither repaint requests nor command append sets `used=true`; the declaration does (`:4980`).
3. `ContextImpl::end_pass` removes unused direct children before constructing `viewport_output` (`:3597`, `:3614`, `:3639`). The command alone does not retain the child. Any queued command for that removed state disappears with it.
4. Only after that Context completion does `end_pass_before_finalization` invoke plugin output hooks (`:3294`). Inspection sees the real output with the child absent, drops its cached entry, returns Removed, removes the request, and then schedules remaining work.
5. Glow prunes native viewports against that output (`glow_integration.rs:1119`, `:2006`). Subsequent window construction is driven by output inventory, not solely by a wake callback.

Therefore, I found no confirmed candidate regression in which repeating this command alone keeps an ordinary ROOT child alive after its declaration is removed. This conclusion depends on the actual lifecycle ordering above, not on the initial known-ID check alone. It does not assert that arbitrary externally injected stale IDs, independently modified output inventories, or every nested-parent retirement interleaving have been proved safe by the candidate tests.

## One small missing registered witness

`removed_viewport_drops_its_cache_and_returns_typed_error` (`plugin.rs:887`) calls the plugin hooks directly. Its `run_frame` helper (`:687`) fabricates RawInput and FullOutput; the test supplies a root-only output itself. That establishes cache pruning and the Removed response branch, **not** Context's child garbage collection or absence of later resurrection. The new real-Context regression keeps its `active` child declarations constant, so it does not close this gap.

Recommended registered witness, using the new test's Context/plugin/repaint pattern, with at most a small `show_child`/active-roster parameter:

1. Run real ROOT UI declaring the deferred child, and a real child pass. Submit its tree request and run ROOT while still declaring it, so the request is already waiting for that target.
2. Acknowledge the target wake without a child pass. Run a real ROOT UI that omits the child declaration. Keep any unrelated child declared. Do not fabricate or filter the resulting FullOutput.
3. Assert the actual ROOT output excludes the removed child, the request replies exactly once with Removed, and the plugin cache excludes it. A child repaint callback during this removal pass is allowed: its input hook ran before removal was known.
4. Clear observed wakes after that response, run another real ROOT-only/remaining-child pass, and assert the removed ID stays absent from actual `viewport_output`, with no request-owned child callback. This is the important check against late output-hook recreation. A later ListViewports must omit it; a fresh request with a root-only raw inventory should reply Unknown.

This is a qualification gap, not a demonstrated runtime failure or a request for a new viewport/testing framework. Inspecting a missing viewport through `ctx.viewport_for(child, ...)` would itself insert state and must not be used as the absence oracle; actual subsequent `FullOutput.viewport_output` is sufficient. The candidate causal regression plus this one real removal test and the existing package tests are an appropriately bounded source qualification scope. Real hidden/deferred window behavior remains the native smoke's job.

## Diagnostic patch and acceptance strength

`InspectionClient::request` (`driver/inspection.rs:67`) preserves the Request debug identity in write-deadline setup errors, read-deadline setup errors, and actual response-read failures. The underlying error text remains present. Write I/O already included the Request. The existing test additionally checks `ListViewports` in the timeout error without changing its 80 ms request budget or one-second upper assertion.

`root_step_before_drag_route` (`driver/scenario.rs:2381`) retains the ROOT-source shortcut and the same `bounded_stage_deadline(overall, 3 seconds)`. It calculates that deadline before logging, identifies the ROOT checkpoint at start/failure, and logs the successful semantic step. It does not inject another input, request an extra tree, retry, substitute a cached tree, or lengthen any budget. The exact patch contains no changes to physical press/move/release, thresholds, source/target selection, pointer passthrough, geometry, native output/admission/settlement, or scenario acceptance assertions.

The diagnostics distinguish a ROOT-checkpoint response timeout from a later child query when another failure is captured. They do not retroactively identify the request that timed out in run 42285373560. The 20-second server wait and driver deadlines remain distinct unchanged limits.

## Review limits and integration gate

No execution occurred in this lane. The new test exercises a real Context callback/command path and fresh semantic output; it does not exercise X11, native hidden-window rendering, output admission, or renderer settlement. The source defect and the expected test red/green are narrower evidence than unique historical CI causation. A later green rerun is evidence for that execution, not proof of the earlier interleaving.

The README correctly calls out the actual custom Git pin: changing only a separate CI fork checkout cannot make the physical-smoke binary use this patch. Root must deliberately pin the reviewed fork commit in the actual runtime dependency/lockfile before claiming the native smoke exercises it. Existing native continuation and admission machinery should remain the executor of those lifecycle duties; no second retry mechanism is warranted by this review.

Final source disposition: **pass for the two exact patches above**, with the concrete Context-removal witness recommended before making a complete removal-safety test-coverage claim. Keep the historical CI explanation qualified and perform causal/package/native checks serially under root's ownership.
