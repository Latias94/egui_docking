# Pending selected-viewport paint obligation — candidate handoff

**READY / STOPPED. Temporary candidate only.** No repository, fork, Cargo cache, dependency manifest, lockfile, or workflow has been edited. No Cargo, compilation, test, smoke, measurement, CI rerun, or remote write was executed. Direct `rustfmt` parsed/formatted only the three temporary candidate files. Dry-run patch-context/whitespace checks succeeded against their temporary base copies. This is not a type-checked or behavior-qualified fix.

The adjacent failing/passing CI logs do not identify the last outstanding request or the precise historical interleaving. This patch repairs the reviewed pending-target scheduling defect and adds diagnostics; it is **not evidence that the historical CI cause was uniquely established or that CI is fixed**. See `../analysis.md` for the bounded diagnosis.

## Exact bases and artifacts

- egui fork base: `60c40304dab75305d2ac0f54a1cabfc354669006`, repository `Latias94/egui`.
- Dockspace base HEAD at capture: `02df1e42ba793721c7cc37332ad2b10b9ed05ab2`, repository `Latias94/egui_docking`.
- The source bases are the actual files copied at capture, not an assumed clean tree. All three actual source files were rehashed after preparation and still equal these bases.
- The pinned checkout and applicable parent/directories contain no AGENTS.md. Root confirmed there is no active local egui worktree with additional instructions and authorized exact-pin preparation. The remote egui main branch is not a valid replacement for this custom pin. Rust skill read before writing: `/Users/frankorz/.codex/skills/rust-best-practices/SKILL.md`.

| Repository | Source | Base SHA-256 | Candidate SHA-256 |
| --- | --- | --- | --- |
| egui | `crates/egui_inspection/src/plugin.rs` | `a81b172ff7507f78415a3d82f38d7341eb7a1ced8bdd6ceb711b02a34a376ec3` | `9242d6d1c5a0062c2a062d3c708234a17fd73887580cbd6c9ce6964d068abb6a` |
| dockspace | `integration/egui-native-smoke/src/bin/physical_x11/driver/inspection.rs` | `19ab0d83a5e8091341b52027406fe7d30657568934b4316c2125a328edae0dae` | `9888b05fe588886b21c549ee8632f13492403b4a5ffdff042ad5a3fd071fdea7` |
| dockspace | `integration/egui-native-smoke/src/bin/physical_x11/driver/scenario.rs` | `9a8031d1fe0d876c28d677d507104dee9974e1057d37b3acc98da399f589dbf2` | `85454244bd86a09978066b3a9af4f34f5912c28a95b1d9bb46b19ccd2acc34c7` |

Main patches:

- `egui-pending-target.patch`: one fork source path, +129/-9, including the registered regression.
- `dockspace-inspection-diagnostics.patch`: two local source paths, +24/-9, including one added assertion in an existing registered deadline test.
- `egui-regression-only.patch`: optional same-test-only patch for a clean exact-pin checkout. **Do not apply it together with the combined fork patch.** It exists to let the reviewer establish a red witness before applying the runtime change; the red outcome has not been executed here.

`receipt.json` contains exact patch hashes, source sizes/hashes, inspection state, and static check results. `egui/{base,tree}/` and `dockspace/{base,tree}/` hold the three exact base/candidate files. These are review copies, not runnable replacement workspaces.

## Runtime change

The existing private `request_frame` helper now receives a `ViewportId`. `maybe_repaint` retains the existing ROOT wake for every non-Settle pending request. It additionally asks each non-root `AwaitViewportTree` target to paint while hidden, on the same existing input/output hooks. The old one-shot target repaint is folded into that existing pending scheduler.

No state fields, request types, transport retries, extra threads, timers, global viewport broadcast, or native continuation system are added. Only requests which already passed known-viewport validation enter the target phase. Existing response matching and Unknown/Removed handling remain intact. Completion removes the request, so it no longer owns a target wake. ROOT inventory/removal progress and the Settle exemption remain in the same scheduler.

The new registered test is:

`plugin::tests::pending_child_tree_rearms_consumed_wake_until_fresh_output`

It uses a real `Context`, installed `InspectionPlugin`, deferred viewport declarations, a real repaint callback, and ordinary semantic widget metadata. It does not manually advance plugin phases or fabricate a tree response. It first caches an old child tree, submits a child request, runs a ROOT pass, consumes the first child wake with `acknowledge_repaint_request` without a child pass, then runs only another ROOT pass. It requires:

- a new callback for the selected child while that child's pass count is unchanged;
- ROOT and target `RequestPaintWhileHidden` commands;
- no unrelated child's callback or paint command;
- no response from ROOT or the old cached child tree;
- a response only after a fresh actual child pass, with the fresh semantic label and a later step;
- exactly one reply and no further request-owned target wake after completion.

The witness uses `allocate_response` plus `WidgetInfo` rather than font rendering, so it does not require adding a font feature/dependency to the fork test package. Existing independent-tree, Unknown, Removed, and root-only hidden/Settle tests are unchanged and remain part of the required package run.

## Local diagnostic change

`InspectionClient::request` keeps `Request` identity in write/read deadline setup errors and actual response-read failures. Write I/O failures already had that identity. The existing registered `request_read_uses_the_remaining_absolute_budget` test now also requires `ListViewports` in the actual timeout error; its timeout and elapsed-time assertions are unchanged.

`root_step_before_drag_route` logs the start of the ROOT checkpoint and its successful semantic step, and attaches that checkpoint stage to failures. It computes the same bounded three-second deadline before logging. The ROOT-source shortcut, OS input sequence, existing deadlines, pointer/geometry requirements, and scenario acceptance assertions are retained. No new repaint is issued by the local diagnostics patch.

## Reviewer qualification commands — not executed in this lane

Apply only after checking the exact base hashes. Use the root-owned disposable fork checkout based on `60c4030`; do not edit the Cargo checkout or replace this custom pin with remote main. All execution remains serial and owned by root.

Static patch checks, run from their corresponding real repositories after base verification:

```text
git apply --check /tmp/physical-smoke-ci/candidate/egui-pending-target.patch
git apply --check /tmp/physical-smoke-ci/candidate/dockspace-inspection-diagnostics.patch
```

The optional red run uses `egui-regression-only.patch` against unchanged exact-pin runtime code in the disposable fork checkout, with the focused command below. Expected red is the missing second child callback after the first wake was consumed. That expectation is source-derived and unexecuted. Use separate deliberate checkouts/states for red and combined candidates; do not double-apply the test.

After root applies the combined fork patch, focused and full package qualification:

```text
cargo nextest run --manifest-path /path/to/egui-fix/Cargo.toml --package egui_inspection --lib --features plugin --locked --test-threads=1 -E 'test(pending_child_tree_rearms_consumed_wake_until_fresh_output)'
cargo nextest run --manifest-path /path/to/egui-fix/Cargo.toml --package egui_inspection --lib --features plugin --locked --test-threads=1
cargo fmt --manifest-path /path/to/egui-fix/Cargo.toml --package egui_inspection --check
```

Before any product smoke is claimed to exercise this fork fix, root must publish/pin the chosen fork commit and deliberately update the actual runtime Git dependency identities and lockfile. In this repository the relevant existing `60c4030` occurrences are in `integration/egui-fork-workspace/Cargo.toml`, `integration/egui-native-smoke/Cargo.toml`, and `integration/egui-fork-workspace/Cargo.lock`. Updating only the workflow's separate `.ci/egui-fork` checkout does not change the compiled physical-smoke dependency. Repinning is intentionally outside these source patches because the reviewed fork commit does not exist yet.

On the Linux/X11 qualification host, after correct repinning and lockfile validation:

```text
cargo nextest run --manifest-path integration/egui-native-smoke/Cargo.toml --package egui-native-smoke --bin egui-native-physical-smoke --locked --test-threads=1
cargo build --manifest-path integration/egui-native-smoke/Cargo.toml --bin egui-native-physical-smoke --locked -j1
```

Then execute the existing full workflow step **Run physical X11/XTest docking smoke**, including its Openbox readiness check, Xvfb/RANDR/XTEST configuration, software GL, and unchanged timeout/acceptance conditions. Keep the native output/admission/continuation checks and all preceding native gates. A successful rerun is validation of that execution, not proof of the unique historical race. If it fails again, the added ROOT checkpoint boundary and request identity distinguish a ROOT query timeout from the next child's input barrier without weakening either.

## Remaining verification

The compiler, lints, registered tests, actual hidden/deferred viewport integration, live X11 scheduling, new fork pin, and real CI remain unverified. No performance or successful-fix claim is made. The candidate is stationary; further source changes or application belong to root after independent review.
