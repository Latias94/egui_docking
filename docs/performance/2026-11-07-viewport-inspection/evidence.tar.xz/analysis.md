# Physical X11 inspection liveness review

Status: read-only diagnosis; no repository/fork edits, builds, tests, smoke executions, CI reruns, or remote writes. Existing CI logs were downloaded with `gh`. This is a bounded source-and-log review, not a reproduced or qualified fix.

## Verdict

The failed job is an application-level inspection-response timeout, not a GitHub queue cancellation, job timeout, or build failure. There is a concrete viewport-liveness defect in the pinned inspection plugin: a pending child-tree request depends on child output, but its persistent wake/paint obligation targets only ROOT. The one initial child repaint is not equivalent to keeping that exact viewport runnable until it supplies the response.

That defect is a justified narrow fix candidate. **The available logs do not prove that it was the unique cause of run 42285373560.** In particular, they do not identify whether the last unread request selected ROOT or the child, nor whether the UI failed before admission, before input hooks, after input hooks, or while producing output. Do not publish “the child request was definitely stranded” or “Shared was deadlocked” as an established observation.

## Pinned evidence

- Failed run: [42285373560](https://github.com/Latias94/egui_docking/actions/runs/42285373560), head `6fe5eb66e8fcc6677f3d8ab6a02a3c6d89cfc334`; failed job [128124694068](https://github.com/Latias94/egui_docking/actions/runs/42285373560/job/128124694068).
- Passing run: [42282205148](https://github.com/Latias94/egui_docking/actions/runs/42282205148), head `5ea7fbb2b10fe1bbac851da1d179d1b78df7a4c0`; corresponding successful job [128113944819](https://github.com/Latias94/egui_docking/actions/runs/42282205148/job/128113944819).
- Full logs: `failed-job.log`, `passed-job.log`; extracted step logs: `failed-physical.log`, `passed-physical.log`; readable event timelines: `failed-timeline.txt`, `passed-timeline.txt`.
- `source-hashes.json` records failed-head, passing-head, and current file hashes. The three requested smoke files, native `app.rs`, `surface_driver.rs`, `mailbox.rs`, `host_frame.rs`, workflow, and fork-workspace manifest are byte-identical across all three versions. This rules out a direct edit to these particular paths; it does not exonerate changes elsewhere in the core or their effect on scheduling.
- The smoke build logs compile `egui`, `eframe`, and `egui_inspection` from `60c40304dab75305d2ac0f54a1cabfc354669006`. All seven reviewed local fork files match that exact Git revision. The separate workflow checkout used for fork tests is `56e3db49...`; it is not the revision identified in the smoke compilation lines. Both runs have the same distinction.
- Source snapshots are under `sources/`. `receipt.json` records run/job metadata and artifact SHA-256 values.

## What happened

All preceding steps of the failed native job succeeded, including native production tests, output/backpressure qualification, the actual editor lifecycle, physical-smoke unit tests, and the programmatic real-window Glow smoke. The physical step exits with code 1 after roughly four seconds; neither its 55-second outer timeout nor GitHub job time limits fire.

| Failed run UTC | Observation | What it establishes |
| --- | --- | --- |
| 20:35:58.3256588 | Child source hover, viewport `2CEC`, tree step 39 | Child inspection and physical pointer observation worked before the press. |
| 20:35:58.3502781 | Child source press, tree step 41, `primary_down=true` | The semantic tree observed the physical press. The press itself did not disappear. |
| 20:35:58.3743665 | Product phase remains ChildFirstLive; quiescent becomes false | A root UI published an updated observation. This line alone does not identify which pending inspection request was already admitted. |
| 20:35:58.3996900 | Native root roster epoch 7 | `DiagnosticNativeHost::on_output_begin` ran far enough to capture a changed roster. This log is emitted **before** inner output admission; it is not evidence of a completed root input/output pass. |
| 20:36:01.4005274 | Root roster epoch 8 | Another root admission boundary occurred around cleanup. |
| 20:36:01.4408771 | `read semantic inspection response: Resource temporarily unavailable (os error 11)` | A blocking socket read exhausted its configured receive budget. It does not identify the request or tell whether no bytes or a partial frame arrived. |

Epoch 7 to epoch 8 is 3.0008374 seconds. Press-log to surfaced error is 3.090599 seconds. The driver uses absolute per-stage deadlines bounded to three seconds; Linux may report an expired socket receive timeout as `WouldBlock`/EAGAIN. The server's independent `recv_timeout` is 20 seconds, so this is not the server's own timeout response. There is no server timeout response in the physical-step log.

In the passing run, child source press is step 44 at 20:04:05.2331882, threshold succeeds at step 47 / 20:04:05.2532776, then first ingress and route confirmation succeed. Both runs use identical window geometry and pointer coordinates: child bounds `(560,226)..(1280,746)`, source `(600,240)`, threshold `(572,241)`, root ingress `(381,244)`.

The ordering after source press matters. `reach_target_surface_while_pressed` first calls `root_step_before_drag_route` (`scenario.rs:2283`), which issues a fresh `GetViewportTree(ROOT)` with its own three-second bound (`:2381-2394`). Only after that response does it inject the threshold motion and enter the child's `input_barrier`. The error text in `InspectionClient::request` (`inspection.rs:67-73`) drops request identity. Therefore “the source-press log was followed by a timeout” is insufficient to distinguish a blocked ROOT checkpoint from a blocked child threshold request. No threshold-success line is printed in the failure.

## Confirmed source defect: response owner and wake owner differ

Pinned `egui_inspection/src/plugin.rs`:

1. `serve_connection` submits one request, wakes ROOT, and waits on a channel (`:562-591`). It handles requests serially per connection.
2. `input_hook` recognizes a known `GetViewportTree { viewport }`, issues **one** `ctx.request_repaint_of(viewport)`, and moves the request to `AwaitViewportTree` (`:314-328`).
3. Both hooks call `maybe_repaint`; for every pending non-Settle request it invokes `request_frame(ctx)` (`:161-169`). That helper unconditionally sends `RequestPaintWhileHidden` to **ROOT** (`:223-227`). The selected child gets no persistent paint-while-hidden command.
4. `output_hook` deliberately keeps the request pending when `current_viewport != requested viewport` (`:410-436`). Root passes cannot legally satisfy a child-tree request with the root tree or the cached child tree.

A selected child that does not produce another full pass can therefore leave a live request while root passes keep spinning. The absence of a response does not mean “the app is not painting”; root painting is insufficient.

There are actual integration paths which can consume a scheduling opportunity without calling child plugin hooks: native admission/input deferral and hidden/logic-only child handling. The latter is explicit in pinned `glow_integration.rs:941-1012`: no egui pass occurs, and only ROOT receives `update_logic_only`. The redraw watchdog in `run.rs` removes an overdue redraw deadline after 250 ms and invokes `PassMode::LogicOnly`, also not a full child pass. These establish why a single repaint is not a complete response obligation. They do **not** establish that this particular visible X11 child was hidden, that a redraw was missed, or that the watchdog fired in this run.

An important countercheck: production native input/admission deferrals already register blocked child continuations (`mailbox.rs:5285-5320`, `:5557-5574`); committed boundaries release/claim those continuations and request child repaint (`host_frame.rs:295-303`). Do not add a second native retry mechanism based on an assumption that all child deferrals lack continuation. This review did not find evidence identifying a broken instance of that existing mechanism.

## Mutex and reply-path checks

No static Shared/TCP lock cycle was found in the reviewed path:

- The physical driver calls `shared_fatal_error` and checkpoint helpers, which return copied/cloned values and drop the guard before `inspection.tree`. Its tree requests do not carry a `Shared` guard.
- `wait_for_product` uses the condvar's releasing wait and does not issue inspection calls while holding the guard.
- `DiagnosticNativeHost::on_output_begin` releases its Shared guard before calling the inner host. Ordinary guide-control does not enable the overflow/stationary hooks that add further Shared work.
- `Context::with_plugin` first returns an owned plugin handle from its Context read, releases the Context guard, then locks that plugin. UI plugin hooks also use an owned handle after releasing the Context read. The connection closure only submits/sends via mpsc; it does not hold the plugin lock while waiting for a response.
- The response callback runs from output hooks and only performs an mpsc send. The connection thread writes the response outside plugin/UI locks. `protocol::write_message` explicitly flushes its writer. There is no evident missing-flush bug.

The cleanup/root activity argues against a permanent UI-thread lock cycle, but does not eliminate transient stalls or a particular output obligation waiting for future native input. Neither request-phase traces nor thread stacks were captured in CI, so negative source findings must not be presented as a proof that no runtime lock stall occurred.

Inspection replies are emitted in ordinary egui output hooks, before native terminal settlement/presentation. A missing semantic response is not, by itself, proof that a GPU/renderer terminal callback was lost; conversely a tree response does not prove presentation. Keep those completion domains separate.

## Smallest justified fix and validation handoff

Recommended fork slice: make the existing pending request own the wake for its selected viewport, without changing protocol responses or deadline policy.

- Retain ROOT wake while any non-Settle request is pending so inventory and removal can progress.
- For every `AwaitViewportTree { viewport }` selecting a non-root viewport, keep requesting that **same** viewport with `RequestPaintWhileHidden`, using the existing per-hook scheduler. The command also requests its repaint. Only do this after known-viewport validation; do not create synthetic entries for arbitrary unknown IDs.
- Remove or fold the redundant one-shot `request_repaint_of(viewport)` into this scheduling responsibility. Stop issuing the target obligation when the request replies or returns Removed. Preserve the current matching-output requirement and typed Unknown/Removed responses.
- Keep `Settle` exempt. Do not replace a fresh target output with a cached tree, inject semantic input, relax presentation checks, lengthen three seconds, retry the entire physical scenario, or skip the case.

This is request-owned scheduling, not a transport resubmission loop. It repairs a provable liveness hole, but requires independent validation before claiming it fixes this CI failure.

Also make the local smoke read error retain `Request`/viewport identity (`InspectionClient::request`) and give the root checkpoint an explicit stage label. That is a small diagnostic change with no timing/acceptance relaxation. It closes the exact evidence ambiguity above; it cannot repair liveness alone.

Necessary registered witnesses for the fork slice, using existing Context/plugin tests rather than a new test framework:

1. Submit a known child-tree request, run a ROOT pass to enter AwaitViewportTree, consume the child's first repaint without producing a child output, then run another ROOT pass. Observe a fresh child wake and a child `RequestPaintWhileHidden` command. The channel must remain empty until an actual child output and then reply exactly once with that child's current tree. The existing manually driven `lists_and_selects_independent_viewport_trees` test does not assert this scheduling property.
2. Exercise the same target scheduling while the child is hidden, then remove the child while waiting; retain the existing typed removal/unknown behavior and do not recreate an unknown viewport. Existing root-only hidden-window tests do not cover this target.
3. Keep the physical guide-control smoke registered and unchanged in behavioral strength. Run it through the real pinned X11/XTest/Glow path after the fork fix is pinned; include the existing native deferral/continuation witnesses. A green rerun alone is not a causal proof of the precise historical event.

If the failure recurs with request-owned target scheduling, the next bounded diagnostic should record request viewport and phase, actual hook viewport, and native Proceed/Defer for that pending request. That distinguishes an unprocessed ROOT checkpoint, a child full-pass scheduling gap, and a post-hook reply/transport stall. Do not add a generic retry/timeout framework or broad instrumentation outside this path.

## Limits

No new execution was performed. There is one failing CI run and one adjacent passing run; their native/inspection source identities match, but they are not a controlled timing pair. No per-request server trace, partial-read byte count, native admission trace, renderer terminal trace, or thread stack is available. The exact historical interleaving remains unresolved. The concrete child wake/response-owner mismatch is independently reviewable from pinned source and is the smallest source correction supported by this review.
