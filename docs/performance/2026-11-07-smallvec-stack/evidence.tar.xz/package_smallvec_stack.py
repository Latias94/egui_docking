"""Archive exact sources, qualification and both complete paired comparisons."""
from pathlib import Path
import csv
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

ROOT = Path('/Users/frankorz/codes/rust/egui_docking')
BASE = Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
AUTHOR = Path('/tmp/smallvec-projection-stack')
OUT = ROOT / 'docs/performance/2026-11-07-smallvec-stack'
OUT.mkdir(exist_ok=True)
frozen = BASE / 'smallvec-stack-frozen'
verified = BASE / 'smallvec-stack-verified'
receipt = json.loads((frozen / 'source-receipt.json').read_text())
checks = json.loads((verified / 'checks-all.json').read_text())
assert receipt['sources_unchanged'] and checks['sources_unchanged']
assert checks['normal_counters_enabled']
assert all(c['returncode'] == 0 for c in checks['checks'])
assert all(receipt['sources'][p] == h for p, h in checks['sources'].items())
assert json.loads((verified / 'work-check.json').read_text())['returncode'] == 0
assert json.loads((verified / 'work-summary.json').read_text())['expected_actual_root_builds_match']
comparisons = []
for reference in ('baseline', 'imgui'):
    directory = frozen / ('against-' + reference)
    env = json.loads((directory / 'environment.json').read_text())
    assert env['complete_state_equal'] and env['frozen_executables_unchanged']
    assert env['source_tree_matches_frozen_candidate_at_finish']
    rows = list(csv.DictReader((directory / 'summary.csv').open()))
    cells = {}
    for row in rows:
        cells.setdefault(tuple(row[k] for k in ('group', 'panes', 'views', 'case')), {})[row['condition']] = row
    assert len(cells) == 42
    for (group, panes, views, case), pair in cells.items():
        row = dict(reference='eb94cb242722962c9e0d88074d81cf462d784357' if reference == 'baseline' else 'imgui', group=group, panes=panes, views=views, case=case)
        for stat in ('p50', 'p95', 'max'):
            old = float(pair['baseline']['operation_owned_ns_' + stat])
            new = float(pair['candidate']['operation_owned_ns_' + stat])
            row.update({f'baseline_ns_{stat}': old, f'candidate_ns_{stat}': new,
                        f'candidate_over_baseline_{stat}': new / old,
                        f'reduction_percent_{stat}': (1 - new / old) * 100})
        comparisons.append(row)
with (OUT / 'comparisons.csv').open('w', newline='') as output:
    writer = csv.DictWriter(output, fieldnames=list(comparisons[0]), lineterminator='\n')
    writer.writeheader()
    writer.writerows(comparisons)

inputs = {}
for name in ('smallvec-stack-frozen', 'smallvec-stack-verified'):
    for path in sorted((BASE / name).rglob('*')):
        if path.is_file() and path.suffix in ('.rs', '.patch', '.json', '.csv', '.txt', '.stdout', '.stderr', '.log'):
            inputs[str(path.relative_to(BASE))] = path.read_bytes()
for name in ('verify_smallvec_stack.py', 'freeze_smallvec_stack.py', 'compare_smallvec_stack.py',
             'work_freeze_smallvec_stack.py', 'package_smallvec_stack.py', 'smallvec-stack-application.json',
             'packed-results-frozen/source-receipt.json'):
    inputs[name] = (BASE / name).read_bytes()
for path in sorted(AUTHOR.rglob('*')):
    if path.is_file() and path.suffix in ('.rs', '.patch', '.json', '.md'):
        inputs['original-candidate/' + str(path.relative_to(AUTHOR))] = path.read_bytes()
inputs['combined-source-review.md'] = (AUTHOR / 'review.md').read_bytes()

# Bind the measured overlay directly to its immutable control, including the new file.
changed = subprocess.check_output(['git', 'diff', '--name-only', 'eb94cb242722962c9e0d88074d81cf462d784357', '--', 'crates/dockspace', 'Cargo.toml', 'Cargo.lock', 'integration/dockspace-host-harness/Cargo.lock', 'integration/egui-fork-workspace/Cargo.lock', 'integration/egui-official-harness/Cargo.lock', 'integration/egui-product-harness/Cargo.lock'], cwd=ROOT, text=True).splitlines()
added = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', 'crates/dockspace', 'Cargo.toml', 'Cargo.lock', 'integration/dockspace-host-harness/Cargo.lock', 'integration/egui-fork-workspace/Cargo.lock', 'integration/egui-official-harness/Cargo.lock', 'integration/egui-product-harness/Cargo.lock'], cwd=ROOT, text=True).splitlines()
assert len(set(changed + added)) == 8
for name in changed:
    inputs['actual-control/' + name] = subprocess.check_output(['git', 'show', 'eb94cb242722962c9e0d88074d81cf462d784357:' + name], cwd=ROOT)
for name in sorted(set(changed + added)):
    contents = (ROOT / name).read_bytes()
    assert hashlib.sha256(contents).hexdigest() == receipt['sources'][name]
    inputs['measured-candidate/' + name] = contents
inputs['actual-control/commit.txt'] = subprocess.check_output(['git', 'rev-parse', 'eb94cb242722962c9e0d88074d81cf462d784357'], cwd=ROOT)

raw_rows = sum(sum(1 for _ in csv.DictReader(io.StringIO(data.decode())))
               for name, data in inputs.items() if Path(name).name == 'raw.csv')
vectors = sum(Path(name).suffix == '.txt' and any(p.endswith('-states') for p in Path(name).parts) for name in inputs)
assert (raw_rows, vectors) == (16128, 336), (raw_rows, vectors)
manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(inputs.items())}
with tarfile.open(OUT / 'evidence.tar.xz', 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as archive:
    for name, data in sorted(inputs.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        archive.addfile(entry, io.BytesIO(data))
    data = (json.dumps(manifest, indent=2) + '\n').encode()
    entry = tarfile.TarInfo('manifest.json')
    entry.size = len(data)
    entry.mode = 0o644
    archive.addfile(entry, io.BytesIO(data))
with tarfile.open(OUT / 'evidence.tar.xz', 'r:xz') as archive:
    for entry in archive:
        assert entry.isfile() and not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts
        data = archive.extractfile(entry).read()
        if entry.name == 'manifest.json':
            assert json.loads(data) == manifest
        else:
            assert data == inputs[entry.name]
(OUT / 'checks.json').write_text(json.dumps({'normal_counters_enabled': True, 'checks': checks['checks'], 'sources_match_formal_receipt': True}, indent=2) + '\n')
shutil.copy2(AUTHOR / 'review.md', OUT / 'combined-source-review.md')
(OUT / 'archive-check.json').write_text(json.dumps({'regular_input_files': len(inputs), 'raw_rows': raw_rows,
    'complete_vectors': vectors, 'all_members_roundtrip_equal': True,
    'actual_control_commit': inputs['actual-control/commit.txt'].decode().strip(),
    'actual_changed_sources': len(set(changed + added)), 'archive_bytes': (OUT / 'evidence.tar.xz').stat().st_size}, indent=2) + '\n')
(OUT / 'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n'
    for p in sorted(OUT.iterdir()) if p.is_file() and p.name != 'SHA256SUMS'))
print('Archived', len(inputs), 'files;', raw_rows, 'raw rows;', vectors, 'vectors;',
      sum(r['reference'] == 'imgui' and r['candidate_over_baseline_p50'] <= 2 for r in comparisons), '/42 within 2x')
for reference in ('eb94cb242722962c9e0d88074d81cf462d784357', 'imgui'):
    for stat in ('p50', 'p95', 'max'):
        values = [r['reduction_percent_' + stat] for r in comparisons if r['reference'] == reference]
        print(reference, stat, 'range', min(values), max(values), 'negative', sum(v < 0 for v in values))
