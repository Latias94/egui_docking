# Layout stack, scratch and fresh leaf-input ownership

**One bounded candidate is justified for measurement: replace only the production projection continuation Vec with SmallVec using 16 inline ProjectionFrames and normal heap spill.** Keep the existing frame enum, state machine, numeric solver, gather scratch, input Adapter and outputs unchanged. This removes a source-level heap-backed stack owner for shallow projections while preserving arbitrary depth. It is not a performance prediction, and the larger inline stack frame and extra container branches may outweigh the saving.

The queued packed child-results representation is outside this recommendation. Its output-owner consolidation is not repeated here. This analysis does not authorize implementation or supersede the current queue.

Only this report was written. No Cargo, compilation, formatting, tests, runner, profiling, timing, network, delegation, repository/fork/cache or candidate modification was performed.

**Source binding and context.** The observed HEAD was `f1c624b62de26220399ae3eff059a76160c232b5` during inspection; the important binding is to the actual source hashes below, including the axis-input change. Root's supplied latest complete/layout medians are context, not measurements or independently reviewed timing evidence from this lane. The remaining approximately 1.125–1.583 us layout phase is a reason to examine work repeated for every root; it does not identify allocator shares or permit subtracting phase medians to predict a gain.

| Source | SHA-256 |
| --- | --- |
| `crates/dockspace/src/layout.rs` | `dc32cdecddbb742f5d6d225d48e80c2170facb385364c7deefc724e709fc367a` |
| `crates/dockspace/src/layout/topology.rs` | `1dc1264af676b5a083a299332203057b02004d174c8d4e27e45c6074f513a26c` |
| `crates/dockspace/src/docking_cost.rs` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` |
| `Cargo.lock` | `f071e3de77e738f557823c49a042472c8bcf261bf168d0c3a792568d589a4210` |
| `crates/dockspace/Cargo.toml` | `effacceb9d309c7351ba7e9504101716341ca874e085fea2572e3c79b9e17c03` |

**Current short-lived owners.**

| Location | Actual ownership and use |
| --- | --- |
| `layout.rs:944–985` | `project_subtree` starts a nonempty Vec with one Enter frame, then uses the compact LIFO continuation machine. This stack is created for every projected root, including a leaf root. |
| `topology.rs:149–178` | One reusable child-measurement Vec per committed measurement call. It is cleared and populated for each split, then borrowed by the original composer. It is not a new Vec for every split. |
| `layout.rs:594–623` | Minimum-only projection has a separate reusable child gather for its delayed maximum pass. A minimum-only measurement discarded before projection never reaches the projection stack. |
| `layout.rs:1029–1068` | Binary constraints and durable weights already use two-element local arrays. General arity uses reusable constraint/weight Vecs; actual overrides are borrowed. Replacing these Vec constructors does not save an allocation in the ordinary binary path. |
| `ProjectionScratch.eligible` | A Vec populated only when grow/shrink redistribution reaches it. An empty constructor is not a heap-allocation witness. Do not assume this owner contributes a fixed per-root cost. |
| `docking_cost.rs:215–256` | Fresh owned leaf-answer records per root, followed by consuming iteration. This is part of layout timing, separate from the core gather and result arrays. |

Raw draft compilation and the reference oracle have their own measurement/projection stacks. They serve different checked/oracle roles and need not migrate in the proposed slice. The production continuation code also projects checked raw topology, so its sequence and overflow behavior still matter there.

**Why the continuation stack is the first choice.** The compact machine keeps one continuation per suspended ancestor, plus the current Enter frame. It no longer queues every sibling up front. For the fixed balanced binary fixture, peak stack length is height +1, not node count or arity.

At 1024 panes and one view, initial height is 10. The formal Item edge wrapper can add one level, giving a peak of 12 frames. Four views start with 256 leaves per root and a smaller peak. The 16- and 128-pane shapes also fit within 16, including the added edge level. This is a static bound for these particular fixtures, not an upper limit imposed on valid workspaces.

Capacity 16 is a small ordinary depth allowance that avoids spilling in those source-defined shapes. Capacity 8 would fit many smaller projections but can spill on a 128-pane edge or the 1024-pane cases. Deep or irregular workspaces must retain normal dynamic spill; the existing ten-thousand-nested-splits witness must not become a fixed-capacity failure or recursive fallback.

The necessary runtime scope is one import, stack construction and the concrete stack parameter in `advance_split_projection`. Use SmallVec directly or a private type alias, without a wrapper container or generic stack provider. Keep every existing push/pop in the same order. Frame storage contains owned rows, bounds and scalar continuation state, with no references into the stack, so relocation does not create a new self-referential lifetime problem.

**The dependency is already available, but is new to the core crate.** Root Cargo.lock selects **smallvec 1.16.4** at lines 2211–2214. Its registry source and crate archive are present locally. The archive SHA-256 is `d0d5d4b1981b8bbbb7aed204cae5726d683d5d6ac7e74ec54122ea28f315e7c8`, exactly the lock checksum. The inspected `src/lib.rs` and package manifest match the archive bytes.

This is the established Servo SmallVec implementation already used by the workspace dependency graph, rather than a new hand-written collection. The installed manifest declares MIT OR Apache-2.0, edition 2018 and no build script. It does not currently appear in dockspace's direct dependency list or workspace dependency declarations, so adopting it still requires explicit dependency/lock integration; it is not a dependency-free runtime change.

The built-in array support includes length 16 without `const_generics` (`smallvec src/lib.rs:2681–2698`). No custom Array implementation, unsafe project code, serde support, union feature or compiler extension is needed for this use. Do not upgrade the locked package or enable unrelated features in the same slice. Existing feature unification and actual compilation remain Root-owned qualification, not established by source availability.

**Initialization, movement and negative costs.** SmallVec's empty constructor sets zero length and uses internally uninitialized array storage (`src/lib.rs:745–755,849–860`); it does not construct 16 valid ProjectionFrames or 16 geometry values. Only actual pushes initialize elements. This concerns temporary storage, not permission to leave required output values uncomputed.

Its source-level push/pop operations distinguish inline and spilled storage (`1215–1255`). On first overflow, growth allocates and copies the currently live inline elements to the heap (`1288–1324`); further growth follows the heap path. There is no requested Frame clone or output recomputation. The current Vec instead starts with heap-backed capacity and may grow as depth increases.

The tradeoff is explicit: reserve space for 16 full enum values in the function's stack footprint, add inline/spilled branches and retain heap behavior for deep cases. Passing/moving the inline owner or compiler-generated initialization can have costs not visible in container counts. Exact enum layout, stack bytes, memset elimination, allocation-call counts and latency have not been measured or compiled here. Four roots are projected sequentially, but the inline footprint still occurs on every call. Minimum-only discard has no direct saving because it never enters this function.

The child-gather Vec is another real candidate for inline storage, especially for binary splits, but it should not be bundled now. That would change a second hot collection path and obscure whether stack handling helped. It is also distinct from the rejected childrows iterator experiment: keeping the gather preserves materialization, but does not itself prove an inline replacement faster.

**Fresh leaf answers remain real timed work.** `project_all_roots` creates the leaf Constraints value, walks each actual root and pushes every `(NodeId, Constraints)` answer into its fresh Vec (`docking_cost.rs:197–237`). These are Copy value records; there is no separately allocated object per answer.

`into_iter().peekable()` consumes the same Vec buffer. It does not clone a second answer Vec. The callback matches the next expected identity with `next_if`, then supplies that stored answer to the fresh measurement. The answer owner lives through the call and is released afterward. The outer collection of RootProjections is another owned container, not part of the child scratch. All of this occurs after mutation and before the layout clock ends (`441–462`).

A SmallVec answer buffer would retain fresh materialization but reserve considerably more inline data than a scalar/index stack and could spill/copy for larger roots. It would optimize this host/benchmark Adapter rather than every caller of the core projector. No such Adapter change is included in the chosen candidate.

Do not replace the identity-checked answer roster with a constant-return callback merely because the fixture's Constraints are equal, precompute it outside the operation, retain answers across runs, or remove the actual measurement pass. None of those follows from reducing storage ownership. Likewise, this report does not assign the Adapter's Vec cost to the core solver.

**Contract and retention boundary.** Preserve the release first-visit-prefix assertion, DFS leaf/child order, pending-child geometry timing, raw repeated-parent/last-write behavior, central route, override and extent checks, original numeric arithmetic, every fresh leaf answer, all node/child/split results and complete export. Output Clone, old-output lifetime and staged/transaction ownership are untouched by a stack-only change.

Root can qualify one concrete SmallVec stack slice with existing deep nesting, raw DAG/cycle/missing-node/error-priority, late geometry/owned-output and full fresh-output oracles, then compare the unchanged complete operation including all negative cells and tails. No new mirror tests or framework are needed merely to demonstrate that push/pop still work. Retain only if complete measured results justify the new direct dependency, inline footprint and branch/code-layout cost.
