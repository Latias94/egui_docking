# Inline projection continuation stack

READY / source stationary / not qualified. This candidate replaces only the
short-lived production projection continuation Vec with SmallVec containing
sixteen inline ProjectionFrame slots and normal dynamic spill. It does not
change projection results, geometry, input validation or numerical algorithms.
No benefit is established by source-level owner reduction.

Only this new temporary package was written. Repository, fork, cache, Git
state, packed candidates and all other previous candidates remain unchanged.
No Cargo, compiler, formatter, test, runner, timing, benchmark, profiler,
network or child agent was used. Root alone owns behavioral qualification,
dependency resolution checks, complete timing comparisons and retention.
Independent source review is required before Root's formal verification.

## Immutable source binding

Every base file is an immutable Git blob from
`07f566ac8fbddfab819f46f613d55bc2069507dd`, obtained through read-only
`git cat-file --batch`. No live worktree input or axis/packed candidate is
included. `base-manifest.json` records complete commit/path origins, blob IDs,
hashes and sizes. `base/` and `tree/` contain ten complete source pairs:
layout.rs, the workspace/core manifests and all seven tracked Cargo.lock files.
Two historical performance locks remain unchanged context pairs.

The design input is `/tmp/layout-stack-and-fresh-inputs.md`,
SHA-256 `3fc5703aa84ba9f4656c18fd47f3b1f1f04f3078e115970452bd2107a741af59`,
copied under `inputs/`. Its axis-parent observations do not authorize that
specialization here: this retained parent keeps the original checked
`solve_axis_into` entry and complete validation. Rust best-practices was read
before the temporary Rust edit.

## Exactly three runtime edits

Only `crates/dockspace/src/layout.rs` changes at runtime:

1. Import `smallvec::SmallVec`.
2. Initialize the existing single root Enter frame with
   `SmallVec<[ProjectionFrame; 16]>` and the crate's ordinary list macro.
3. Change `advance_split_projection`'s concrete mutable stack parameter to
   that same SmallVec type.

The entire file otherwise matches the retained parent after reversing those
three literal edits. Runtime delta is +4/-2, below the fifteen-added-line limit.
There is no type alias, collection wrapper, provider trait, new enum, recursive
fallback, fixed-depth error or handwritten inline container. ProjectionFrame
and SplitProjectionState remain their original owned types; no Clone bound is
added. The list macro pushes one initial value; it is not the repeated-element
macro form.

All existing push/pop statements, values and order remain exact. ContinueSplit
still precedes the next child Enter push; the LIFO traversal, pending-child
extent reread, late gap construction and error ordering do not change. The
release first-visit prefix rejection and legal raw revisits remain. No changes
are made to RootMeasurement, NodeMap, output arrays, constraints gathering,
binary/generic/override inputs, central route, original solver, validators,
fresh leaf Adapter, complete export or clocks.

The same continuation Implementation also projects successful checked raw
topology; its raw DAG behavior is retained. The raw diagnostic compiler's own
stack and the independent reference implementation are not migrated.

## Dependency and lock inventory

All seven tracked retained-parent locks contain exactly one smallvec package:
version **1.16.4**, registry source
`registry+https://github.com/rust-lang/crates.io-index`, checksum
`d0d5d4b1981b8bbbb7aed204cae5726d683d5d6ac7e74ec54122ea28f315e7c8`.
There is no version disagreement to resolve.

The workspace declares `smallvec = "1.16.4"` and dockspace declares
`smallvec.workspace = true`. This follows existing workspace version syntax;
the committed locks select 1.16.4. No feature, optional-dependency rule,
default-feature flag, package source or version is changed.

Only these five applicable lockfiles add the single `"smallvec"` entry to the
existing dockspace package's dependency list:

- `Cargo.lock`;
- `integration/dockspace-host-harness/Cargo.lock`;
- `integration/egui-fork-workspace/Cargo.lock`;
- `integration/egui-official-harness/Cargo.lock`;
- `integration/egui-product-harness/Cargo.lock`.

Every other byte in each lockfile remains unchanged. Package rosters,
versions, sources, checksums and existing dependencies are preserved.
No new lock is invented for a directory without one.

The two locks under
`docs/performance/2026-11-06-title-resources/allocation-{baseline,candidate}/`
are immutable historical evidence, without their own current Cargo.toml
build input. They are inventoried and copied unchanged, not rewritten to
pretend the historical experiment depended on SmallVec.

`lock-inventory.json` records all seven findings and decisions. Source-only
manual lock edits do not substitute for Root's locked Cargo checks.

## Existing dependency behavior and negative costs

The locally present smallvec 1.16.4 archive matches the lock checksum exactly.
Its source manifest and library hashes are recorded in `scope-checks.json`.
This was read-only inspection of the existing cache, without fetching,
installing, resolving or compiling anything.

The crate's ordinary array support includes length sixteen without enabling
const_generics. Its list macro creates an empty SmallVec and pushes the one
Enter frame into inline storage. Empty construction does not create sixteen
valid ProjectionFrames. The existing implementation supports subsequent heap
spill and normal growth, so arbitrary valid depth is not restricted to sixteen.
These are observations of the dependency source, not executed qualification.

The existing compact continuation machine keeps one suspended continuation per
ancestor. The fixed balanced benchmark trees, including their one extra edge
wrapper, fit within sixteen according to the design report's source reasoning.
Deep or irregular user trees can exceed that allowance and must spill normally.
No fixed-array size is treated as an invariant about valid workspaces.

This is a new direct dependency for the core crate even though its package was
already locked transitively. It is not dependency-free or zero-cost. The inline
owner reserves storage for sixteen full enum values, increasing the projector's
stack footprint. Push/pop distinguish inline from spilled storage; the first
spill can allocate and move live frames, with later heap growth as necessary.
Compiler-generated movement, initialization, branching and code layout can
outweigh avoiding a shallow Vec allocation. Existing feature unification can
affect the selected implementation; this candidate requests no extra feature.
No sizeof, allocation-call/byte count, allocator share or latency claim is made.

Sequentially projecting several roots does not make the per-call inline
footprint or branch costs disappear. Minimum-only measurements discarded before
projection never reach this stack and have no direct saving. General input,
measurement, eligible-index scratch and complete output owners remain.

## Source checks and verification handoff

The primary patch has eight changed paths: one runtime source (+4/-2), two
manifest additions, and five one-line lock additions; total +11/-2. It contains
no test or cost-probe hunk. `source-pairs.md` and `manifest.json` bind all ten
base/tree pairs. Set digests explicitly sort UTF-8 relative-path strings.

`scope-checks.json` records 44 static checks: immutable origins, exact three
runtime edits, preserved push/pop statements and full checked solver, original
frame/scratch types, unchanged validators, literal manifest additions, exact
one-edge lock changes, unchanged package metadata, local archive identity and
default array/macro source support. Exact primary patch reconstruction and
read-only `git apply --check --whitespace=error` in the temporary base pass.
No formatter was run; static source checks are not Rust compilation.

Root's independent reviewer should confirm the exact three-edit runtime slice,
lock integration, feature assumptions and unconstrained spill. Existing genuine
10k-depth, complete raw/error-priority and owned-output oracles should then
qualify it without new storage-form tests. Only Root's complete operation
comparisons, including small/large roots, four views and negative tails, can
justify retention. Do not combine packed-output work in this measurement or
attribute its work to the stack candidate. This package is stationary.
