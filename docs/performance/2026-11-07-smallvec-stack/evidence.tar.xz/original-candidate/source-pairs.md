# Exact source pairs

Base commit: `07f566ac8fbddfab819f46f613d55bc2069507dd`.

| UTF-8 relative path | Base SHA-256 | Candidate SHA-256 | Delta |
| --- | --- | --- | --- |
| `Cargo.lock` | `f071e3de77e738f557823c49a042472c8bcf261bf168d0c3a792568d589a4210` | `522799eaf6df6729c40e80454e3e29fdcd9fce3b73f456686d227a30ee8565f0` | +1/-0 |
| `Cargo.toml` | `03937455cf6bd2c7124d6c17efc374244324d4d6a64f8c15af430ad7c97d17b7` | `390bfe200830b570890e5ad3b83f28cca69cedc4fbb521db135e0f815d8e9d6b` | +1/-0 |
| `crates/dockspace/Cargo.toml` | `effacceb9d309c7351ba7e9504101716341ca874e085fea2572e3c79b9e17c03` | `4aedf758012c5e64cf455abd66236107469e0ed36e94ff9e523f9a2a24466dae` | +1/-0 |
| `crates/dockspace/src/layout.rs` | `478cf5a1f3c6cf41cd3f21f3dfdc301a350957f18f58f900376edb256e38c05e` | `a38cb6a224cc420472218caaa18b3ce9e7c5eadb83bda402119c5dcb91a5121a` | +4/-2 |
| `docs/performance/2026-11-06-title-resources/allocation-baseline/Cargo.lock` | `2a82f1423b6d87f5a941de8fe002525c7b51563656fa3e8e34c3171838d2596b` | `2a82f1423b6d87f5a941de8fe002525c7b51563656fa3e8e34c3171838d2596b` | +0/-0 |
| `docs/performance/2026-11-06-title-resources/allocation-candidate/Cargo.lock` | `2a82f1423b6d87f5a941de8fe002525c7b51563656fa3e8e34c3171838d2596b` | `2a82f1423b6d87f5a941de8fe002525c7b51563656fa3e8e34c3171838d2596b` | +0/-0 |
| `integration/dockspace-host-harness/Cargo.lock` | `89bb8442e6ca290761f3c4d51e9680d98af6ce6d99175cdb5d08f330437ec614` | `50a082947ec8db973378bc1d63f6d7e1ed88ddec407c22bb922167bf98cc8c26` | +1/-0 |
| `integration/egui-fork-workspace/Cargo.lock` | `0d32e3fc8e4ab1fa07592288da52f98e0d7fc27984b3f70d1c6fe574aabac6aa` | `efd19c4b8d810edddd20dc913ecba5d52b6960d0f8c78f2f38c84f306ac9b264` | +1/-0 |
| `integration/egui-official-harness/Cargo.lock` | `bb7442680415b3091429bd3207e78b5fff93bd7a28788adf81ee18ca2524bc65` | `be12c6aff6e66b2b740b104bc422e60a3d19d2932b58b83dda7c86cec7b10279` | +1/-0 |
| `integration/egui-product-harness/Cargo.lock` | `4dbbe56bbe89c631b7abb46f9cfb73b7ffe5af922886632b05f83daef3b6497b` | `cc2f7adf02ed0a64e837b7ef1f21cf115b4efd0cf89f889f323773b879b78e74` | +1/-0 |
