# Independent source review request

Candidate: `/tmp/smallvec-projection-stack/`, based entirely on immutable
`07f566ac8fbddfab819f46f613d55bc2069507dd`.
Patch SHA-256:
`00b88a4b79c5caa164c748cdcb68f2ea4764e0439190dd477acb9116f6a6e0ad`.

Root has requested an independent review before formal verification.
Please inspect only the concrete three-edit continuation stack migration,
SmallVec<[ProjectionFrame; 16]> list initialization and normal dynamic spill;
workspace/core dependency declarations; and the five applicable one-edge
Cargo.lock edits. Two historical archived locks are unchanged.

The whole original layout file is reproduced after reversing those three
literal changes. Push/pop order, frame enum, numeric solver, full checked
validation, raw diagnostics, central route, gathering, input/output and timer
contracts are unchanged. No feature, version upgrade, provider, wrapper,
custom container or mirror test is introduced.

The candidate is source-only, uncompiled, unformatted and unmeasured.
No performance/allocator claim is made. Root owns all execution and retention.
Review findings should bind the exact patch and immutable base hashes in the
manifest; reviewers must not edit repository, cache or candidate source.
