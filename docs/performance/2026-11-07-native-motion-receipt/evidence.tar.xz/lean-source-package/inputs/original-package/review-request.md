Please independently review `candidate.patch` against immutable parent `9ddb63f425ca8316bdf483d6297e923c35a16ac3`.

Patch SHA-256: `70656ac0269be13f06be277593ea6a1551703bd6066ac7aaa6786e87b2268eff`.

The author is `/root/mru_rebase_review`. This package is source-only, stationary and unqualified; author's preparation is not an independent approval. No Cargo/compiler/formatter/test/runner/timing was executed.

Focus on the actual Move/Gone race and stale receipt boundaries:

- Only the real UI begin-pass producer reads processed raw input. Expected coordinates and native callbacks must not manufacture receipts.
- Ordered primary state at Move, later release/focus/Escape cancellation, and Gone's non-release behavior must remain correct.
- Pre-injection baseline, current native window/create-attempt/context lifetime, strict Move sequence, exact Child snapshot freshness and exact tree/UI sequence correspondence must all be enforced.
- Empty and repeated passes must not advance the input sequence; lifetime changes must invalidate a previously held receipt.
- The new passive AccessKit node uses the existing selector/bounds boundary. No custom token serialization or general journal is present.

Check all fourteen migrations against their original physical points, pointer assertions, step thresholds, deadlines and stage strings. Hover/press/release and non-motion held-state calls remain on the original state branch. Product route/ACK/guide/Center/release/retirement code should be unchanged.

The three Context/UI plugin tests use no invented native token and do not test the real native ownership branch. Review that branch from pinned public token APIs, then qualify real X11/native lifecycle behavior separately. The tests should exercise actual input processing and AccessKit output, rather than reconstructing the probe state machine.

Report source blockers and limits before Root applies. A compiled/passing CI or a proven product root cause must not be inferred from this package.
