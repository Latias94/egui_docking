**READY for independent source review; not compiled, formatted, tested, or qualified.** Parent: immutable `9ddb63f425ca8316bdf483d6297e923c35a16ac3`. Only this temporary package was written. No Cargo, compiler, formatter, test, runner, timing, profiling, network, delegation, repository/fork/cache or other candidate changes occurred.

Patch: `candidate.patch`  
SHA-256: `70656ac0269be13f06be277593ea6a1551703bd6066ac7aaa6786e87b2268eff`

The four changed source paths are three existing files plus one private module:

| Path under `integration/egui-native-smoke/src/bin/physical_x11/` | Scope |
| --- | --- |
| `app.rs` | +8: one UI-published facts member and one call from the existing semantic probe |
| `assertions.rs` | +3: private module declaration, under the existing Linux-or-test compilation boundary |
| `driver/scenario.rs` | +123/-58: fourteen held-motion call migrations and one common injection/barrier path |
| `motion_receipt.rs` | 202 runtime lines, 225 test lines: UI fact collection, existing AccessKit parser boundary, three Context/UI regressions |

Total: **+561/-58**, including tests; runtime **+336/-58**. No dependency, Cargo, product/core/native runtime, fork, inspection protocol, deadline or input-coordinate changes. The physical entry file remains byte-identical.

**The actual fix.** The existing hover/press/release state diagnostic is unchanged. Fourteen physical held-motion injection sites now call `inject_held_motion`, which captures the latest UI-published native receipt before injection, performs the same physical Move and pointer/button assertion, then enters the original bounded semantic loop. No additional inspection request is introduced. The original overall deadline and three-second barrier deadline calculation remain in the same post-injection position.

The original non-motion held-state checks remain state checks. Root/Child route confirmation, exact pass-through enable/restore ACKs, guide/target/Center validation, release cleanup, retirement and quiescence assertions remain their original implementations. A few pure step/max calculations formerly between injection and its barrier now precede the combined call; no fallible operation or platform action was moved across those calculations.

**One UI producer, bounded latest facts.** The production publisher is the existing PhysicalSemanticProbe's on_begin_pass. It reads the actual processed InputState.raw.events and current pointer state. Native host callbacks do not produce motion receipts. The probe retains one latest record per active viewport, pruning against the actual RawInput viewport inventory. It is not an event history or replay executor.

Records carry actual ViewportId, current NativeOutputToken, a lifetime anchor token, monotonic input sequence, latest Move coordinate and its held-button condition, cancellation sequence, latest Gone sequence, and current pointer/frame/pass diagnostics. A context/window/create-attempt change, inventory removal or counter restart invalidates the prior lifetime. There are no decoded keys, fabricated native identities, expected-coordinate inputs or serialized token strings.

The sequence advances only for consumed Move, primary-button, Gone or explicit focus/Escape cancellation events. A Move records the primary state at its position in the ordered batch; a later release/cancel invalidates it even if another press follows. Gone records loss of hover while retaining the Move receipt and held condition. An empty pass does not advance the sequence.

An outer cumulative frame identifies the one extracted physical RawInput batch; repeated passes in that same frame do not reapply it. The pinned RawInput.take already removes events before repeats; the frame guard also prevents duplicate accounting. The cumulative pass is retained for diagnostics. This is specifically the physical smoke's existing run_ui integration, not a new general manual-begin/end input protocol.

**Semantic correlation stays explicit.** AccessKit adds one passive label containing only the sequence and actual Move bounds. The parser reuses the existing semantic selector and checked bounds helpers; it does not parse native tokens. A successful held-motion barrier requires:

- The existing strictly newer exact-viewport inspection step.
- The same actual native UI lifetime as the pre-injection baseline.
- A Move sequence strictly newer than that baseline.
- The tree's sequence equal to the latest typed UI record, preventing a newer shared fact from being paired with an old tree.
- Actual coordinates, held state at Move and current held state, and no intervening release/cancel.

Baseline capture rejects missing native scope or an unheld UI state. This is observation of a UI-consumed input, not new product command/gesture authority or proof of native presentation. The existing product settlement assertions remain necessary.

Failure diagnostics include the baseline and last typed UI record: actual tokens, last Move/Gone sequences, current latest_pos/button state, and frame/pass. Existing read-error context and pre-cleanup error logging remain.

**Three meaningful regressions, not executed here.** The new module compiles through assertions.rs under the existing `cfg(any(target_os = "linux", test))` boundary, allowing ordinary macOS unit-test builds without compiling the Linux app. Tests install a real egui Plugin, run actual Context/UI passes, and parse actual AccessKit output from the same publisher.

They exercise Move→Gone in one batch; Move then Gone in separate passes; an empty successor and a real discarded/repeated pass; old sequence/tree, no-new-Move, wrong position/viewport, Move-before-press, later release/repress, and focus-cancellation negatives. Test contexts are genuinely unmanaged and have no NativeOutputToken; none is fabricated. These tests establish the UI event and semantic-correlation behavior only. Real native owner/lifetime and routing qualification still requires Root's fork-backed physical run and existing lifecycle/retirement coverage.

The failed CI batch's exact native Move/Gone/ACK order remains unproven. This candidate corrects the demonstrated observation-window assumption and preserves diagnostic evidence; it does not claim that native delivery has been repaired or that CI has passed.

`base/`, `tree/`, `source-pairs.json`, `manifest.json` and `READY.json` bind immutable originals and the complete candidate. `context/` contains the unchanged cfg entry, inspection client, physical injector and manifests. Root owns independent review, formatting, qualification and the unchanged real X11 smoke.
