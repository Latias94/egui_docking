**READY / source stationary / not qualified.** This is the explicitly requested three-line simplification of `/tmp/native-motion-receipt/`, against the same immutable parent `9ddb63f425ca8316bdf483d6297e923c35a16ac3`.

Only this new temporary directory was written. The original package, both independent reviews, repository, fork, cache and other candidates were not modified. No Cargo, compiler, formatter, test, runner, timing, profiling, network or delegation was used.

Full candidate: `candidate.patch`  
SHA-256: `5323fda66a4bed2557d4e67b08b71019eac1eef16a55d9585d70d5bb7aba0b55`

Original tree to lean tree: `cleanup.patch`  
SHA-256: `0d1ac05be7c5c6b3872837aeff4e25855a58126de51822b6a7ca4495b8117238`

The cleanup changes two files by exactly **+0/-3**:

- Delete MotionReceipt's latest `token` field.
- Delete its per-publication assignment.
- Delete the duplicate `baseline.token` filter check.

The actual token is still obtained and filtered to the current UI viewport. Its context/window/create-attempt comparison and lifetime reset rules remain byte-identical. A missing native token resets the record; a present one establishes the strong typed lifetime anchor. The baseline still requires that anchor and a held UI state.

All remaining receipt matching, ordered Move/button/cancellation handling, Gone preservation, frame/pass behavior, semantic sequence/position correlation, fourteen motion migrations, fifteen state checks, deadlines and product assertions retain the reviewed original implementation. The complete 225-line Context/UI regression section is byte-identical.

The full candidate remains four source paths, **+558/-58**: runtime **+333/-58**, tests **+225/-0**. The private module contains 200 runtime lines and 225 test lines. No other source adaptation or formatting was included.

The entire stationary original package is copied under `inputs/original-package/`, including immutable base/tree, original patch/manifest/READY and both independent source reviews:

| Original review input | SHA-256 |
| --- | --- |
| `review-minimal.md` | `7582a46214fa43422ac69e2acfee29b643649d80246dfc24e2fa689daf8f8562` |
| `review-frontier.md` | `2fcd195c7cc7508083ed5c46cd6d174ab7abe4e8b85fcc0d603134a14534d7a0` |

Both found no substantive blocker in original patch `70656ac0269be13f06be277593ea6a1551703bd6066ac7aaa6786e87b2268eff` and independently identified this same redundancy. They are original-source reviews, not executed qualification or a new review of the lean hashes.

`base/` retains the immutable originals and `tree/` contains the full lean candidate. `source-pairs.json`, `manifest.json` and `READY.json` bind both patches, all source pairs and the original review inputs. Read-only patch checks and exact three-deletion reconstruction are recorded separately from execution.

Root owns review, formatting, compilation, tests and the unchanged real physical X11/native lifecycle qualification. The candidate makes no claim of CI success, a unique failed-run event ordering or a repaired native-delivery defect.
