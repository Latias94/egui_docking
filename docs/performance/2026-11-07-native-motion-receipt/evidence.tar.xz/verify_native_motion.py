"""Local native smoke UI regressions; Linux app/physical execution stays in CI."""
from pathlib import Path
import datetime
import difflib
import hashlib
import json
import os
import subprocess
root=Path('/Users/frankorz/codes/rust/egui_docking')
b=Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
out=b/'native-motion-verified'
a=Path('/tmp/native-motion-receipt-lean')
paths=[str(p.relative_to(a/'tree')) for p in (a/'tree').rglob('*.rs')]
diffs=[]
for n in paths:
 original=(a/'tree'/n).read_text();actual=(root/n).read_text()
 target=out/'formatted-tree'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(actual)
 diffs.extend(difflib.unified_diff(original.splitlines(True),actual.splitlines(True),fromfile='author/'+n,tofile='formatted/'+n))
(out/'formatting.patch').write_text(''.join(diffs))
(out/'runtime.patch').write_bytes(subprocess.check_output(['git','diff','9ddb63f','--','integration/egui-native-smoke'],cwd=root))
(out/'added-motion_receipt.rs').write_bytes((root/'integration/egui-native-smoke/src/bin/physical_x11/motion_receipt.rs').read_bytes())
files=paths+['integration/egui-native-smoke/Cargo.toml','integration/egui-fork-workspace/Cargo.toml','integration/egui-fork-workspace/Cargo.lock','crates/dockspace/src/layout.rs']
hashes=lambda:{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
record={'started_utc':now(),'sources':hashes(),'formatting_review':'Root inspected full adaptation diff: production is rustfmt-only, test helper uses mutable FullOutput and explicit textures_delta.clear for renderer-free semantic tests.',
        'platform':'macOS; Linux app/driver execution remains remote CI','checks':[]}
env=dict(os.environ,CARGO_BUILD_JOBS='1');env.pop('DOCKSPACE_BENCH_NO_WORK_COUNTERS',None)
for name,command in [('fmt',['cargo','fmt','--manifest-path','integration/egui-fork-workspace/Cargo.toml','--all','--check']),('physical-units',['cargo','nextest','run','--manifest-path','integration/egui-native-smoke/Cargo.toml','--bin','egui-native-physical-smoke','--target-dir',str(root/'target'),'--locked','--offline','-j1','--no-fail-fast'])]:
 print(name,flush=True);entry={'name':name,'command':command,'started_utc':now()}
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 entry.update(returncode=r.returncode,finished_utc=now());record['checks'].append(entry);record.update(sources_unchanged=hashes()==record['sources'],finished_utc=now());(out/'checks.json').write_text(json.dumps(record,indent=2)+'\n');print(name,r.returncode,flush=True)
 if r.returncode:
  print((out/(name+'.log')).read_text()[-14000:],flush=True);raise SystemExit(r.returncode)
assert record['sources_unchanged']
