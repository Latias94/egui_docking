# Minimal scalar-issuance witness extension

**Recommendation: extend the existing owner-reference test with one real self-center Tabs Move, a wrong-Tabs rejection, and one additional Select on a cloned branch.** No fixture, private mutation hook, or new test framework is needed.

Read-only source assessment, 2026-11-07. No repository changes, compilation, tests, or workloads were performed.

Use `operation/tests/owner_reference.rs:349`, `same_version_index_rejects_changed_and_foreign_issuers_and_retains_unrelated_roots`. Its fixture already supplies two nonempty Tabs leaves in A, unrelated B/C roots, a pre-selection WorkspaceIndex, and a real Select of item 2 in `tabs[0]`. Insert the Move immediately after that Select and before the old-index capture checks.

Capture both operands from the selected workspace:

- Payload: `MovePayload::Tabs`, using `capture_node_source(A, tabs[0])`.
- Target: `DockTarget::Center`, using `capture_tab_target(A, tabs[0])`.
- Execute exactly one Move through `WorkspaceTransaction::from_commands(...).apply(...)`, with `default_policy()`.

Save the post-selection workspace and its current reference before this Move. Assert durable workspace equality afterward, the current reference still equals the saved post-selection reference, and the single outcome is `Moved { changed: false, .. }` with the two original items. The report must also say unchanged. Keep the existing old-index stale-capture checks and the successful `index.after_selection(..., A, tabs[0])`; the latter proves that the predecessor relationship survives the real general transaction.

The control-flow justification is exact: the specialized transaction branch accepts only `MovePayload::Item` (`operation.rs:651–701`), so a Tabs payload goes through `prepare_general_candidate` and `TransactionDraft::finish`. `move_payload` validates the real command, then recognizes source-node equals target-node with a Tabs target (`1789–1806`) and returns a no-op. There is one Moved outcome and durable equality, so finish calls `retain_original_issuance` (`823–828`). The same command with a Subtree payload rooted at this Tabs leaf would work, but Tabs is the clearer intent. Do not use the root Split as a Center payload: a Split cannot be merged into Tabs.

There is a useful limitation: this Move does not mint an intermediate issuance. It tests preservation through the actual restoration path, and catches clearing the predecessor there, but would not by itself detect omitting a predecessor copy if the candidate's predecessor was already unchanged. Do not describe it as demonstrating restoration from an observably different intermediate identity. The existing exact inner-edge no-op at `owner_reference.rs:741` also returns before detachment, and its two-outcome batch bypasses the single-Moved restoration condition. It is not a stronger replacement. If direct restoration of deliberately different metadata needs a focused private-unit assertion, that can supplement the real transaction witness; it must not replace it.

Add the two rejection boundaries at the same test site:

1. After the first Select, call the original index's `after_selection` for `A, tabs[1]`, expecting `StaleNode`. This is a different real Tabs leaf in the same root, so it reaches the recorded Tabs comparison rather than failing foreign-root or membership checks.
2. Once the successful rebound index exists, clone the post-Move workspace and perform a real Select of item 1 in `tabs[0]` on that branch, capturing a fresh source there. The original pre-selection index must reject `after_selection` on this twice-selected branch. The intermediate rebound index should admit it. This isolates one-step lineage from arbitrary ancestry, even though two-item selection/MRU values can return to their initial state.

These checks leave the existing foreign-build rejection and intervening Reorder/Select checks intact. They exercise the consumer through real commands; there is no need to expose the serial, predecessor field, or issuer for these witnesses.

The proposed checked `AtomicU64::fetch_update(...checked_add...).expect(...)` exhaustion policy fits the bounded production scope: it is explicit fail-stop behavior, keeps ordinary Result signatures/error precedence, and cannot recycle identities. Start from a valid unused serial, retain the returned pre-update value consistently, and never reset or reclaim burned candidate serials. This is a newly documented resource-exhaustion behavior, not preservation of an existing recoverable counter error. No broader Result API is required.

Source SHA256:

| Path under `crates/dockspace/src/` | SHA256 |
| --- | --- |
| `operation/tests/owner_reference.rs` | `0d6a8d0f5931976a1561790a48d53273c8f68e5983d6ad25c8ff7989d4aa7199` |
| `operation.rs` | `7586ec06b29b77a794133e0c554d4fcca7a6faa16b8c550b86034ad394175862` |
| `workspace.rs` | `6cbcca776bfca60b1e767dc909121f06ae751110ea1f9fd265ea398da644aa36` |
| `graph/authority.rs` | `89d0d337cdc2365caf62f5dd2d48d6f9132b21c2d4b882e9c24096cc6602a600` |
