# A1 owner reference implementation plan and handoff

Status: STATIONARY COMPILE HANDOFF (2026-11-07); direct rustfmt parsed all owned Rust files. No compilation, test, benchmark or qualification result is claimed. Root exclusively owns Cargo/tests/timing. Semantic acceptance tests and a final cold/publication audit are still outstanding.

## Concrete slice

Keep the existing graph/operation/canonical concrete executor. Add graph-owned opaque exact root references and one generation-aware sparse placement directory (root plus optional parent/index), cloned with the candidate. Builder/import establishes a new issuer after full completion. Common Select/Item Move complete authority from their actual result/frontier; general/cold commands compare actual affected roots and refresh placement between commands. Full canonical completion reports/reconciles its actual changes, including retired/flattened records. No command uses a NodeFingerprint value to authorize execution. The existing real NodeFingerprint remains only frozen geometry/presentation data.

First planned write files: `graph.rs`, new `graph/authority.rs`, `command.rs`, `error.rs`, `workspace.rs`, `operation.rs`, `canonical.rs`, `transaction.rs`, `docking_cost.rs`, and focused `operation/tests/owner_reference.rs` plus existing checked/local/resize tests.

Mechanical production caller migrations inside dockspace/src: `engine.rs`, `engine/splitter_geometry.rs`, `engine/pointer_transaction.rs`, `engine/presentation_authority.rs`, `scene.rs`, `scene/validation.rs`, `drop_resolver.rs`, `runtime/paint/drag_decoration.rs`. Existing tests in `engine.rs`, `engine/splitter_geometry/tests.rs`, `engine/tests/focus.rs`, `interaction.rs`, `workspace.rs`, `drop_resolver/contract_tests.rs` may require reference-versus-real-geometry migration. Exact final changed paths will be listed before READY. No other crate, reference, script, Cargo, repository docs or AGENTS edit is authorized for this lane.

## Scope handoff needed

`layout.rs:648–762` currently treats `NodeSource::fingerprint()` as a full value (including Arc internals). It must instead use `source.reference()` and `workspace.verify_reference`, with indexed membership only an acceleration/current-owner check; remove repeated full fingerprint construction/dedup. `layout/topology_tests.rs` and `layout/override_tests.rs` have corresponding method/field migrations. These paths belong to design_snapshot: this lane will not edit them. Root should assign those exact mechanical changes to the layout owner. Public command geometry facts remain a separate NodeFingerprint and do not regain command authority.

## Audited publication routes

Standalone canonicalize, Builder build, single Select, single Item Move+local finish, each general command prefix, full canonical finish, approved item/surface close, owned follow-up, and exact typed recovery must all complete placement and root issuance before publication/next command validation. No-op/disjoint roots retain refs; a real published ABA may reject older refs even when durable equality returns true. Source and target check independently, policy target facts are derived from actual current state.

## Verification pending

Only direct local rustfmt and source audits will run here. Root must compile, run focused owner-reference/staging/recovery/placement and existing float-frontier oracles, full suites and unchanged timed request/mutation/layout/owned-export comparisons. No reported earlier pass qualifies this implementation.


## First compile integration handoff

All known command-source/target fields and read sites inside this lane now use opaque RootReference. Actual geometry NodeFingerprint remains in scene/index/presentation ownership. The command-only for_command_reference/include_command_reference rebuilding path was removed. The request capture in docking_cost.rs now uses the same owner capture API inside its unchanged request timer.

Workspace carries one SparseSecondaryMap for generation-aware actual node root/parent/index. Direct roster transitions publish their attachment changes before subsequent parent queries. Local Item canonical completion erases retired directory entries, reassigns the actual root node and updates only changed surviving direct rosters. The common Select/Reorder/Resize/Item paths renew exact refs without whole-root proof snapshots. Full general/cold paths still use actual temporary before/after values and full canonicalization.

The only transition metadata besides exact root issuance is a weak predecessor plus selected tabs on an actual Select issuance. WorkspaceIndex::after_selection consumes it to reject an unrelated/foreign indexed root rebind. Weak ownership prevents retaining a chain of prior owners. No future geometry permission markers or origin/birth tags are allocated.

`WorkspaceTransaction::apply_with` and its crate-private prepare counterpart now share TransactionDraft::push_command and TransactionDraft::finish with the literal Vec path. `WorkspaceTransactionStage::push` runs a constructor against TransactionCapture, a narrow root/node/MRU/capture facet with no Deref/AsRef/Workspace conversion. First error is terminal even when the editing closure ignores a push result. One final prune/canonicalization/item reconciliation covers the batch, and publication consumes the actual candidate rather than replaying commands.

Exact changed lane files at this handoff: graph.rs, graph/authority.rs, command.rs, error.rs, workspace.rs, operation.rs, canonical.rs, transaction.rs, docking_cost.rs, engine.rs, engine/splitter_geometry.rs, engine/splitter_geometry/tests.rs, engine/pointer_transaction.rs, engine/tests/focus.rs, scene.rs, scene/validation.rs, drop_resolver.rs, drop_resolver/contract_tests.rs, runtime/paint/drag_decoration.rs, operation/tests/split_resize.rs. Other layout paths are snapshot-owned; engine/tests/recovery_policy_authority.rs and engine/tests/native_lifecycle.rs are explicitly excluded and can be assigned to minimal. No changes in other crate/tests/docs/Cargo/scripts/AGENTS were made by this lane.

Pending acceptance: actual-stage net-zero selection/MRU; ignored-stage-failure; cross-branch rejection versus actual-stage success; late-output failure rollback and one-final-normalization behavior; independent placement oracle against real child rosters; stale same-version/foreign WorkspaceIndex; closed publication routes, error ordering and both f32 frontier regressions. Existing raw-storage test fixtures that mutate a canonical Workspace directly may need conversion into actual owner transitions rather than implicitly trusting stale authority.


## Acceptance source handoff (second check)

Status: STATIONARY for root's second compile integration pass. Fixed the two EdgeTarget field shorthand errors diagnosed by first-check.log. Added operation/tests/owner_reference.rs (ten real behavior tests), registered it in operation.rs, and connected its independent root/child-roster placement oracle to every successful existing local Item Move matrix case. The oracle runs after the work snapshot so it cannot inflate the claimed common-path zero counts.

Coverage now includes: clone inheritance versus independent Builder origin; literal single-command no-op/canonical no-op; committed ABA; actual-stage Select away/back with exact MRU and false final changed report; predicted-branch rejection; ignored stage failure plus no later constructor execution; transient empty source retained until one final canonicalization; legal and zero-width late-output rollback; same-version index capture on every source/target shape; explicit selection-rebind lineage; foreign issuer; unrelated-root rebind rejection; complete-generation recycled primary node; cross-root subtree transfer; staged live-but-unrooted merged residue; and selection versus resize structural/topological geometry permissions. Common capture plus Select/Item Move and the existing whole Item matrix assert zero full proof builds/visits. Existing drop/drag work-count expectations were migrated to exact-owner cost while clone/target/semantic assertions remain.

Additional actual changed files since first handoff: operation/tests/owner_reference.rs (new), operation/tests/local_item_move.rs, operation/tests/checked_move.rs. workspace.rs after_selection now checks other indexed roots' exact owners before retaining their facts. No layout files or minimal's three fixture files were edited. This lane ran only direct rustfmt, searches and source inspection, never Cargo/tests/timing. Root's previous first check failed before test typechecking, so no pass is claimed. Acceptance source hashes are in owner-ref-verified/acceptance-source.json.

Root should next run quick --tests --allfeatures check, then these owner_reference tests and the existing numeric/local/general/close/recovery suites. Further compiler or behavioral diagnostics must be resolved before qualification. Production hot-path and cold publication review is still needed against the now-testable slice; this handoff is not a performance or correctness qualification.


## Affected-roots repair handoff

Status: STATIONARY after root explicitly stopped the 118.593-second regressed targeted process. Root's retained pre-cold-fix-targeted.log is the authority for the prior 81 passes, one opaque error-value comparison failure and one intentionally stopped recovery test; this lane did not execute it.

The cold scope now matches every WorkspaceCommand explicitly. Rehome/Promote snapshot only the source root. Tabs/Subtree Move snapshot source+target, with existing deduplication. Open snapshots target. Attach snapshots the new root; Create/Install snapshot new root plus an optional Move donor. Select/Reorder/Resize/Item Move use the existing concrete hot completion. Root/surface retirement uses the existing concrete owner deletion/unrooting. Rect/roster/raise operations do not change exact root authority and take no snapshot. No command snapshots or refreshes all roots.

The original recovery fixture still runs at 16/128/1024 contained roots and retains its existing constant whole-item reconciliation scan assertions. It now also bounds real fingerprint builds/node visits linearly in command count for these singleton-root fixtures, permitting the single final whole-forest canonical pass. This detects the accidental per-command whole-root loop without reducing workload or changing semantics.

Mixed batch comparison now compares typed stale-command index/role/node/expected issuance and the actual root identity, while independently asserting each expected is stale. It does not require two independently minted actual refs to compare equal. Successful workspace/report equality and rollback equality remain unchanged.

One added behavior case, `a_new_root_and_its_donor_issue_actual_refs_before_the_next_prefix`, checks CreateContainedRoot with moved Item content followed by actual-candidate capture in the new root and changed donor, plus untouched-root ref preservation. There are now eleven owner-reference acceptance tests.

Remaining cost: the final general canonical completion snapshots and refreshes all roots once, and its presentation_in_storage lookup is currently linear in surface/contained roster size for each root. Each affected-root cold snapshot/refresh can also do that lookup. The cubic per-command/all-roots nesting was removed; a remaining quadratic carrier-discovery factor is not claimed solved. No further runtime optimization was bundled.

Changed paths in this repair: operation.rs; operation/tests/local_selection.rs; operation/tests/owner_reference.rs; surface_recovery.rs (test assertions only). Direct rustfmt parsed these files. No Cargo/test/timing/Git write was run by this lane. Exact current repair hashes are in owner-ref-verified/cold-fix-source.json. Root should rerun the preserved targeted suite and recovery scale test before qualification.


## Four full-workspace failures: source-based repair

Status: STATIONARY for root's four-test retry. Runtime behavior was not changed in this repair. Root's full-workspace log reports 2223 tests, 2219 passed and four failed; the fixes below are not yet executed by this lane.

The two background baselines execute `prepare_surface_background_command` -> `InstallMainRoot { content: Move(Item) }` -> cold effect classification -> general full canonical finish. The maintained requirement index itself is reused, but the cold path still captures actual NodeFingerprint values for before/after effect classification. These values never authorize commands.

With R original roots, S original source nodes and V original total nodes, the scale fixture does one donor before capture, two after captures (donor plus newly born root), then two complete snapshots of R+1 roots at canonical finish. Builds = 3 + 2(R+1) = 2R+5. This fixture's first single-item source leaf becomes empty; its binary parent collapses. Adding the new root leaf therefore leaves V-1 final nodes. Visits = 2S + 1 (birth) + (V+1) before normalization + (V-1) after = 2S+2V+1. The test now asserts the actual prepared command and its final node count independently, uses that source-derived formula, and retains the fixed baselines:

| Panes | Roots | Distribution | S | V | Builds | Visits |
| --- | --- | --- | --- | --- | --- | --- |
| 16 | 1 | balanced | 31 | 31 | 7 | 125 |
| 128 | 8 | balanced | 31 | 248 | 21 | 559 |
| 128 | 8 | hot-root skew | 226 | 247 | 21 | 947 |
| 1024 | 32 | balanced | 63 | 2016 | 69 | 4159 |
| 1024 | 32 | hot-root skew | 1922 | 2015 | 69 | 7875 |

The real engine background fixture has two original one-node roots and adds a third. The donor retains one item, so no node retires: three cold root-value captures plus six canonical before/after root values give exactly 9 builds/9 node visits. The exact test retains its geometric winner/index and transaction assertions. Other native lifecycle fixtures remain untouched.

The real ordinary tab press performs no cold transaction, no index refresh and no value proof capture: its two source captures share actual owner issuance. Its baseline is 0 builds/0 visits while all clone/arming/watermark/release assertions remain.

`append_item_to_root`, a test-only helper, now runs a real checked WorkspaceCommand::Open against a current captured target. It no longer edits raw canonical storage or bumps metadata manually. The existing changed-source close must still return the exact StaleSurfaceRoster precondition and roll back; unrelated-root changes still allow close. Neither assertion was weakened.

This explicitly records a negative A1 limitation: cold root creation and general canonicalization retain/add full value snapshots. They are effect classification costs, not command proof costs. Common Select/Item Move zero-proof work must not be extrapolated to these background paths. An eventual canonicalizer changed-root receipt can replace this work in a separate measured slice; no such runtime change was bundled here.

Only drop_resolver.rs (test baseline), operation.rs (test helper), engine/tests/host_authority.rs (press work baseline) and the one authorized engine/tests/native_lifecycle.rs test were edited. Direct rustfmt parsed them. Hashes: owner-ref-verified/workspace-four-fixes-source.json. No Cargo, test, timing or Git write was run by this lane.
