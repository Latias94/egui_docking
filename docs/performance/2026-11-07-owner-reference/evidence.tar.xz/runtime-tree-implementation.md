# Sealed runtime-tree compiler implementation

Base: qualified checkpoint `91f42ce`. Status: READY / SOURCE STATIONARY for the linear compiler and exact-owner-reference layout migration. Root owns all compilation, tests and timing. No Cargo, build, test, benchmark, timing, Git write or global formatting was run by this lane.

## Changed ownership

Only these four authorized repository paths were edited:

- `crates/dockspace/src/layout.rs`
- `crates/dockspace/src/layout/topology.rs`
- `crates/dockspace/src/layout/topology_tests.rs`
- `crates/dockspace/src/layout/override_tests.rs`

Root additionally authorized override-test migration after the common lane began writing its exact-owner Interface. This lane read the actual new `command.rs` and `workspace.rs` definitions before applying the migration. No common-lane repository file was edited. Root should wait for both lanes' stationary handoffs and verify the combined tree; this report does not propose a checkout, rollback or isolated pre-owner comparison.

## Production Implementation

`RootLayoutTopology::compile` now accepts `&Workspace`. It relies on the graph owner's sealed tree invariant, rather than accepting arbitrary raw shared storage and rediscovering parent/cycle ownership.

Each split reserves its final contiguous child slots on entry. Enter frames carry the exact parent-child slot, and each new child immediately fills it with its assigned dense row. Split metadata, durable weight bits and gap ranges are copied/assigned once. The Exit frame composes measurements from those already-recorded child rows. It does not re-read the split from Workspace and does not join each child NodeId through a HashMap.

Measurements are directly owned in one `Vec<SubtreeMeasurement>`. The existing valid zero measurement supplies temporary split placeholders; the iterative schedule completes every child before its parent's Exit reads that slot. No visited/active/completed table or whole-table Option conversion exists in the production compiler. Each node still uses the ordinary full-generational Workspace getter when entered. The requested root still has its existing missing-root check.

The remaining topology `HashMap`, `CheckedCompileFrame` and `Vec<Option<SubtreeMeasurement>>` are behind `cfg(test)` inside `compile_draft`. `project_draft` calls that checked Adapter; production `measure_root` calls the sealed compiler directly. Raw DAG/cycle/cardinality/missing-node error priority and completed-subtree behavior remain on the old checked traversal, not on a new general validation framework.

Private constructor and directory-finalization helpers avoid copying the same storage/ordering setup between the two compilers. Directory ordering still uses actual `NodeId::Ord` comparison sorting. Its complete generational IDs and sorted lookup/iteration Interface are unchanged. No radix, slot-only map, arena-sized per-root directory or preorder exporter was added.

## Preserved calculation and output contracts

Leaf answers are read at the same depth-first point. Split minima/maxima are composed in the same postorder with the same ordered child operands. Preorder assignment of private flat ranges changes only slab offsets and split ordinals, not any observable node/split outcome or operation ordering. The immutable input borrow means copying durable weights on entry rather than exit cannot observe a different value.

The solver, floating-point grouping, bounds cursor/gap construction, metrics, leaf BTreeMap input, numeric override validation order, warm hint matching, complete owned output arrays, old-output lifecycle and benchmark/export paths were not modified. `layout/reference.rs` remains untouched and independent; reference traversal and numerical answers do not pass through either production compiler.

The structural compiler is O(reachable nodes + child edges) with root-local storage. Full cold layout still includes the unchanged identity comparison sort, leaf BTreeMap queries and actual constrained solver work; this report does not claim the whole operation is linear or meets the twofold performance goal.

## Exact-owner-reference migration

The actual common-lane Interface used by the layout code is:

```rust
NodeSource::reference(&self) -> &RootReference
Workspace::verify_reference(
    &self, root: RootId, node: NodeId,
    expected: &RootReference, role: ReferenceRole,
) -> Result<(), CommandError>
WorkspaceIndex::verify_reference(
    &self, workspace: &Workspace, version: WorkspaceVersion,
    root: RootId, node: NodeId,
    expected: &RootReference, role: ReferenceRole,
) -> Result<(), CommandError>
```

Every override independently verifies its root/node and exact reference through the live or indexed Interface. The indexed implementation checks its version/current owner and then the supplied source reference against the actual Workspace owner. Layout no longer creates a full NodeFingerprint, reads fingerprint Arc internals, maintains a pointer-dedup HashSet, or caches one rebuilt root fingerprint as command authority. The old `verify_split_override_source` helper was deleted.

The source-root mismatch remains first, followed by exact source authority, duplicate override, actual split kind, cardinality, then numeric normalized-weight checks. In particular, an independently stale second source is rejected before the duplicate check; sharing a valid root reference never skips a missing/foreign node check. Old output ownership, real retained geometry fingerprints and all numerical oracle code are unaffected.

Override tests now construct `NodeSource { reference: ... }`, exercise valid shared-root references and independently stale duplicate sources, and retain missing/foreign membership and batch error-priority cases. They assert zero geometry fingerprint builds on both public and indexed projection. The former distinct-value-fingerprint-Arc assertion was replaced with actual owner-reference equality for two independently captured current nodes in the same root; that old incidental representation is no longer command authority. The existing topology/semantic independence test verifies the old target via `old_target.reference()` against the refreshed owner.

No compatibility accessor, owner token generation in layout, alternate executor or extra dependency was introduced. The independent reference file was not edited; it continues to share only the existing command-override validation adapter while owning its old traversal/output/numerical implementation.

## Behavioral regression

Added one registered module test:

`layout::topology_tests::sparse_recycled_tree_keeps_ordered_identity_and_cold_warm_oracle_results`

It keeps a few old-generation leaves among 512 initial slots, retires the others, inserts recycled-generation nodes and two opposite-axis splits, deliberately orders children differently from identity/arena order, and retains a separate root at a high slot. It verifies:

- the entire cold constraints projection against the independent frozen oracle;
- actual NodeId-sorted key order despite different preorder;
- complete reachable node-constraint and split counts;
- exclusion of every retired generation and the other root's node;
- cold-then-warm minimum projection against the complete independent oracle;
- Arc identity reuse of the actual topology between those two minimum calls.

The actual registered 10,000-depth owned projection/drop test is unchanged and remains in `layout/topology_tests.rs`. Existing full-tree property, live metrics/minima, same-version legal topology edits, override error-priority and raw malformed diagnostics tests remain registered. No legacy integration file is counted as executed evidence.

## Permitted local checks and next gate

Direct `rustfmt --edition 2024 --config skip_children=true` succeeded on the four changed files. Limited `git diff --check` found no whitespace errors. A source audit confirmed only the test-only compiler retains the visited HashMap and Option conversion; production Exit reads private rows only. No compiler, test or performance result is claimed.

Root should compile when its shared core Interface is stationary, then run the registered topology/raw diagnostic/override tests including the new sparse-recycled case and active 10,000-depth case before ordinary qualification. Borrow/type inference and concrete combined integration still require root's compilation. The exact-reference methods above were read from common's actual source, but combined type/borrow integration still requires root compilation after common also stops. No independent oracle numeric Implementation should be changed to resolve an authority-caller mismatch.

## Source identity at stationary handoff

Aggregate SHA-256 uses sorted relative path bytes, NUL, then complete file bytes for the four changed files:

`6a32a530ea9fd01ba933a4275e289c5a7c404d72114c490fd04e84693d237331`

- `crates/dockspace/src/layout.rs`: `354f015c74a2e942d006d7c1e510a26df3f43ebf49e42bf0763687ab38fdd44f`
- `crates/dockspace/src/layout/override_tests.rs`: `dc06845930e2379862be78d66b9a6041728c1f7428a6ec088d03191b9d813cc9`
- `crates/dockspace/src/layout/topology.rs`: `7bc045245503a4ebd329349e6cf92676c40bdb78201a04069ca6fa5f0c230fb1`
- `crates/dockspace/src/layout/topology_tests.rs`: `bb8611a47a0b8c4d804165a2c721cbca62de7bd3461fe1cc5b6fce1bfa44ee64`
