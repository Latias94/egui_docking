# Owner-issued root references after sealed Workspace

DESIGN ONLY. This is a proposal for the next decision after root's complete combined comparison; it is not implemented, compiled, timed or qualified. Scope is the current sealed Workspace/local Item Move/dense layout tree. No repository change, Cargo, benchmark, timing, executable, Git write or child agent was used. `codebase-design` and the Rust ownership guidelines informed the Interface sketches below.

**Recommendation: retain the flat arena first, make root issuance and node ownership committed graph state, and replace command fingerprints with one opaque exact root reference. Measure that slice before partitioning actual root storage. Keep the two existing geometry-comparison meanings distinct; initially they can remain comparisons of real frozen presentation facts. Do not introduce an old-command fallback.** A later immutable-root representation can remove the remaining whole-workspace clone, but requires a larger read Interface migration and a new measurement decision.

The objective remains complete real-operation p50 at most twice the pinned ImGui operation, or an independently supported structural limit. Neither design predicts that result. In particular, complete projection/export, candidate cloning and real payload/policy work remain costs after reference capture becomes cheap.

## Current work and the useful Seam

Current source facts:

- `command.rs:42–159` stores a full root fingerprint with root-node/central/presentation and per-node items, selected, MRU, children and weight bits. Cloning an existing fingerprint is an Arc clone. **Constructing one** copies all those sequences and discovers root membership.
- `workspace.rs:127–180,857–953` constructs those records for every root in a complete WorkspaceIndex. Public `capture_*` uses `capture_reference → root_fingerprint → build_root_index` (`:669–774,810–855`). Command-local preparation reconstructs the distinct source/target roots (`:84–124` and `operation.rs:1063–1115`); it then compares full values.
- `docking_cost.rs:154–199` begins every non-resize request with complete `WorkspaceIndex::build`, inside the request timer at `:349–353`. An optimization that retains that build but prewarms it in fixture setup would change the workload. The new capture must actually stop doing that work.
- `graph.rs:363–418,800–803` now seals committed Data behind graph and its child Implementations. Builder owns raw Data. This gives a real owner which can issue a reference once and make every publication obey it; the public numeric WorkspaceVersion is no substitute for this ownership.
- `operation.rs:1611–1682` already fuses checking and execution under one exclusive candidate borrow. Keep this locality; do not expose a reusable “checked move” which can outlive the candidate state.
- `drop_resolver.rs:992–1055` already owns live target rebinding. `engine/presented_input.rs:73–107` separately admits old actually presented receivers with topology comparison plus explicit current/transient weight checks. These are different privileges and must remain so.

The proposed Module is the **committed graph owner**, with a small Interface for issuing/checking a root/node reference and performing a checked edit. Source/target capture, standalone checked transactions and engine execution are real callers of that Interface. The in-process command Adapter and the egui/headless presentation Adapter must reach the same owner. There is no reason to introduce a trait, mock authority provider, or second rebinding Module merely to use this Seam. Its Depth comes from keeping membership, exact staleness and publication together; its Locality should replace scattered whole-root revalidation.

## Contract shared by both architectures

### Three comparisons, not one version test

| Comparison | Included state | Permitted use |
| --- | --- | --- |
| Exact command reference | Origin/root incarnation, root node, central identity, presentation owner, all node identities/kinds, child and item order, selected/MRU, durable weight bits | Source/target command staleness. Selection or ratio changes reject the older literal command. |
| Presentation structure | Same origin/incarnation, root node, central, presentation owner, node/kind/member/order facts and durable weights; ignores selected/MRU | Existing resolver may rebind an admitted frozen location after selection. It cannot authorize different split ratios. |
| Presentation topology | Same facts as structure but also ignores durable weights | Receiver admission during resize; **still requires** explicit presented durable/transient weight and owner/rect checks. It is not a command proof. |

The new process-local origin/incarnation check deliberately makes independently rebuilt equal values and published ABA branches potentially stricter than the old value protocol. Within one owner lineage, Select/MRU must not spuriously change structure/topology, and Resize must not spuriously change topology. An unrelated-root edit must leave this root's issuance intact. Equal no-op commands must not invalidate it.

Geometry equivalence is not a measurement answer: selected minima, intrinsic/tab-strip/Unavailable values, reveal/scroll, effective bar/close capabilities and current drop policy remain their existing checks. A geometry reference is also not a presented-output ticket, host acknowledgement, engine authority domain, native binding or permission. No new root reference may make stale or unpresented output admissible. Within a changed category, opaque equality may conservatively reject a value-identical published round trip; the expressly permitted Select/Resize sharing and exact zero-operation sharing above are not optional.

### Opaque references and ordering

The illustrative external Interface preserves familiar capture calls while replacing their hidden proof. All reference fields and constructors belong to the owner; crate siblings must not be able to assemble `root + node + arbitrary proof` literals.

```rust
pub struct RootRef { /* one private owner-issued exact root handle */ }
pub struct NodeSource { /* private RootRef and NodeId */ }
pub struct ItemSource { /* private NodeSource and ItemId */ }
pub struct TabTarget { /* private NodeSource */ }
pub struct EdgeTarget { /* private NodeSource, scope, edge, fraction */ }

impl Workspace {
    pub fn capture_item_source(
        &self, root: RootId, tabs: NodeId, item: ItemId,
    ) -> Result<ItemSource, CommandError>;
    pub fn capture_node_source(
        &self, root: RootId, node: NodeId,
    ) -> Result<NodeSource, CommandError>;
    pub fn capture_tab_target(
        &self, root: RootId, tabs: NodeId,
    ) -> Result<TabTarget, CommandError>;
    // Existing inner/outer edge capture shapes remain, without a full value proof.
}
```

A caller still captures the request **inside** its actual operation:

```rust
let source = workspace.capture_item_source(source_root, source_tabs, item)?;
let target = workspace.capture_tab_target(target_root, target_tabs)?;
WorkspaceTransaction::from_commands([WorkspaceCommand::Move {
    payload: MovePayload::Item(source),
    target: DockTarget::Center(target),
}]).apply(&mut workspace, &current_policy)?;
```

No caller needs a complete WorkspaceIndex just to issue this request. Internal root views can avoid repeated BTree root lookups, but are ordinary borrows of the same owner, not independently trusted snapshots.

For an executing Move, retain current arrangement-lock ordering, then validate source before target. For each role check live root, live complete generational node and its current root membership before exact issuance. Then check item/node kind, scope/gap semantics, target relation and policy in the existing semantic order. The same-root target must check **its own** RootRef even when source validation succeeded; sharing a root is not permission to skip that comparison. A missing/recycled node is not accepted because its old root token still exists.

`surface`, `central` and `rule` should cease to be caller-assembled fields on command targets. Once exact target reference validation succeeds, derive these facts from the current candidate: the selected item represents the pane rule, with the existing empty-central Root rule exception. An outer edge still derives the current root node and uses a Root rule. A private borrowed checked target can feed policy and execution under the same borrow; it cannot escape as an authorization object. This deletes the possibility of a “current proof + forged policy fields” command, instead of retaining redundant fields and a second full proof comparison.

Every policy evaluation uses the policy supplied for **this execution**. No RootRef stores an Allow result. A policy-only change does not have to stale a graph reference to prevent bypass: check arrangement, drag-source, tab-bar when applicable, drop/presentation/resize rules again. Same-pane no-op still runs those policy checks. Exact surface-recovery authority bypasses policy only through its existing typed program; it does not bypass source/target staleness.

## Architecture A: flat arena with committed root issuance and ownership

This is the recommended first architecture. It changes the owner contract without replacing node storage, numerical layout or the public transaction shape.

### Committed state, not a proof cache

Move authority-bearing state into one closed owner Implementation:

```rust
// Private to graph's owner Implementation.
struct RootIssuance {
    root: RootId,
    birth: Arc<RootBirth>,        // origin + this root incarnation
    topology: Arc<TopologyId>,
    structure: Arc<StructureId>,
    // The Arc<RootIssuance> allocation itself is the exact identity.
}

struct RootState {
    record: RootRecord,
    presentation: RootPresentationOwner,
    issued: Arc<RootIssuance>,
}

struct OwnedNode {
    root: RootId,
    value: Node,
}
```

The primary generational arena's node slot should carry normative root ownership, or use one owner-private generation-aware directory with the same invariant. Prefer recording ownership in the primary slot when doing the migration: lookup becomes one actual slot lookup, no per-root member HashSet and no per-node Arc. An independently mutable membership cache next to public raw writes is **not** this architecture. If a temporary separate table is used to reduce migrations, it must be part of the committed owner state with eager updates by the same edit methods, never lazy, invalidatable or trusted only by an engine version. A single SparseSecondaryMap avoids per-root highest-slot arrays; its hash dictionary still checks exact keys and is not a probabilistic fingerprint.

The central invariant is: every live committed node belongs to exactly one declared root, its primary ownership agrees with the root's reachable tree, and RootState contains the presentation carrier enforced by the presentation roster. Builder/import establishes this invariant while performing the existing real whole-forest completion; runtime edits maintain it. This is not a stored copy of selected/MRU/children/weights, not a cached validation success, and not a dirty bit. There is no “build a new fingerprint later if uncertain.” Query capture only reads this actual owner state.

`RootRef` contains the opaque Arc issuance (and its root/birth), with no tree or workspace payload. Pointer equality is used only on still-owned private allocations; both compared handles keep the allocations alive, so allocator address reuse cannot resurrect an old authority. No address or counter is serialized. Do not derive marker-value equality: two empty marker structs must not compare as the same issuance. Any diagnostic ordinal is non-authoritative and must not replace opaque identity.

`root membership` lookup and command exact check are constant work after a BTree root lookup. Capturing an ItemSource additionally checks the actual pane's item membership; that may scan its tab list, which is legitimate pane-local work. Pane rule derivation reads the actual selected item. Capture allocates no root-sized array and no per-reference identity: it clones a handle already held by the root.

### Closure and why safe Rust is enough for the intended threat

The existing module move is necessary but not the entire implementation: today graph's child `operation.rs`/`canonical.rs` can write `workspace.storage` directly. Tokens must not be added beside those same uncontrolled write sites with an instruction to remember to bump them.

Make the authority-bearing state private to a deeper owner module and give its callers no `&mut WorkspaceData`, `DerefMut`, `node_mut`, mutable root map, public token constructor, mutable issuer Arc or raw-completion constructor. Raw Data remains a Builder/Candidate input, not a committed Workspace. Re-export immutable reference types from `command.rs` if their constructors need the deeper privacy scope.

The owner applies edits through concrete mutation methods which know what changes, for example selection, split weights, item transfer, subtree ownership transfer, root presentation and local canonical repair. These methods perform data updates **and** issuance/ownership updates before returning a command result. A private command-local patch may record actual old/new written fields; it must not be an externally writable “dirty roots” flag. Only the owner can seal/publish the result.

Safe Rust then prevents caller code from forging references, altering the immutable state under a borrowed validation, writing around the owner or carrying a private checked borrow across mutation. It does **not** mathematically prove that an owner method classified a change correctly. That small implementation remains the trusted invariant owner and needs behavioral counterexamples. If runtime code still receives arbitrary mutable storage and can publish without the transition methods, this architecture has not been implemented, regardless of passing happy-path tests.

### Change matrix and equal no-ops

For each actually changed root:

| Completed change | Exact | Structure | Topology | Membership/placement action |
| --- | --- | --- | --- | --- |
| Selected or MRU only | New | Retain | Retain | No node owner change. |
| Durable weight bits only | New | New | Retain | No node owner change. |
| Item order/membership; node kind/children/order; root-node or central identity | New | New | New | Maintain owners for added/removed/transferred nodes. |
| Root Main/Contained/surface/floating **owner identity** | New | New | New | Update the root's normative presentation carrier. |
| Contained rect, z/roster order, bounds, scroll, config or policy only | Retain root graph issuance | Retain | Retain | Existing rectangle/roster/output/config/policy authorities handle these facts; old root fingerprints did not include them. |
| Equal operation, including checked Move no-op | Retain | Retain | Retain | No ownership update. |
| Retired root | Remove | Remove | Remove | Delete its node ownership; a reused RootId gets a new birth. |

Do not decide changes from the command tag or a global item multiset. A two-root item transfer preserves the workspace multiset but changes both roots, so both roots receive new issuances. A same-root transfer renews that root once, not source first and then target again. Root node identity is significant even if the normalized geometry/value appears equal.

Conversely, the current same-pane Center move, TabGap `from == to`, singleton self-edge and exact simulated sibling-edge no-op must retain issuance after all stale/policy checks. For Select compare actual selected and MRU; for Resize validate the entire batch first and change only roots with a changed f32 weight vector. Compare before invoking a COW detach or minting an identity.

Structural commands can do transient detach/reinsert/flatten work that cancels out. Compute the actual normalized command-local patch before installing its final state, or retain before-images for just the affected fields and compare their final values. A zero net patch reuses the old issuance. Do not bump on the first low-level write and later try to recover an old identity by value. The existing exact-noop predicates and current local-completion/general oracle are useful starting points, but the effect must account for root-node IDs, actual normalized weight bits, selected/MRU and presentation owner, not merely `CommandOutcome::Moved.changed` after the fact.

This is O(changed nodes/child-and-tab sequences + changed frontier) authority maintenance. Subtree transfer across roots must update every moved node's ownership, O(moved subtree); it is not O(1). Existing whole candidate cloning still costs O(workspace). Existing canonical fallback may visit the whole candidate; this slice does not promise to remove that work. Crucially it does not reconstruct a full root-value proof before and after every mutation.

### Clone, origin, candidate and every staged command

The lifecycle must be explicit:

1. A fresh Builder/import creates a new origin and root births. A runtime-owned clone of an unchanged Workspace preserves root issuances and generational IDs. Its durable `PartialEq` still compares durable values, not issuance bookkeeping.
2. The current transaction candidate clone initially inherits those exact root issuances, so a request captured on the original can validate on the untouched candidate. No comparison of `&Workspace` addresses or numeric WorkspaceVersion is involved.
3. Check one command against its current candidate. Source and target are independently checked before writes. Execute/finish that command, install the actual changed membership/presentation facts and root issuances, then discard any borrowed checked facts.
4. **Before checking command i+1**, the candidate must already expose the issuances produced by command i. A Select in root A makes old A source refs stale; a Move into B makes old B target refs stale even for a fresh source in C. An unaffected C ref remains valid. There is no transaction-wide “the proof came from my origin” exemption.
5. A no-op prefix changes no issuance, so a later original ref remains usable. A single `ResizeSplits` command validates every split against the pre-command state before changing any weight, including multiple splits sharing a root; do not invalidate the second split halfway through that one command.
6. General batches may stage noncanonical empty/singleton/same-axis forms as today. Keep them private Candidate Data. The ownership directory and current issuer at each inter-command read must nevertheless describe the current forest. Canonical repair and final publication install their additional semantic changes through the same owner methods. A staged object is not a newly public valid Workspace merely because it has an origin.
7. On any later rejection/normalization failure discard the candidate and all its new issuances. The original and its old valid refs remain unchanged. A failed owned follow-up must not return a publishable partially edited state. No authority is changed in a shared mutable Arc.
8. Publish moves the already-completed candidate into the Workspace; no hidden validation/proof rebuild is deferred to the next capture. Clone branches that diverge get different private issuances, even when they later reach equal values; this deliberately rejects value-identical published ABA.
9. `into_builder` transfers Data to an unissued Builder. Rebuilding arbitrary raw Data/import is an explicit new-origin publication, not an authorized way to preserve runtime root stamps. Engine replacement invalidates old presented-output authority through its existing epoch/domain protocol and should not relabel raw Data as the old issuer. No serialization can recreate a RootRef. An exact unchanged Workspace clone is different from independently rebuilding equal Data.

For `WorkspaceIndex` methods that accept a workspace argument, version matching alone is insufficient: either hold only an owner-issued immutable read view, or verify the indexed root issuance against the supplied owner's current root before issuing/checking refs. Same-engine-version legal mutations must fail an old index's exact-authority operation. Layout reuse stays its own structurally matched acceleration; it grants no semantic authority.

### Two geometry migration slices within A

**A1, smallest useful measurement slice:** use opaque **exact** refs for every command/source/target, authoritative node-root ownership for capture/validation, and remove fingerprints from the command Interface. Keep the existing **presentation facts**/comparison Implementation for geometry admission where it already runs during scene derivation. Its scene-only basis should omit selected/MRU, which are not operands of either geometry comparison; selection binding remains separate. Do not copy that obsolete exact-state payload merely to keep a familiar type name. The resolver compares frozen/current geometry bases from the scene/index, then issues a current exact target ref. It no longer extracts a full proof from the newly rebound command target. No old literal command can fall back to value equality.

This is not two command protocols: one exact RootRef is the only command authority; the retained scene basis is an output/geometry fact and cannot execute a command. It is not precomputing request proofs in Builder: Builder stores actual membership/issuance, and the request performs real membership/item/capture work within its existing timer. The remaining scene geometry snapshots are disclosed product costs, and may still be O(root). There is no request-specific prewarm.

A1 needs only exact-root change ownership, reducing the risk of migrating every geometry admission rule simultaneously. It still requires coverage of **all** committed mutation methods and per-command staging; implementing only the benchmark's Item Move while other writes silently reuse an issuance is not a viable partial slice. General commands may use their existing full normalization/validation work to complete owner state, but may not keep an old exact-value authority fallback. For a bounded first patch, derive actual changes from its existing mutation primitives/command-local patch; do not add whole-root before/after fingerprint construction.

**A2, only after A1 evidence:** add the structure/topology identities to RootIssuance and replace the geometry comparisons with opaque geometry refs. Preserve the exact change matrix above. Old plans still need real frozen **effective weight inputs** for the weight exceptions in `presented_input.rs`; tokens alone do not contain them. Reuse complete projection/resize records or one plan-owned weight basis captured during actual complete compilation. Do not make `TopologyId` equality a replacement for explicit weight/owner/rect/output checks. Avoid retaining items/MRU/children solely to reconstruct an obsolete command fingerprint.

## Architecture B: immutable actual root owners with factored data

B makes the identity source the actual immutable root value, rather than a small issuance record next to flat mutable storage. It is a larger but viable replacement if the combined/A1 data show the remaining whole candidate clone dominates.

An example representation is:

```rust
struct RootValue {
    geometry: Arc<RootGeometry>,
    selection: SelectionRows, // selected and exact MRU; actual authoritative values
}
struct RootGeometry {
    shape: Arc<RootShape>,
    weights: WeightRows,     // actual durable weights, not a copied proof
}
struct RootShape {
    root_node: NodeId,
    central: Option<NodeId>,
    presentation: RootPresentationOwner,
    nodes: NodeRows,         // IDs, kinds, ordered item/child membership
}
// Workspace root entry owns Arc<RootValue>; node slots own root/local-row locators.
```

Exact command refs retain the root value Arc; structure compares its geometry owner; topology compares its shape owner. Selection creates a new RootValue while reusing geometry. Resize replaces geometry while reusing shape. Structural or presentation-owner changes replace shape/geometry/value. These are actual data owners, not duplicated fingerprint records or a trusted “unchanged” bit. Frozen refs can read the actual old weights if needed; the same data is the authoritative storage, not a second capture copy.

A global generational NodeId allocator/locator retains stable NodeIds across root edits and keeps one authoritative owner/local-row for each live node. Root-local node rows must never be indexed by global arena slot into each root allocation. Membership uses the live global locator plus root-local key agreement. Deleting/recycling a global slot invalidates old generations. A moved subtree updates locators for its nodes; an Item move between populated leaves changes only the two pane rosters, not root ownership for all nodes.

Workspace clone shares immutable roots and copies/shares the small roster directory. Candidate edits build replacement values for affected roots privately, then swap both affected root entries and changed global locators atomically after checks. Every staged command swaps its replacement values before the next command checks refs. Unaffected roots keep the same actual owners. Do not keep origin acceptance after a swapped root, and do not perform `Arc::make_mut` blindly before recognizing an equal no-op; reusing old root/geometry/shape owners for a zero patch is part of the contract.

A first B Implementation that copies an entire changed RootShape/SelectionRows is **O(root size)** on a shared root edit, not O(height). It can still avoid copying unrelated roots and avoid duplicate proofs. Flat paged rows or a persistent path representation could reduce copying to changed pages/frontier later, but that is a separate representation choice and cannot be claimed from Arc alone. No generic persistent DAG/cache framework belongs in this proposal. The existing complete layout should continue consuming all actual nodes and current answers.

B changes `Workspace::node() -> Option<&Node>` because selected/weights/items are no longer colocated in the current Node enum. A borrowed `NodeView<'a>` enum over those actual arrays is the honest Interface; do not reconstruct an owned Node/Vec on each read. It also changes serde/build/import, command editing, current query traversal and all Node matches, so it is not the smallest next patch. The two root and locator swaps need the same candidate/rollback discipline as A. The root incarnation/origin travels with the root value as a private field (omitted from the sketch), so another RootId cannot be assigned a shared value as a membership shortcut.

Exact origin and ABA rules match A. A fresh import/new Builder creates fresh origins/owners; a clone of the same immutable root shares them. Builder edits based on runtime storage may publish a new origin rather than perform a costly opaque cross-build identity equivalence reconstruction. Presentation comparisons are allowed only within the same admitted runtime origin; an independently reconstructed equal tree is not automatically a compatible actual output.

## Comparison and cost limits

Let N be live workspace nodes, C arena slot high-water, r the requested root size, F the changed frontier/tab/child sequences, and M a moved subtree size.

| Property | A: closed flat owner | B: actual immutable root owners |
| --- | --- | --- |
| Capture/check exact root | BTree root lookup + actual generational ownership lookup + constant handle compare; Item capture also pane membership | Same, via global locator and owned root |
| Root-sized proof allocation per request | None | None |
| Selection/resize authority maintenance | O(F), excluding existing candidate clone and actual MRU/weight edits | Constant owner replacement plus copied changed selection/weight storage; O(r) in simple whole-root arrays |
| Structural owner/membership upkeep | O(F + M) for actual changed nodes, plus existing normalization where applicable | O(F + M) logical updates; O(r) root copy in first COW representation, potentially smaller with separate later paging |
| Candidate clone | Existing full Data clone O(N/C + item/edge payload) remains; no per-node Arc | Shares root values; roster/locator ownership still needs a concrete copy/patch plan |
| Geometry structure/topology | A1 current real output facts retain O(r) comparisons; A2 constant token comparisons plus necessary effective-weight checks | Constant owner comparisons plus necessary effective-weight checks |
| Old references' retained memory | O(root/reference count) small identity objects; no retained whole workspace payload | Old root actual data/arrays stay alive while refs/plans retain them |
| Source migration | Owner state + concrete writers + command/index/resolver consumers; existing Node reads remain | All Node readers/writers/build/persistence and locator publication change |

Neither design removes real payload collection, selected/MRU updates, current policy, exact gap validation, normalization errors, rich projection, owned export or native settlement. Do not label the residual ratio “language overhead” or a proved structural limit before measuring their actual shares and considering B's remaining ownership cost.

## Concrete source migration and deletion list

For A1:

1. `graph.rs` and a small owner-private child: add actual node-root/presentation ownership and exact issuance; keep Builder raw/unissued; define clone and new-origin behavior. Remove committed mutable escapes from operation/canonical callers by moving them behind concrete owner methods. The methods must install owner state per command, not at the end of an arbitrary batch.
2. `command.rs` / owner reference definitions: replace ItemSource/NodeSource/TabTarget/EdgeTarget full fingerprint fields with opaque root/node refs. Remove public `fingerprint()` accessors and caller-assembled target policy fields. Preserve typed edge scope, fraction and gap semantics. Do not retain aliases or value-proof command compatibility.
3. `workspace.rs`: make capture use live owner membership/issuance; delete `build_root_index` and `root_fingerprint` from command capture/verification. Eliminate command-local `WorkspaceIndex::for_command_reference`/`include_command_reference` and duplicated member sets for command authority. Scene/index geometry and layout acceleration remain purpose-specific until A2; they cannot mint command authority without owner binding.
4. `operation.rs`: replace ReferenceAuthority's Live/Indexed full-value verification with the one current owner check, independently for each role. Derive current target facts once and feed policy/execute under the fused borrow. Ensure Select, resize batches, Open/Close, root creation/retirement, presentation transfer, recovery and canonical repairs all use the closed owner methods; every staged command updates authority before returning.
5. `transaction.rs`: preserve original-issued refs on the initial candidate clone, never accept all origin refs across the whole batch, and keep discard/publication atomic. Workspace durable equality excludes private issuance; failed candidates cannot change the original issuer.
6. `drop_resolver.rs`: reuse `rebind_topology_target`; compare the admitted scene geometry basis to current geometry basis, then capture a fresh exact command ref. Do not add a second rebind layer. Keep exact root/node/surface/edge/gap location and current selected target rule.
7. `layout.rs`: split override sources use the same exact NodeSource; remove per-request root fingerprint rebuilding and Arc-fingerprint-dedup shortcuts. Validate each split's live membership/issuance, then actual cardinality and normalized weights. A same-root batch checks all refs before any mutation.
8. `scene.rs`, `scene/validation.rs`, `scene_manifest.rs`, `engine/presented_input.rs`: initially retain output facts for geometry, bind current exact command refs separately where needed, and ensure a supplied current Workspace/index is really owner-current even at equal engine version. Selection retention must no longer copy an exact root fingerprint simply to change selected/MRU.
9. `error.rs`: replace expected/actual full fingerprint payloads with small typed stale-reference diagnostics (role/root/node and optional opaque issuance diagnostic). No error path should reconstruct a full proof to print an expected value. Persistence must not serialize reusable command authority.
10. `docking_cost.rs:154–199`: capture directly through owner methods inside the same request interval; remove the full all-root index construction from that path. All-root current layout and fresh full owned export stay in their existing phases. The standalone in-process Adapter and egui/headless compiler Adapter use these same captures; no bench-only authority bypass.

For A2 additionally replace scene full geometry bases with typed structure/topology refs plus real effective-weight inputs; delete obsolete RootFingerprintData/FingerprintNode algorithms after their last geometry reader is migrated. B replaces the same exact-ref protocol rather than adding another one; it further replaces actual root/node storage/read Interfaces and clone Implementation. Neither calls for a second general command compiler, a compatibility shadow or an assurance script that attempts to prove Rust control flow.

## Necessary behavior tests through the real Interface

Reuse the current unit/integration/property suites; add only missing counterexamples, no new framework. Existing `checked_move.rs`, local-selection/local-item general oracle and engine presentation/retention tests already supply much of the surface.

1. **Staged independent staleness:** keep Select→old-source rejection for Item/Tabs/Subtree, Move→old-target rejection with an unaffected current source, and fresh same-root source→old target rejection. Include an unchanged prefix and a disjoint-root prefix that both permit the later valid command. Check failure index/role and original rollback, not private token layouts.
2. **No-op and two-root change:** same-pane Center/gap, exact edge no-op and same weight Resize preserve subsequent command usability after policy checks. A real cross-root Item move invalidates refs on both roots while refs on a third root remain usable. A one-command normalized equal no-op does not invalidate; a published A→B→A sequence may reject the original ref and must follow the documented strict rule.
3. **Generation and origin:** a retired/recycled node cannot validate through an old ref; fresh independently built equal NodeId values cannot share issuer authority. An unchanged Workspace clone can apply the captured command; after a clone branch changes a root, the old ref is rejected on that branch and still valid on the untouched original. Same engine version does not rescue old refs/index operations after a legitimate mutation.
4. **Three permissions:** after Select/MRU, old exact refs reject but an already admitted geometry location can rebind with structure unchanged. After durable Resize, structure comparison fails, topology matches, and presented input still succeeds only when the actual durable/transient weights match its complete output. After item/child/central/root-owner change both geometry comparisons reject. Rect/roster changes continue to be rejected by their own authorities when applicable.
5. **Current selected drop policy:** keep effective bar policy identical while changing selected target item and its drop rule. The real resolver must use the new selected rule under current policy; an old literal target is stale. Old actual output without current semantic/host admission cannot obtain new permission merely because geometry tokens match. Policy-only change rejects a previously captured operation when now denied; no-op denial and exact typed recovery semantics remain covered.
6. **Atomicity and normalization:** retain the actual local-versus-general complete candidate oracle, late f32 normalization-underflow rollback, discard/retry and multi-root retirement cases. A failing candidate may not invalidate refs on the original. Root-node/central identity and precise weights are significant, not just final rendered rectangles.
7. **Complete output:** use existing headless/egui prepare/commit and conservative compiler oracles to compare actual measurement, reveal/scroll, selected/MRU and complete plans. Keep stale/unpresented output, native lifecycle and transient resize checks. Most are existing regressions; no duplicate proof-constructor tests are needed once forgery is unrepresentable.

Representation-only forged-field tests can be removed or converted to public wrong-root capture/policy behavior after the fields disappear; preserve their behavioral authorization counterexamples. The normal disabled-for-timing work ledger can verify zero root-fingerprint builds in capture and command checking, but counts alone are not semantic evidence. Do not put benchmark assertions inside timed phases.

## Smallest next decision and falsifiers

Wait for the combined frozen result. If request/proof work remains large, implement A1 as one closed protocol slice, keep geometry admission's existing semantics, run the focused behavioral set and the existing full suites serially, then repeat the unchanged two-group complete-operation matrix with all original raw tails/state vectors. Keep request capture in its timer; do not modify ImGui, move issuer acquisition to fixture setup or omit new owner-maintenance work from mutation timing.

Stop or redesign if any of these is true:

- Runtime writers still mutate committed raw Data without the owner updating membership/issuance, or a supplied index is trusted only by engine version. Then opaque refs would be unsound metadata.
- The only way to complete A is “collect whole root before/after into new full values for every mutation.” That fails the intended change-frontier design; choose actual root owners or a genuinely smaller measured slice instead.
- Equal one-command no-ops stale later valid references, disjoint roots are over-invalidated, or a batch-origin escape accepts an old same-root target. These are observable contract failures, not harmless false negatives.
- Topology equality admits mismatched presented weights, or structure equality suppresses current selected minima/drop-policy checks. Those uses grant more authority than the original comparisons.
- A1's remaining full candidate clone/output work dominates the twofold gap. That is evidence to evaluate B or a smaller mutation publication unit, not permission to announce a structural limit from proof removal alone.
- B's actual changed-root copying or long-lived root data retained by many outputs overwhelms its clone savings. Arc sharing by itself is not proof of good locality or memory use.

There is no implementation authorization implied by this document. Root should choose after measurement; neither the current CI fix nor the conservative arena checkpoint establishes the new twofold objective.

Prepared at 2026-11-06T18:17:53.239306+00:00.

## Read identity

Design source anchors at report time (these are not a measured candidate receipt):

| File | SHA-256 |
| --- | --- |
| `crates/dockspace/src/command.rs` | `70dfd7d22e0a4efb7ae959ba72ade99195e073b49d727d4f28701938d625924c` |
| `crates/dockspace/src/workspace.rs` | `4831e24788c18e4cf0254a567105b2801f23db55cde003f3f9e405cdd701e300` |
| `crates/dockspace/src/graph.rs` | `cbe27a19fa3c9612f33b87f702ec56acd3aad40d03e3c7f1fb0ca872468de166` |
| `crates/dockspace/src/operation.rs` | `f89cc23fe15c7626e145ec2434853be6a01bedd3b3db07b1310650d9f312c586` |
| `crates/dockspace/src/drop_resolver.rs` | `27b83457f5dced92a8d81ba6f051fa5280fd0f6e01b2c02ed833795df218e981` |
| `crates/dockspace/src/engine/presented_input.rs` | `205b66116083393cc074f70a0741d5f6828b1f4e5c26b20795eeefbd07d84697` |
| `crates/dockspace/src/layout.rs` | `ec44b2ddd4ac9bc529222de44950f1cc6c1e2cd894d357e7c6593c23ba95bca9` |
| `crates/dockspace/src/docking_cost.rs` | `0994c837556c82fa9e3b21b81055a514a402cf24117c4e25edea0e04ca66e2f5` |
