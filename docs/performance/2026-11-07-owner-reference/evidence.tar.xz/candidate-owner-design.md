# Independent transaction candidates without full payload cloning

Status: read-only design, 2026-11-07. No repository edits, Cargo, tests, benchmarks, or timing were performed for this report. Root is verifying the combined sealed-Workspace/local-finish slice, including the two exact-f32 regressions. Implement none of this before that qualification and its frozen timing result. References describe the current working implementation, including the modified-split correction.

## Recommendation

First remove the two common-path Workspace equality scans without changing storage: let the graph owner finish the transaction report once, using the existing exact single-Item/no-op outcomes and one final semantic comparison for the general route. Freeze the result with its candidate. This is a small, independently reviewable change.

If cloning remains material after the common owner-reference work, use immutable **node payload COW with the existing SlotMap allocator** as the next bounded storage slice. Keep the current checked executor, local canonical completion, raw Builder normalization, and engine publication Interface. This removes the deep copying of every node's item/child/weight vectors and every MRU vector. It does **not** remove the O(slot extent + map entries) fork/drop work of a stock SlotMap and BTreeMaps. Measure that remainder honestly before adopting a persistent arena.

Do not start by adding an in-place rollback route to public `apply`. It could optimize an immediately consumed unique Workspace, but the production prepare/preview/host-frame paths must retain independent candidates before several later rejection points. Accommodating those paths turns a local delta into a persistent read overlay or requires a much wider transaction Interface. A benchmark-only immediate executor would leave the important candidate contract unresolved.

If the remaining slot/map fork work is itself too expensive, a page-based persistent generational store is a justified later design, rather than claiming that `Arc<SlotMap<...>>` solves it. That is a separate allocator/storage change, with a larger verification surface; it is not required for the first two slices.

## What the current source actually requires

| Source | Observed work or contract | Consequence |
| --- | --- | --- |
| `transaction.rs:11`, `operation.rs:594` | `clone_workspace_draft` calls `Workspace::clone` before branch selection/execution. | Every successful/rejected preparation starts with a full independent Data clone today. |
| `graph.rs:365–395` | Data owns `SlotMap<NodeId, Node>`, a separate `BTreeMap<NodeId, Vec<ItemId>>` MRU, and three presentation/root maps. Workspace equality compares those maps and every live node by identity/value. | A whole-Data Arc just moves this copy to the first `make_mut`. Node sharing alone also leaves the separate MRU vectors to copy. |
| `operation.rs:649` | Single local Item Move recomputes `Moved.changed` using complete candidate equality. | The already checked command outcome is discarded as change evidence. |
| `transaction.rs:85–103` | `into_parts(original)` computes complete equality again; both `publish` and `into_snapshot_parts` use it. | The same successful single-Item result receives two complete comparisons. Comparisons short-circuit, so this is a worst-case traversal claim, not a measured per-operation cost. |
| `drop_resolver.rs:930–956` | Preflight projects the actual prepared candidate before consuming it into an owned preview mutation. | A list of future writes is not a sufficient candidate unless it supports the normal graph queries. |
| `drop_resolver.rs:1882–1920` | `PreparedDropMutation` shares `Arc<Workspace>` across query clones; release requires `Arc::try_unwrap`. | Independent candidate lifetime and release ownership must survive a storage change. Logical base sharing inside that Workspace is compatible with this existing outer uniqueness rule. |
| `engine.rs:3447–3540`, `5682–5730` | Preparation is followed by optional delivery activation, pending presentation checks, recovery/publication mismatch checks and staging recovery obligations. | Mutation success is earlier than publication success. Dropping/rejecting any later stage must leave the live graph unchanged. |
| `engine.rs:5887–5985`, `engine/host_frame.rs:2958–3190` | The full engine candidate shares the old WorkspaceSnapshot, and can itself be abandoned before host-frame commit. | A successful local Workspace operation must not mutate the original snapshot through shared storage. |
| `operation.rs:663–737` | Mixed/multiple commands and owned follow-ups keep complete general settlement. Each command sees its actual staged graph. | Preserve this route and its error order. No retry against the initial base may replace sequential staged validation. |
| `graph.rs:563–577`, `canonical.rs:222–354` | Item moves may allocate payload/wrapper nodes, retire empty/flattened nodes, change root nodes, remove main/contained ownership, and prune a vacated surface. | A two-tabs journal alone cannot cover the full single-Item Interface. Central leaves and contained owners are part of the transaction. |

`WorkspaceSnapshot` already gives O(1) sharing for an unmodified outer engine candidate (`operation.rs:33–87`). This is useful but does not change the inner `&Workspace -> owned Workspace` transaction fork. `WorkspaceSnapshot::apply_draft_command` can also trigger an outer Arc clone when another owner exists; COW at the Data payload level would make that clone share immutable payloads too.

The formal renderer-free kernel includes request capture, `WorkspaceTransaction::apply`, all-root actual projection and fresh owned export (`docking_cost.rs:349–375`). `publish` replaces and drops the old Workspace inside `apply`, so old slot/map destruction belongs to mutation timing. Final fixture and measured-result cleanup occur later; a new design must not move publication's old-storage release to that later cleanup to obtain an artificial win.

## Small first slice: the prepare owner seals the report

Use the existing graph-owner Seam. The external transaction Module need not expose storage, mutation logs, checked tokens, or a second executor. Its useful Interface remains three operations:

```rust
// Schematic private Interface; no new public benchmark Interface.
Workspace::prepare_transaction(&self, policy, commands)
    -> Result<PreparedTransaction, TransactionError>;

PreparedTransaction::candidate(&self) -> &Workspace;
PreparedTransaction::into_parts(self) -> (Workspace, TransactionReport);
```

The existing public `WorkspaceTransaction::apply` prepares, consumes those parts and assigns the candidate. Engine conversion to WorkspaceSnapshot is similarly a consuming conversion, without an `original` argument. `candidate()` supplies the resolver's preview read. The graph owner constructs the prepared value; callers cannot obtain `&mut` access or replace candidate/report independently.

Keep `PreparedTransaction` and its constructor within the sealed graph/operation Implementation, with a transaction-module re-export if needed. Its current crate-visible mutable fields are unnecessary for the sole production direct reader, `drop_resolver::preflight`. A frozen `TransactionReport` is an owned result of completion, not a mutable validity/dirty cache and not authorization to publish onto another base. Do not use `report.changed()` or its stored base to bypass any engine barrier.

Change computation is exact for the existing local single-Item branches:

| Successful execution branch | Exact final change fact |
| --- | --- |
| Same-tabs center | False; executor performs no write. |
| Same-tabs tab gap | The existing reorder result compares actual old/new position; MRU/selection stay the same. |
| Noncentral singleton item dropped on itself at an inner/outer edge | False; existing branch returns before detach/insert. |
| Other center/tab-gap destination | True: an item changes its tabs membership, and valid Workspace ownership forbids the same item already existing in the destination. |
| Other edge move | True: the real writer allocates a new payload tabs node before local retirement. That node survives. Even if canonicalization recreates the previous visual arrangement, runtime node identity differs; current Workspace equality compares identities. Central self-edge leaves a preserved central leaf plus the new leaf. |

The final finisher can reject these operations; rejection produces no prepared report. For success, it cannot reverse the stated membership/new-node fact. This reasoning depends on retaining the current Item-edge allocation/retirement semantics. If a future change reuses an existing payload node, revisit its exact change result rather than inheriting this conclusion.

Single Select can use the existing `Selected.changed`: a sealed selected-first MRU means reselecting the current item cannot secretly repair history. All other programs keep one complete `candidate != original` at the end of general settlement. Reuse that one result for both a single nonlocal `Moved.changed` and `TransactionReport.changed`. In particular, **do not** OR per-command changes for a batch: two valid staged selections can restore the original selected/MRU values and require a false final report.

This removes exactly the two transaction-kernel comparisons under discussion. The engine's composed delivery activation still compares its further-mutated candidate against the live workspace (`engine.rs:3514`), and surface recovery can perform a similar comparison after an extra Select (`engine/surface_runtime.rs:2753`). Those are separate composed-operation semantics. A frozen prepare report describes the candidate at consumption; it is not a result certificate for arbitrary later edits. Preserve those existing comparisons unless their own composition is proved separately.

Precise edit surface: `operation.rs` preparation and prepared-value construction; `transaction.rs` report/conversion/publish; the resolver's one candidate field read in `drop_resolver.rs`; `into_parts/into_snapshot_parts` call sites in `engine.rs`, `engine/pointer_transaction.rs`, `engine/pointer_timed.rs`, `engine/surface_runtime.rs`; and direct private tests. Close uses its separate `PreparedContentCloseCommit` and need not be redesigned. Keep the general comparison as an oracle in tests.

## Storage alternatives

| Alternative | Real copy work on prepare/write | Candidate/allocator behavior | Assessment |
| --- | --- | --- | --- |
| `Arc<WorkspaceData>` or `Arc<SlotMap<NodeId, Node>>` only | O(1) initial fork; the first shared write copies the complete object, including all nested Vec payloads. | Existing SlotMap keys/free list are easy to preserve. | Too shallow: shifts the current cost into the first edit. |
| Immutable root-level COW | Copies the modified root's payload; two roots for cross-root moves; still needs global identity/lookup ownership. | A root-local SlotMap cannot simply replace today's global key space without key remapping or a global directory. | Poor first choice for this fixture: with one view a root is essentially the entire forest, so the N-sized copy remains. |
| **Immutable node payload COW, stock SlotMap** | Copies slot/map entries, increments shared handles; deeply clones only first-written node/MRU payloads. | Fork copies existing slot generations and free-list state using SlotMap's normal Clone. Existing read and independent candidate semantics fit. | Recommended bounded storage slice if the next profile warrants it. Does not make fork/drop sublinear. |
| Persistent paged node/allocator store | Copies a small directory path, affected pages and changed payloads; whole-Vec page-directory copying would still be O(number of pages). | Must own generation/free-list/version semantics across persistent branches, live old outputs and discard. | The route to removing the remaining whole-arena copy. A separate, larger slice, not a wrapper around private SlotMap pages. |
| Validation-first local delta / rollback | Can copy only touched rows in a topology-preserving case; full candidate reads need an overlay, or unique mutable ownership held until commit. | In-place mutation of a shared live snapshot is invalid. Stock SlotMap rollback has allocation-state limits. | Viable under a restricted Interface; not a drop-in replacement for current prepare/publication. Details below. |

### Practical node payload COW slice

Keep `Node` as the public value with today's Vec fields. Store immutable values privately, conceptually:

```rust
struct NodeStore {
    slots: SlotMap<NodeId, Arc<Node>>,
}

// MRU must also share its vector; sharing only Node misses this full copy.
tab_mru: BTreeMap<NodeId, Arc<Vec<ItemId>>>
```

The typed private storage Implementation exposes `get -> &Node`, first-write `get_mut -> &mut Node` via `Arc::make_mut`, insertion, retirement and the exact read iteration subset that existing code uses. This is a storage Module that earns Depth by hiding ownership and key handling; do not implement an arbitrary generic persistence/patch framework or the whole SlotMap surface. Keep all production writes behind graph's existing closure.

Queries should keep `Workspace::node/nodes/tab_mru` and shared Data reads. Adapt the internal NodeStore iterator once so layout/compiler/engine callers see `&Node` without an Arc-related product Interface. Owner mutation paths need first-write access to the node/MRU handles. Builder mutation also uses make_mut, so `clone().into_builder()` cannot alter the originating Workspace. Raw malformed-Builder diagnostics remain possible. Do not fold MRU into the node record in this first storage slice: it is an attractive ownership simplification, but it would also change the representability of raw unexpected/missing MRU rows and need a separate diagnostic migration.

For a populated-source center move the expected deep copy frontier is two tab nodes and two MRU vectors, including any subsequent modifications to those same values. The target's tab count and the source's MRU length are real local costs. Edge moves additionally allocate the payload/wrapper values. Last-item cleanup clones modified ancestor payloads as required by the existing local writer. No full input/output pass is skipped beyond the already qualified local finish.

Several traps must be handled explicitly:

- **No first-write cloning of an entire MRU map's Vec values.** Arc-wrap each value, not just the complete BTreeMap. Map structure/entry copies remain honest O(N) work.
- **Read-only sweeping must stay read-only.** A NodeStore `retain` used only to filter reachable keys must not call make_mut for every retained Node merely to satisfy a needless `&mut Node` callback.
- **Retirement need not deep-clone a value merely to drop it.** Removing a shared Arc can release that handle. Where `remove_runtime_node` truly needs the old children, read or retain that immutable value; where its return is ignored, avoid `unwrap_or_clone` just to discard it. This matters to wide flattened splits.
- **Unique follow-ups should remain unique.** Once a candidate has detached its source/target payloads, a delivery Select on that same candidate should not deep-copy those same values again unless an actual second reader was retained. Keep `PreparedDropMutation`'s outer uniqueness check.
- **Flat IDs avoid recursive destruction.** `Arc<Node>` whose children remain `Vec<NodeId>` does not create a recursively owned Arc tree. Naively replacing it with recursive immutable child Arcs can reintroduce stack overflow on a real 10k-depth graph, including during drop; any persistent tree design must address destruction as well as traversal.
- **Do not claim O(touched) total resources.** Stock SlotMap Clone copies its initialized slot extent, including vacant slots (not just live nodes); copying live Arc entries incurs atomic increments, and old-storage disposal incurs decrements. Each retained snapshot also owns its copied slot/map metadata. Memory usage with multiple prepared/host/output owners must include all those headers and unreleased old payloads.

The installed `slotmap` source confirms Clone copies the slot vector and preserves `free_head/num_elems` (`slotmap-1.1.1/src/basic.rs:967–985`). It has private contiguous slots, not a public page-level fork operation. Cloned candidates can allocate the same numeric key on separate branches, just as today: NodeId alone is not cross-Workspace authority. Current fingerprints, and the proposed owner-issued references later, must retain that distinction.

Precise edit surface for this storage slice: `graph.rs` (or one private graph storage submodule) for typed sharing/accessors/Builder behavior; `operation.rs` node and MRU writes and retirement; `canonical.rs` writes and nonmutating sweep; `validation.rs`/`workspace.rs` only where direct raw map access needs its adapted read iterator; `drop_resolver.rs` clone/work instrumentation; relevant Builder/raw tests. Layout/compiler callers should receive the same `&Node` Interface; announce any unavoidable mechanical migration before expanding ownership. Public persistence continues to normalize raw Builder input with the existing strict route. Do not change the persistence format or replace NodeId in this slice.

### Validation-first owned delta / rollback: useful but constrained

There are two substantially different designs hidden by the phrase “local rollback.”

**A unique mutable guard** owns the before-values of touched nodes/MRU/root/presentation rows, runs the same executor, and restores them on failure or Drop. For a populated-source center/tab-gap operation there is no node allocation/retirement, no source-root disappearance and no presentation rewrite; a two-node/two-MRU journal can restore that case exactly. This is a practical restricted operation if the caller genuinely hands over exclusive ownership and the guard is consumed before returning.

The current shared `&Workspace` preparation Interface does not hand over that ownership. The engine's rollback candidate normally still shares the old WorkspaceSnapshot with its original engine. Mutating the shared underlying Data with interior mutability would make the original and any retained views observe speculative state. `mem::take` of an Arc handle does not make its allocation unique. Nor can a borrow guard be retained as `PreparedDropMutation` while unrelated engine work and output lifetimes proceed. Optimizing only public immediate `apply` through this route would leave `prepare_transaction` unchanged and should not be presented as the common prepared-candidate solution.

An unshared original could use SlotMap's public `detach/reattach` for existing removed keys (`basic.rs:467–550`), provided no snapshot/serialization can observe the detached interval. Ordinary remove/reinsert does not restore the original key generation. More importantly, undoing newly inserted nodes through `remove` does not restore the pre-edit free-list/generation state: remove advances the generation. A detached slot is deliberately not reusable until reattached; detaching/reinserting everything is not a free allocator transaction. Workspace equality ignores vacant slot state, so an equality-only rollback test would miss this distinction. Edge allocation and source/flattened-node retirement therefore need deferred deletion/reservation with a genuine allocator design or an independent allocator fork. Do not quietly broaden the atomic contract using an equality that fails to observe allocator changes.

**An owned sparse delta** can be held independently: it retains an immutable base plus owned replacement rows, tombstones, presentation changes and new nodes. To preserve this codebase's depth, the existing executor would write through the storage owner into that delta; there must not be a second planner implementing tab selection, central preservation, canonical weights and retirement separately.

However, all the normal graph reads, actual preview projection and lifecycle barriers must see base+delta as one Workspace. Today `storage() -> &WorkspaceData` and direct map reads assume a complete materialized store. Supporting delta reads therefore requires a persistent NodeStore/read iteration change much like a COW storage design. A linked chain of prior deltas also makes read cost grow with committed history unless it has a bounded persistent index or pays compaction/materialization costs. Treat this as a real persistent representation choice, not a tiny deferred commit list.

A restricted first overlay could cover populated-source center/tab-gap only: it shares the allocator unchanged and owns two replacement node/MRU rows. For every shape that allocates/retires/reparents, select the existing independent general representation **before executing the command**. This avoids inventing an allocator transaction, but leaves edge/last-item costs and requires all candidate readers to understand the overlay. Follow-up activation/general batch settlement can materialize the overlay, making that cost part of the actual production operation. This restricted slice is less attractive than payload COW unless measurements specifically show slot-header work already dominates.

Do not use failed validation as permission to retry on the initial base. Stale/forged facts, policy rejections and the qualified numeric failures must propagate with their current types/order. If a representation is unsupported, choose fallback before any executor work; if a private scratch delta is abandoned for another representation, discard it completely and retain the original staged base. Later commands in an atomic batch must still run on the prior command's actual staged state. No already-mutated live graph may become a fallback base.

## Coupling to the owner-reference slice

The designs are separable, but their interfaces should agree:

1. An unmodified fork shares the original root authority. A real source/target edit mints candidate authority through the sealed mutation owner, leaving the live owner's references intact. Selection/MRU, weights and structure may preserve the proposed distinct presentation identities according to common's design.
2. Payload Arc identity is memory ownership, not complete root authority. A single unchanged node Arc cannot prove sibling topology, MRU, root central or presentation ownership. A full storage-page identity cannot stand in for both independently validated source and target facts either.
3. Parent/membership metadata from common must fork with the candidate and be updated at the same mutation completion points as graph data. A “small metadata” owner-reference design can still lose its gains if its whole parent/index map is deeply cloned per move. Its storage cost belongs in the candidate fork account.
4. Root reference tokens, semantic `changed`, Workspace value equality and allocator lineage answer different questions. A strict ABA policy may retire authority even when final values compare equal; report that according to the authority plan rather than turning root identity inequality into `TransactionReport.changed = true` for a net-zero general batch.
5. Retained old output facts remain immutable. Neither page reuse nor an overlay may mutate values behind an old root reference/plan. Discard must release only the candidate's handles and its new authority. Old-output rejection and lifecycle barriers remain in the engine; the candidate representation does not replace them.

Implement the frozen-report slice before or separately from common's root-reference storage changes. For COW, agree on the internal root/parent metadata representation once common has a concrete plan; avoid two independent wrappers each copying all the same per-node facts.

## Required behavior tests and falsifiable work checks

Reuse the existing local-vs-complete matrix and real engine harnesses. Add the smallest cases that distinguish these mechanisms:

- **Change report ownership:** all single-Item no-op and same-tabs reorder branches must match the full general oracle; non-noop center/edge moves must have equal outcome/report flags; an empty program and a genuine staged select-away/select-back batch keep a false final report. Capture each second command against its expected staged state so stale-proof refusal is not confused with net-zero semantics.
- **Candidate independence:** retain two prepared results from one base; consume/drop them in either order; mutate one candidate through an existing owned follow-up and verify the other and the original still have the original node/MRU/presentation values. Preparing then discarding and retrying must give the same observable result.
- **Generation/allocator independence:** delete and allocate on one branch while retaining another and an old output. Verify stale generations and owner references reject correctly. If any rollback guard is proposed, also compare subsequent fresh allocation keys to an untouched control; `Workspace == original` alone is insufficient to verify allocator rollback.
- **Topology and presentation:** retain the existing central/noncentral, inner/outer, same/cross-root matrix; source main-root and contained-root retirement; source surface pruning; the underflow and both exact-f32 input/output witnesses. Strict validation remains the successful-output oracle outside the work-counter snapshot.
- **Late publication failure:** use existing host/native fixtures to reject after candidate preparation for a frozen surface/recovery mismatch or failed required delivery activation; drop the prepared host frame; verify live Workspace, focus, native/presentation identities, output authority and old receipts remain unchanged. Reuse the real frame-drop and prepared-drop unique-owner coverage rather than copying another large harness.
- **Staged batches and raw input:** the second command sees the first command's graph and rejects old proofs; late batch failure restores the original. Builder clone/replace/normalize cannot modify an existing Workspace. Keep full raw input and import diagnostics, including malformed MRU tests.
- **Physical copy accounting:** distinguish candidate forks, slot/header/handle copies and actual Node/MRU deep copies. The current logical clone-volume ledger captures an entire Workspace at call time; do not rename that number to “actual deep copied values” after COW. Place small test-only counters at real first-write payload cloning if attribution is needed, and retain the compile-env counter bypass for formal timing. Repeated writes to the same uniquely held node must not be counted as repeated COW clones.

Predictions to test, not measured findings: frozen reports remove Workspace equality from successful local Select/Item Move preparation/consumption while the general route still compares once; payload COW bounds deep copied content by touched nodes but retains linear slot/map-handle fork/drop work; a root-only copy still scales with the sole root at one view; a persistent overlay without bounded indexing can accumulate history-dependent read cost. Old-storage destruction, allocation, request/proof capture, final equality retained on general routes, all-root layout and owned export must stay in the declared timer. No source-only analysis here establishes a numeric lower bound, a 2x result, or how much of the current end-to-end time these changes would save.

## Bounded implementation order after measurements

1. Qualify the current frontier fix and freeze its comparison first.
2. Seal the prepared report and remove the two local equality scans. Keep storage, runtime identities and all barriers as they are. Qualify against the general oracle and net-zero batches.
3. Integrate the separately reviewed owner-reference work, then reattribute the remaining real operation rather than optimizing a superseded profile.
4. If full payload cloning still matters, implement typed node/MRU sharing with stock SlotMap in one storage slice; retain independent complete candidates and the same executor. Qualify isolation, lifecycle/drop, generation and numeric cases, then measure mutation including old-storage release.
5. Only if remaining slot/map copies limit the measured goal, design the persistent generational store as its own change. Choose it over growing an unbounded overlay or an engine-wide undo protocol. Keep the current implementation available as the correctness oracle during that design, not as a second production executor.

The first two changes provide Locality: report and payload ownership live in the graph/transaction Module, while engine callers continue to approve a complete independently owned candidate. Their Interface gains Depth without transferring rollback obligations to every Adapter or publication caller.

## A1 second opinion: use the existing concrete transition owner

Read-only addendum requested after `proof-owner-design.md` became available. Repository source remains stationary; no Cargo or timing. **A1 is implementable without a new setter layer or another executor. Treat `graph + operation + canonical` as one trusted Implementation of the committed graph-owner Module.** Their concrete checked transitions can maintain issuance and membership. Making those three Implementation files unable to modify their own data is not a prerequisite for ownership; safe Rust would not prove the semantic change classification inside a new setter layer either.

The necessary closure is at the caller Seam: outside this owner, no mutable committed Data, unchecked completion/Workspace constructor, authority minting, or independently editable authority directory escapes. Keep raw Builder input unissued. Inside the owner, audit the finite checked transition and completion paths and require them to close owner state before another reference check or an externally readable candidate is returned. Do not expose a general `node_mut`/dirty/refresh protocol to crate siblings. Existing private low-level writes may remain inside this trusted owner.

The two important points in the A1 document are correct: every mutation family must participate, and authority must be current between staged commands. The wording about a “deeper owner module” should not force a rewrite of the existing dispatcher/executor into dozens of setters. Moving/re-exporting the private authority types and narrowing outside visibility is enough; the command transition is the useful unit of the Interface.

### Minimal bridge in production

Use one owner-private completion receipt from the **actual checked command path**, containing only the affected existing roots and concrete node attachment/retirement changes. Extend the existing `AppliedCommand`/inserted-split receipt if convenient; keep the public command/result shapes unchanged for this step. The receipt is temporary output of a trusted transition, not a persistent dirty flag, user assertion, cached validation result, or permission to defer rebuilding a proof. No command tag alone decides whether a change happened.

The flow is:

1. Check source, independently check target and current policy using their current owner-issued refs, in the existing error order.
2. Run the existing command writer. Its existing no-op branches return no root renewal. Concrete real changes return exactly the roots they changed, including both distinct source and target for transfer.
3. Complete the command's attachment/retirement facts and issue its changed roots. This step is **before command i+1 checks anything**. Do not issue halfway through a multi-split Resize command; validate all inputs against its pre-command state first.
4. For the already qualified single Item route, its existing local finisher is inside that same completion, before issuance. Select has no structural finish. Both common paths maintain only their actual local mutation/frontier, excluding the still-present candidate clone.
5. For the general route keep its current noncanonical staged execution, then its one whole-graph normalization/validation. Complete any additional normalization changes through the same owner before returning the candidate. No old-value command-validation fallback remains anywhere.

This adds owner-state completion to one real executor rather than adding an alternative executor. There is no need for a callback registry, generic proof provider, tracking wrapper around every scalar assignment, or a reusable checked token. A small private root list can deduplicate source==target; a changed-roots vector from Resize can deduplicate the actual changed split roots. Avoid adding a public effect taxonomy merely to encode these few cases.

### Concrete coverage, with few membership helpers

| Existing checked transition | Issuance completion | Membership work |
| --- | --- | --- |
| Select | Renew that root only when actual selected/MRU changes; current sealed selected-first MRU makes equal reselection a true no-op. | None. |
| Reorder | Renew only for the existing real position change. | None. |
| Single Item center/gap/edge | Existing exact no-op/reorder decisions; otherwise source and target roots, deduplicated. Finish local canonical effects before issuing. | Existing source/target leaves keep their root; assign only new payload/wrapper nodes; erase retired nodes and unroot any removed-root residue. |
| Tabs/Subtree Move, RootContent::Move | Renew exactly the changed source and destination roots. Existing checked no-op predicates remain before edits. Complex cold equal-delta cases need an actual affected-value comparison, not an aggregate outcome assumption. | Retag the actually transferred subtree, or leave an emptied merged tabs node unrooted pending sweep. O(moved subtree) is honest for these cold operations. |
| ResizeSplits | Use the existing validated per-split `current != weights` results, not only the aggregate outcome bool; renew only roots containing changed vectors, after all writes. | None. |
| Root creation / empty-root attachment | Mint a fresh root birth and exact issuance, including RootId reuse; renew a changed donor root for moved content. | Assign newly rooted nodes and transferred subtrees. |
| Rehome / Promote | Compare actual previous and resulting Main/Contained carrier. Renew that root if carrier identity changes; other roots on either surface keep their authority. | Node root identity stays the same. Update the normative presentation owner. |
| Rect / Raise / same-carrier presentation metadata | Keep graph issuance even when their overall command outcome says changed; these values were outside the exact root fingerprint. | None; retain separate rect/roster preconditions. |
| Root/surface/item close or retirement | Remove retired root issuance; renew surviving actually changed roots. The separate approved-close entry points must close owner state too. | Delete retired nodes' ownership; process the real source path for item close. |
| Canonical completion | Report its actual surviving-root changes; no renewal for an unchanged split/root or orphan sweep outside every root. | Erase collapsed/flattened/empty nodes; surviving nodes retain their root. |

Only a few **typed private membership operations** are necessary: assign a newly inserted node to its actual root, remove its membership with node retirement, and assign/unroot an actual transferred subtree. These can be colocated with existing `insert_runtime_node`, `remove_runtime_node`, `detach_payload/insert_payload` and root-presentation helpers; they are not dozens of field setters. Builder/import performs the existing full walk once when minting a new valid owner. Canonical local repair already knows the nodes it retires, so it need not rediscover complete root membership.

There is one important staged-state representation detail. Current general batches may leave emptied or detached arena nodes until final canonical sweep. Their actual membership is **no root**; they must not retain a stale assignment to a removed source root or be automatically assigned to the destination merely because their items moved. Store `Option<RootId>`/a precise unrooted state, or omit those exact generational keys from a private ownership directory. Committed Workspace still requires every live node to belong to a root; only the private general candidate can contain these intermediate unrooted records. A correct table must describe reachability, not merely where a node was last seen.

A generation-aware sparse directory is a reasonable lower-churn bridge if embedding `OwnedNode` would force every existing Node match to migrate at once. It is normative graph state updated eagerly by the owner and cloned with the candidate. It is not lazy membership, a version-qualified cache or one highest-slot table per root. Embed ownership later only if that simplifies the final storage. A1 still eliminates capture/check DFS and full command fingerprints; it need not simultaneously replace the arena.

### What one comparison at cold completion can and cannot do

“Update touched roots per command, then compare actual root values once at cold general completion” is sound **only if the first clause already establishes exact current authority and membership**. Deferring the decision about whether each staged command changed its root until the final comparison is unsound:

- Select B followed by a Move with an original B target must fail at command 1, even if a later command would restore B. End-of-batch equality is too late.
- A changed root plus an unrelated root in the same command cannot both be renewed from an aggregate `outcome.changed`; a no-op or disjoint-root prefix must keep later original refs usable.
- The existing normalizer runs only after the command loop. Earlier issuances must describe the actual noncanonical staged graph, not a prematurely normalized prediction. Normalizing each command would change the accepted program/error behavior.

A final borrowed actual-value comparison is useful for cold completion and final no-op classification; it is not a second command protocol. It must compare the state relevant to that transition. Comparing only **transaction base versus final candidate** cannot reveal whether canonicalization changed a root relative to the last staged issuance, and cannot safely undo the authority history of earlier real changes. Likewise, constructing a new whole-root fingerprint before/after every command would defeat the intended A1 slice.

The smallest reliable choice is for the existing canonicalizer to return its actually changed root IDs alongside its existing result. Its rewrite already knows whether it removed/replaced/flattened a node or changed a root node; unchanged splits preserve their bits. Feed that concrete result into issuance completion. A single cold normalization pass may still visit all roots, but authority work need not invalidate or resnapshot all roots. For a difficult cold operation whose exact zero-delta result is not proved by existing branches, use command-local before-images of **its written fields** or a direct affected-root value comparison inside that checked transition. This is correctness work in a rare path, not a new proof-validation fallback or a requirement to instrument every setter.

If root prefers a once-only root-value comparison at cold completion instead of a canonical changed-root result, retain a real pre-completion image for those possibly changed roots and compare borrowed values directly. That image has an actual copying/storage cost unless an immutable pre-completion owner already exists; the transaction's initial base is not automatically the right image. Keep it cold and disclose the cost. Do not introduce permanently retained root-node snapshots for this purpose. Concrete canonical results are usually less machinery in the current implementation.

True equal checked operations keep issuance. A program with real staged A→B→A changes is different: under A1's explicitly stricter ABA contract it may finish with durable `report.changed() == false` and nevertheless retain newly issued root authority. Do not restore the old token merely because the final values equal the initial base. For a **single** cold command whose only transient internal work normalizes to an equal result, no between-command observer exists; its completion can compare against the pre-command state and keep the old issuance. Preserve this one-command no-op behavior deliberately rather than assuming every raw writer's aggregate `changed` flag proves it.

The concrete existing recovery program does not require a batch-origin exemption. `surface_recovery.rs:831–907,1119–1215` compiles a complete source-roster program: one possible main-root move/rehome, then rehomes of **different contained roots**. Moving an earlier root changes surface roster order but must not renew the untouched contained roots' graph issuance. Their own original sources can then remain valid. Rehome updates only each moved root's carrier; the roster itself retains its separate exact checks. Keep the existing typed exact-program/policy-bypass checks and source/target validation; do not treat recovery as authority-maintenance bypass.

### Scope and acceptance for the bridge

Keep this A1 bridge to `graph.rs` authority/membership state and Builder completion, `operation.rs` checked command/close completion, `canonical.rs` actual retirement/rewrite completion, and `workspace.rs` owner capture/check. `command.rs`/`error.rs` hold the private opaque-reference and small stale diagnostic migration. Scene/resolver/layout call sites still need A1's already-described command-versus-geometry separation; this addendum does not replace or expand that plan. `transaction.rs` keeps one independent candidate and the actual general fallback. Do not combine COW storage or A2 geometry tokens with the bridge.

Lock these behavior tests before calling the bridge complete: old source and independently old same-root target after a real prefix; no-op/disjoint prefix accepted; changed Resize roots versus an equal split in another root; same-carrier rect/raise preserving graph refs; main/contained cross-surface recovery with later untouched sources; unrooted merged residue rejecting wrong-root capture; general canonical collapse updating root-node authority; single normalized no-op retaining authority; mixed late failure discarding all issued candidate state. Reuse current rollback, same-version, forged policy, numeric frontier and real host/output suites. Add a cold net-zero batch test that distinguishes semantic report equality from strict authority ABA. None needs a generic setter test harness.

The falsifier for this pragmatic bridge is not that trusted Implementation code can contain a bug; that is also true of new setters. It is an actual successful path that returns or checks another command while its normative membership/issuance is stale, or a path outside the owner that can mutate committed values without its completion. Eliminate those paths, keep the concrete transition audit finite, and A1 can earn Depth without becoming a general proof framework.
