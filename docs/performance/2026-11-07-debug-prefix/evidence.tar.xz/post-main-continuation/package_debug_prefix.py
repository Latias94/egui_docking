"""Package source nonempty cleanup and complete unchanged comparisons."""
from pathlib import Path
import csv
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

root = Path('/Users/frankorz/codes/rust/egui_docking')
base = Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
author = base / 'post-main-continuation/debug-prefix-source'
out = root / 'docs/performance/2026-11-07-debug-prefix'
out.mkdir(exist_ok=True)
frozen = base / 'debug-prefix-frozen'
verified = base / 'debug-prefix-verified'
control = subprocess.check_output(['git', 'rev-parse', 'c7508ee'], cwd=root, text=True).strip()
receipt = json.loads((frozen / 'source-receipt.json').read_text())
checks_path = verified / 'checks-all.json'
if not checks_path.exists():
    checks_path = verified / 'checks-fmt,targeted,fixes.json'
checks = json.loads(checks_path.read_text())
assert receipt['sources_unchanged'] and checks['sources_unchanged'] and checks['normal_counters_enabled']
assert len(checks['checks']) in (3, 12) and all(c['returncode'] == 0 for c in checks['checks'])
assert all(receipt['sources'][p] == h for p, h in checks['sources'].items())
assert json.loads((verified / 'work-check.json').read_text())['returncode'] == 0
assert (verified / 'work.csv').read_bytes() == (base / 'projection-stack-reserve-verified/work.csv').read_bytes()
comparisons = []
for reference in ['baseline', 'imgui']:
    directory = frozen / ('against-' + reference)
    env = json.loads((directory / 'environment.json').read_text())
    assert env['complete_state_equal'] and env['frozen_executables_unchanged'] and env['source_tree_matches_frozen_candidate_at_finish']
    cells = {}
    for row in csv.DictReader((directory / 'summary.csv').open()):
        cells.setdefault(tuple(row[k] for k in ['group', 'panes', 'views', 'case']), {})[row['condition']] = row
    assert len(cells) == 42
    for key, pair in cells.items():
        row = dict(reference=control if reference == 'baseline' else 'imgui', group=key[0], panes=key[1], views=key[2], case=key[3])
        for stat in ['p50', 'p95', 'max']:
            a = float(pair['baseline']['operation_owned_ns_' + stat]); c = float(pair['candidate']['operation_owned_ns_' + stat])
            row.update({f'baseline_ns_{stat}': a, f'candidate_ns_{stat}': c, f'candidate_over_baseline_{stat}': c / a, f'reduction_percent_{stat}': (1 - c / a) * 100})
        comparisons.append(row)
with (out / 'comparisons.csv').open('w') as f:
    w = csv.DictWriter(f, list(comparisons[0]), lineterminator='\n'); w.writeheader(); w.writerows(comparisons)
inputs = {}
for directory in [frozen, verified]:
    for p in sorted(directory.rglob('*')):
        if p.is_file() and p.suffix in ['.rs', '.patch', '.json', '.csv', '.txt', '.stdout', '.stderr', '.log']:
            inputs[str(p.relative_to(base))] = p.read_bytes()
for name in ['post-main-continuation/verify_debug_prefix.py', 'post-main-continuation/freeze_debug_prefix.py', 'post-main-continuation/compare_debug_prefix.py', 'post-main-continuation/work_freeze_debug_prefix.py', 'post-main-continuation/package_debug_prefix.py', 'post-main-continuation/debug-prefix-source/predeclared.json', 'projection-stack-reserve-frozen/source-receipt.json', 'post-main-continuation/debug-prefix-source/source-review.md', 'post-main-continuation/scope-refinement-prefix.json']:
    inputs[name] = (base / name).read_bytes()
for p in sorted(author.rglob('*')):
    if p.is_file():
        inputs['source-package/' + str(p.relative_to(author))] = p.read_bytes()
changed = subprocess.check_output(['git', 'diff', '--name-only', control, '--', 'crates/dockspace'], cwd=root, text=True).splitlines()
assert changed == ['crates/dockspace/src/layout.rs']
for name in changed:
    inputs['actual-control/' + name] = subprocess.check_output(['git', 'show', control + ':' + name], cwd=root)
    inputs['measured-candidate/' + name] = (root / name).read_bytes()
    assert hashlib.sha256(inputs['measured-candidate/' + name]).hexdigest() == receipt['sources'][name]
raw_count = sum(sum(1 for _ in csv.DictReader(io.StringIO(data.decode()))) for name, data in inputs.items() if Path(name).name == 'raw.csv')
vector_count = sum(Path(n).suffix == '.txt' and any(part.endswith('-states') for part in Path(n).parts) for n in inputs)
assert (raw_count, vector_count) == (16128, 336)
manifest = {n: {'bytes': len(v), 'sha256': hashlib.sha256(v).hexdigest()} for n, v in sorted(inputs.items())}
with tarfile.open(out / 'evidence.tar.xz', 'w:xz', preset=6) as archive:
    for name, data in [*sorted(inputs.items()), ('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode())]:
        info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644; archive.addfile(info, io.BytesIO(data))
with tarfile.open(out / 'evidence.tar.xz', 'r:xz') as archive:
    for entry in archive:
        assert entry.isfile() and not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts
        data = archive.extractfile(entry).read()
        assert json.loads(data) == manifest if entry.name == 'manifest.json' else data == inputs[entry.name]
statistics = {}
for reference in [control, 'imgui']:
    statistics[reference] = {}
    for stat in ['p50', 'p95', 'max']:
        values = [r['reduction_percent_' + stat] for r in comparisons if r['reference'] == reference]
        statistics[reference][stat] = dict(improve=sum(v > 0 for v in values), regress=sum(v < 0 for v in values), ties=sum(v == 0 for v in values), reduction_range_percent=[min(values), max(values)])
report = dict(actual_control_commit=control, candidate_binary_sha256=receipt['binary_sha256'], statistics=statistics, within2x=sum(r['reference'] == 'imgui' and r['candidate_over_baseline_p50'] <= 2 for r in comparisons))
report['qualification'] = dict(ordinary_gates_passed=len(checks['checks']), all_twelve_passed=len(checks['checks']) == 12, performance_screen_only=len(checks['checks']) == 3)
(out / 'measurements.json').write_text(json.dumps(report, indent=2) + '\n')
(out / 'archive-check.json').write_text(json.dumps(dict(regular_input_files=len(inputs), raw_rows=raw_count, complete_vectors=vector_count, all_members_roundtrip_equal=True, archive_bytes=(out / 'evidence.tar.xz').stat().st_size), indent=2) + '\n')
shutil.copy2(author / 'source-review.md', out / 'source-review.md')
shutil.copy2(base / 'post-main-continuation/scope-refinement-prefix.json', out / 'scope-refinement.json')
(out / 'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(out.iterdir()) if p.is_file() and p.name != 'SHA256SUMS'))
print(json.dumps(report, indent=2)); print('Archive inputs', len(inputs), 'raw', raw_count, 'vectors', vector_count)
