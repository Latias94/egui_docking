# Child extent slab on RootStructure + single NodeResult

**READY / STOPPED — temporary candidate only, unapplied, uncompiled and untested.** Only this new directory was written. No repository, fork, cache, old candidate, Cargo, compiler, behavior test, benchmark, timing, Git write, network request or sub-agent was used. The Rust best-practices skill was read before edits. Direct Rust 1.95.0 rustfmt formatted only the two temporary source files, with `edition=2024, skip_children=true`.

## Exact base, recorded before editing

Composition is exact commit `80403cb4bfe66f65a48da490a2aae660091f5f06`, then the frozen 16-path RootStructure overlay, then the complete frozen single NodeResult patch. The two changed files are copied from the latter's checked complete output, not from a drifting live Workspace.

| Input | SHA-256 |
| --- | --- |
| RootStructure patch | `8dc1059d026310e0ef26a9ff5bcb1bca92cd8d00cff62a0bcf833a0c1404ad0b` |
| Single NodeResult patch | `274634d11c456f95515b8428917eb5f9bd439ec9ae96493165ce4408d1a86232` |
| `layout.rs` base | `325f56f16cacbde46cce531461c8830417a6aa8ff4af06f6c87145a7528963df` |
| `layout/projection.rs` base | `d86c008dd78c5f1ed805de76b71d102a29dd3dab4e6ee37ca8f3cb74839edfb0` |
| Sorted two-path base set | `a55a00fcc4d62b6fafa5c294780a629138a57d365cb72f578127b62dc3b42fc2` |

All 16 RootStructure outputs and all 13 single-map outputs were checked against their frozen manifests before the new copies were edited. `base-manifest.json` records the complete composition identities, exact two-path input hashes and unchanged dependency hashes. `base/` and `tree/` contain complete before/after copies of just the two changed paths.

The old slab reference is `/tmp/child-extents-slab/child-extents-slab.patch`, SHA-256 `f87fd2979ea4c78040804cb1a04b737fbb3fb2458d27220c18f650df6dd73654`. Its saved complete files include the rejected solver-aggregate candidate. They were **not** copied as a base or replacement. Only its production storage hunks were transferred, preserving current RootStructure payload access and the single owning NodeMap<NodeResult>. The old slab test hunk is already covered by the current stronger owned-clone/borrow test and was not duplicated.

## Deliverable and scope

- Patch: `child-extents-slab-current.patch`, SHA-256 `3cb323c6d799ce448e431c1944d040ada21c7bc4a55fba215cfcd3534eebbfee`, 4,450 bytes.
- Exactly two paths, **+33/-16, net +17**: `crates/dockspace/src/layout.rs` and `crates/dockspace/src/layout/projection.rs`.
- Candidate `layout.rs`: `e4597343ab8b0f8d69f94bebf7e23e190905dace9e77b942b2187c2ef555d26c`, 47,709 bytes.
- Candidate `layout/projection.rs`: `d770e03663941e840e5e37222d9663092c3e699f27b51dee535d301abc492c60`, 11,889 bytes.
- `manifest.json` binds per-file inputs/outputs, sorted set hashes, the complete patch and scope receipt. `READY.json` binds the final manifest and this README.

Apply this patch only to the exact composed base or explicitly merge its hunks. New root-owned counter additions and any later layout candidates must be preserved. Do not replace a newer whole file with these saved copies. Neither old slab nor frame patches should be applied as extra copies of the same work.

## One storage change

`SplitMap` replaces three private equal-length `Vec<f64>` buffers with one fresh owned zero-initialized `Vec<f64>` of length `3 * E`, where `E = topology.children.len()`. Layout is `[all minima | all maxima | all actual extents]`. The immutable topology remains the only source of E; no length metadata, cache, validity flag or new owner is added.

Two private borrowed accessors use `split_at` / `split_at_mut` to return the disjoint regions. The public `SplitProjection` still exposes the same three borrowed slices with the same field names, child order and per-split lengths. No caller migration is needed. The mutable helper's borrow ends after the unchanged solver writes the actual split range, before `set_outcome` mutates the owner again. No borrowed scratch or input escapes the result.

Only three `layout.rs` substitutions occur: borrow the minimum/maximum/actual regions for the original zip and solver writes, pass that actual region to the same solver, and read the same actual element during child advancement. Reversing those three substitutions reproduces the exact base layout.rs. The existing full continuation fields and `pending_child_size: Option<f64>` are retained. **No frame compaction, pending-size reread transformation, weight fusion or solver-aggregate is included.**

Each output/clone continues to own every extent scalar. Cloning the output deep-copies one slab instead of three buffers; older outputs remain independent. The E=0 leaf-only case has an empty allocation-free child slab and still returns no split rows. `checked_mul(3)` guards internal allocation capacity without introducing a new LayoutError or changing domain validation order. As with existing Vec allocation, capacity exhaustion/contiguous allocation failure is not a recoverable layout result promised equivalent to three separately allocated buffers.

## Cost statement

For a root with nonempty child storage, the explicit child-result backing allocation requests change **3 -> 1**, and the corresponding buffer deallocations change 3 -> 1. A clone has the same reduction. A leaf-only root saves zero such requests. All **3E f64 values** remain initialized and returned, totaling **24E payload bytes** before and after; this is not a reduction of required output data.

For the primary balanced binary fixture, E is `2 * (total_panes - roots)` across all roots:

| Total panes / roots | Total E | Unchanged child payload bytes | Explicit backing requests removed |
| --- | ---: | ---: | ---: |
| 16 / 1 | 30 | 720 | 2 |
| 16 / 4 | 24 | 576 | 8 |
| 1024 / 1 | 2046 | 49,104 | 2 |
| 1024 / 4 | 2040 | 48,960 | 8 |

These are source-level inventories, not measured allocator/system calls, RSS or timing. A larger contiguous allocation can select a different allocator size class, and the accessors can change generated bounds checks. Measurement scratch, solver work, fresh leaf queries, every node/split result, RootStructure construction, complete owned export and all timer boundaries remain unchanged. No speedup, allocation measurement, peak-memory saving or goal attainment is claimed.

## Static checks and retained contracts

`scope-checks.json` records exact byte equality for eight regions: the public solver core; fresh measurement/override and single NodeResult construction; the node-record prefix; splitter geometry; complete numerical validation/solver/inline-test suffix; NodeResult/NodeMap/iterators/public SplitProjection; SplitMap public queries; and SplitMap equality/iterators/single-map output shape. The complete layout.rs also compares identical after reversing only its three slab substitutions.

An independent in-memory patch reconstruction checks exact hunk context and line counts for both outputs. The two private slice helper bodies match the old slab candidate exactly. A read-only composition scan of all 561 Rust source paths confirms no remaining direct access to removed SplitMap Vec fields; only the two intended files use the new private helpers.

The following seven inputs remain unchanged and are hash-bound in `base-manifest.json`: geometry, RootStructure, raw compiler/current measurement implementation, override tests, the single-map topology/ownership/error tests, independent oracle, and docking_cost. In particular, the frozen oracle/capture Adapter remains the single-map version (`2b2eee151d88bdd83048f0dfe7a4931a769aff6616da59e060200819008b209a`), and the complete benchmark source remains `c6ec3cebbaa05cb2b697d8dd32aa739f9f5a696ccce19c652fe49840016c0f10`. No formal/work CSV, fresh layout or exporter path changes.

No tests were added or weakened. Existing registered full-value oracle cases already compare all three public extent slices for n-ary, nested, central, compressed, overridden and raw-DAG layouts. The current owned-clone/borrow test captures all split fields after dropping the original output and Workspace; the late-error test preserves prior outputs after partial private construction. Sparse E=0/generation cases and the registered 10k-depth/drop case remain intact. Their source retention is not a passing test result.

Root owns the next gate: exact-hunk integration after the single-map candidate, serial typecheck/tests covering these existing contracts, then separate controlled comparison and allocation accounting against that same qualified base. All temporary source and patch bytes are now stationary.
