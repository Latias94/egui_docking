"""Freeze the binary measurement gather candidate with the unchanged formal probe configuration."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root = Path('/Users/frankorz/codes/rust/egui_docking')
out = Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e/binary-measurement-gather-frozen')
out.mkdir()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
files = sorted((root / 'crates/dockspace').rglob('*.rs')) + [root / 'Cargo.toml', root / 'Cargo.lock', root / 'crates/dockspace/Cargo.toml', root / 'integration/product-comparison/imgui_docking_cost.cpp']
hashes = lambda: {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
record = {'started_utc': now(), 'sources': hashes(), 'counter_bypass': 'DOCKSPACE_BENCH_NO_WORK_COUNTERS=1', 'normal_validation': '../binary-measurement-gather-verified/'}
command = ['cargo', 'test', '--package', 'dockspace', '--lib', '--profile', 'production', '--locked', '--offline', '--no-run', '--message-format=json-render-diagnostics']
record['command'] = command
env = dict(os.environ, CARGO_BUILD_JOBS='1', DOCKSPACE_BENCH_NO_WORK_COUNTERS='1')
with (out / 'build.stdout').open('w') as stdout, (out / 'build.stderr').open('w') as stderr:
    result = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr)
record['returncode'] = result.returncode
record['sources_unchanged'] = record['sources'] == hashes()
(out / 'source-receipt.json').write_text(json.dumps(record, indent=2) + '\n')
assert result.returncode == 0
assert record['sources_unchanged']
artifacts = [json.loads(line) for line in (out / 'build.stdout').read_text().splitlines() if line.strip().startswith('{')]
executables = [entry['executable'] for entry in artifacts if entry.get('reason') == 'compiler-artifact' and entry.get('executable') and entry.get('target', {}).get('name') == 'dockspace']
assert len(executables) == 1
frozen = out / 'dockspace_docking_cost'
shutil.copy2(executables[0], frozen)
record.update(binary=str(frozen), binary_sha256=hashlib.sha256(frozen.read_bytes()).hexdigest(), finished_utc=now())
(out / 'source-receipt.json').write_text(json.dumps(record, indent=2) + '\n')
(out / 'runtime.patch').write_text(subprocess.check_output(['git', 'diff', '37e388fbc95705204a42e4f8788623873c6ea711', '--', 'crates/dockspace'], cwd=root, text=True))
for relative in subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', 'crates/dockspace'], cwd=root, text=True).splitlines():
    target = out / 'added' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(root / relative, target)
print(frozen, record['binary_sha256'], flush=True)
