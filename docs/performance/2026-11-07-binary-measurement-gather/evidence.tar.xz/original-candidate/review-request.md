Please independently review the stationary `candidate.patch` against the complete immutable base/tree pairs in this package.

Parent: `eb94cb242722962c9e0d88074d81cf462d784357`  
Patch SHA-256: `8db3c0cf34440a48be5563844a872e7e8d36fdf75bacd0d7c908d4b3ea19b7d2`  
Runtime scope: two files, two local gather hunks, +55/-15; no new tests or dependencies.

The author is `/root/mru_rebase_review`; this is an implementation handoff, not an independent approval. Root should obtain a separate source review before qualification or measurement.

Review the exact binary-versus-general child slice selection at both sites. The binary local array must carry the same ordered copied constraints and false central bits as the old gather, remain alive through its composer call, and introduce no alias to mutable NodeResult storage. The fallback must retain the reusable Vec and arbitrary arity.

Confirm that the only composer change is its borrowed argument owner. `compose_constraints`, `compose_minimum`, `compose_maximum`, total-splitter arithmetic, the one numerical executor and all checked boundaries must remain unchanged. Check that a preceding nary gather followed by a binary split cannot expose stale Vec contents.

Pay particular attention to delayed maximum timing: minimum-only measurement and discard, bounds-derived maximum, override validation, postorder per-row updates, Constraints construction and error labels/order. No maximum may be computed early to justify fewer owners.

The raw compiler and independent oracle should remain byte-identical. Projection continuation, raw DAG/last-write behavior, scalar central routing, deep traversal, full old-output ownership and all fresh inputs/export must remain intact. The copied mixed-arity property oracle, delayed/error witnesses, raw diagnostics and retained-output tests are intended qualification coverage; none was executed here.

Report concrete blockers or the source-only boundary. Do not infer speedup from the removed temporary owner. The local array and arity branch can still worsen code generation or complete timings.
