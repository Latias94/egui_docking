**READY for independent source review; source stationary; not qualified.** The parent is immutable `eb94cb242722962c9e0d88074d81cf462d784357`, including retained packed ChildProjection results. The package contains two complete base/tree source pairs and one two-hunk patch, with runtime delta **+55/-15**. No live worktree source was used.

Patch: `candidate.patch`  
SHA-256: `8db3c0cf34440a48be5563844a872e7e8d36fdf75bacd0d7c908d4b3ea19b7d2`

Only `/tmp/binary-measurement-gather/` was written. The Rust best-practices skill was read before the temporary Rust edits. No Cargo, compiler, formatter, tests, runner, timing, profiling, network, delegation, repository/fork/cache or other candidate modification was performed. Static patch/source checks do not constitute Rust qualification.

**The two storage changes.** In `layout/topology.rs`, `RootStructure::measure_with_reader` now matches the existing ordered child-row slice. For exactly two rows, it constructs two local SubtreeMeasurement records with the same copied Constraints and `contains_central: false`, then borrows their array as the original slice argument to `compose_constraints`. Every other arity keeps the reusable child_values Vec, its clear/extend gathering and the original composer.

`layout.rs` applies the same storage choice only inside the existing delayed maximum postorder pass in `project_measurements`. It still calls the original `compose_maximum` slice function, followed by the original Constraints construction. No helper, trait, provider, container implementation or numeric executor was added.

These are the only runtime edits. The sole `compose_constraints`, `compose_minimum` and `compose_maximum` bodies are unchanged. The public and private numerical entry points, arithmetic, fold order, checked-sum labels, total splitter extent, axis arrays, durable/override weights, central route, continuation stack and all projection/output writes remain their parent implementations.

**Delay and errors.** Normal measurement retains the same postorder and leaf callback order. Binary gathering reads the first child then the second; general gathering retains iterator order. Each original composer executes once at its original site with the same ordered record values.

The delayed maximum pass still occurs only after minimum measurement has succeeded and projection has been requested at the original boundary. Minimum-only measurement does not run compose_maximum early; discarding RootMeasurement does not create a projection or perform this pass. The bounds-derived leaf maximum, delayed per-row Constraints construction, override-validation boundary and first failing Result operation retain their order. No validation was removed or moved.

The checked raw compiler's traversal, gather, cardinality/cycle/missing-node checks and central diagnostics are byte-identical. Projection of successfully checked raw topology, its repeated-parent edges and last-write behavior are unchanged. No depth bound, recursive fallback or new fixed-capacity failure was introduced.

**Owners and negative costs.** A fully binary root no longer populates the temporary child_values heap buffer in either changed pass. This is a per-pass owner removal, not a claimed allocation removed for every split: the old Vec was already reused within that pass. Empty Vec construction remains and is not claimed to allocate. Mixed/general-arity trees still populate and reuse the same Vec when needed.

Both local child records remain materialized and copy the same Constraints fields. The new arity branch and local storage can affect stack use, inlining, register pressure and code placement; the compiler may already optimize some original overhead. General-arity or mixed shapes may regress. No type-size, allocation-time share, latency reduction or performance benefit is established.

Fresh NodeResult, SplitOutcome and packed ChildProjection owners remain unchanged, including all minima, maxima, actual extents, following gaps and overflow/unallocated outcomes. Old projections retain their independent values. Fresh leaf answers, identity-checked reads, all-root projection, complete owned export and the formal timer are unchanged. Candidate/staged transaction behavior, MRU and stale identity authority are outside the runtime diff.

**Existing qualification, not new mirror tests.** No test or oracle source changed. The copied independent reference still gathers from its own traversal and uses its own implementation. Relevant existing witnesses include:

- `dense_layout_matches_frozen_traversal`: generated two/three/four-child trees, central choices, complete fields and delayed minimum projection against the independent reference.
- `caller_owned_axis_matches_frozen_solver`: exact numerical results and floating-point bits.
- `constraint_reader_preserves_depth_first_errors_and_override_precedence` and `minimum_measurement_errors_precede_override_validation_for_cold_and_warm_topology`.
- `central_ancestor_depths_keep_fresh_reader_order_and_delayed_minimum_projection`, including leaf roots.
- `projects_ten_thousand_nested_splits_without_call_stack_growth`.
- Raw shared-central, active-cycle, missing-node and measurement-error-priority witnesses.
- `dense_projection_keeps_identity_order_and_owned_old_outputs` and `owned_node_rows_keep_previous_outputs_after_late_geometry_error`.

Root owns independent review, the ordinary qualification gates and complete paired measurements, including all small/large cells and negative tails. This candidate inherits no qualification from the parent or another ownership treatment.

`base-manifest.json`, `manifest.json`, `source-pairs.md`, `scope-checks.json` and `READY.json` bind the immutable source, exact tree and patch. Four unchanged context files provide the independent reference, existing topology/override witnesses and complete probe. They are review inputs, not additional changed paths. Fused continuation, SmallVec, numeric/axis hints, exact-assigned reduction reuse, persistent directories and dependencies are absent.
