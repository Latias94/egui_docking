Source pairs from immutable `eb94cb242722962c9e0d88074d81cf462d784357`. No live source inputs.

| Runtime source | Base SHA-256 | Candidate SHA-256 | Diff |
| --- | --- | --- | --- |
| `crates/dockspace/src/layout.rs` | `ee0bbdadf60b10a3787539e89cdee41411301c3c774e66d53c0146ad1567eaec` | `d28a55c27baeffbedc27ecadf2f1a713d7aed14ff2e501b777e9aea595d0b03d` | +27/-7 |
| `crates/dockspace/src/layout/topology.rs` | `1dd27eb635c84e0d73bf9186eb2e741f400b10e4b36bb6365477ac01c5bd21c6` | `ab10ff27f57c3f03a2336daec731999af7d9c6038076cf4820d4ddf6a461fa44` | +28/-8 |

Unchanged immutable review context:

| Source | SHA-256 |
| --- | --- |
| `crates/dockspace/src/docking_cost.rs` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` |
| `crates/dockspace/src/layout/override_tests.rs` | `f18d00fac60f87cd8fe136df5eb25bb36ffe444bda606ed16db4571568ae7fcb` |
| `crates/dockspace/src/layout/reference.rs` | `4b6ff84c9bed4b65a202e1c771b5f176b161bbb27b99dba25e4875c7b08c07c6` |
| `crates/dockspace/src/layout/topology_tests.rs` | `67671850120413fbaec896b7eea930b7eb52086ccf4864b8486ab21ed8ea1ad2` |

Path-set hash: ascending UTF-8 relative path strings; concatenate path + NUL + lowercase per-file SHA-256 + newline, then SHA-256.

Base set: `35bd51a4e08743cdb00c3c8afb606f5790190f0c984bc26fcb763ee9f98276d0`  
Candidate set: `33725522820ea6e2e078f279a1a5b50dc4e07095ccbbee40ef9feb5b7cf74a4e`
