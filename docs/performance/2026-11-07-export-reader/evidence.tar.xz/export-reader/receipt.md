# Preorder export reader: prepared candidate receipt

Status: PREPARED IN /tmp ONLY; STOPPED pending root's apply/verification decision. No repository source edit, Cargo/build/test execution, benchmark or timing. The source is formatted, not typechecked or executed. No speedup or attribution of the full 52–75 us export budget is claimed.

## Artifacts and exact source

- `export-reader.patch`: unified patch with exact a/crates/dockspace and b/crates/dockspace paths.
- `base/` and `tree/`: complete original and candidate copies of the five paths below.
- `base-hashes.json` and `candidate-hashes.json`: exact per-path identities and diff counts.
- `design.md`: Interface, ownership, cost limits and validation reasoning.
- Patch SHA-256: `5f0351097009ad379ff8847de034196f333c9b2da1c766ef5635f3fb41cc94a3`.
- Five-path aggregate base SHA-256: `cb32d6c749b9b2570b83dfe07ff5d658dcf4b65a20bb9c2301a72eb9ffc813ba`.
- Five-path aggregate candidate SHA-256: `c63708060deb32118e8582185d9fd86ac282cb8cc0f2a9e00f44b8b48a9dfa83`.
- Aggregation uses sorted relative path bytes, NUL, then complete file bytes.
- Diff: 181 added, 6 removed lines. Most additions are API documentation and registered contract tests.

| Proposed path | Exact base SHA-256 |
| --- | --- |
| `crates/dockspace/src/docking_cost.rs` | `c5186bac7b0a2cfe32f3c69b593efdb40a882fea48365d38c2089267abdc8c57` |
| `crates/dockspace/src/engine/splitter_geometry.rs` | `82b640b9bc539a826b8b0bd758bcd2d55e2a6be9f14908bebc6fa0502e1c8e3b` |
| `crates/dockspace/src/engine/splitter_geometry/tests.rs` | `e4e5e111ef77fd794e223e3bd28cf8b29730f9989970d564d016787f870e031d` |
| `crates/dockspace/src/layout/projection.rs` | `c31bfdad6ec84a8714f1d93fa93f97fdb96cb96226349263018da09c62dd742e` |
| `crates/dockspace/src/layout/topology_tests.rs` | `0a045129ebe37bc5cfd365651ab6ad6865f199a34d8b68e5694de4f60ad654a2` |

These saved bases were copied from the actual workspace after leaf-reader had been applied. The three shared leaf-reader paths (`docking_cost.rs`, splitter tests and topology tests) match its published candidate hashes. All five live files still equal the saved base at receipt generation. Solver-aggregate touches only layout.rs, which this patch does not edit; there is no shared file/hunk with that solver patch. If root edits later, transplant these hunks against the saved bases rather than replacing entire files and masking source drift.

## Concrete change

Adds `NodeMap::iter_preorder()` by zipping the existing immutable dense topology nodes with their owned values. Its result is a borrowed, exact-size, fused, double-ended iterator yielding complete generational NodeId references and value references in left-to-right depth-first first-visit order. No new storage, preprocessing, traversal stack, directory or public iterator type is added. Existing sorted iter/keys/values, Index/get, solver, independent reference and rich output ownership are untouched.

The timed exporter still recursively traverses the actual current Workspace, computes every actual path/axis/item/selected field and writes a fresh owned Vec. A single root-local preorder iterator supplies each rect; the exporter compares every yielded complete ID to the actual expected tree node and verifies exhaustion. It also reuses one actual Workspace node read instead of performing the identical lookup twice. Timer boundaries and output content/capacity policy are unchanged.

The real resize frontier walker also consumes this same iterator while traversing live children, comparing every full ID and checking exhaustion. It replaces repeated current-node rect joins; all visited/authority/constraint/split/gap/child-geometry/interval checks and their arithmetic remain. It intentionally rejects a layout whose preorder no longer matches the actual tree, including equal-extent child swaps. A remaining once-per-root rectangle lookup, constraint joins and direct-child geometry checks are not optimized in this bounded candidate.

## Registered contracts

- Existing sparse/recycled/n-ary/central cold/warm oracle fixture now checks complete preorder IDs and frozen rect values, exact size hints and decrementing len, repeated end exhaustion, and mixed front/back traversal of generic constraint values. Existing sorted iteration and generation exclusion checks remain.
- Existing owned-old-output test rereads the entire saved preorder after a second projection and dropping index and Workspace.
- New `docking_cost::preorder_export_matches_the_keyed_export_for_all_primary_commands` compares every exported word against a test-local preserved old keyed exporter, and then the existing independent normalized expected state. It runs resize/center/edge at one/four views and cross-view at four views on fresh actual 16-pane fixtures. The old exporter stays local to the test and outside measured paths.
- New `frontier_rejects_a_reordered_live_tree_with_equal_child_extents` constructs a legal Builder change under unchanged outer bounds/handles and checks the production reader rejects old projection/live-order mismatch.

No legacy unregistered test is counted as evidence. The independent reference file was not edited and remains SHA-256 `93afdf6e8ad79d81f2efdafc4814a4bb6076fd9f535129f82ce33f9ee12ddf4e`. The active 10k test remains registered without change.

## Checks and next gate

Only direct rustfmt with edition 2024 and skip_children ran on the temporary copies. The complete unified diff was read back, and the five saved/live base pairs were compared byte for byte. No code was built or executed. Root should apply only after its chosen leaf-reader/solver freezes, run serial compilation plus the new registered contracts and existing full geometry tests, then compare identical full owned exports through its normal paired matrix. Source-level deletion of lookups is not a measurement of the export budget. This lane has stopped.
