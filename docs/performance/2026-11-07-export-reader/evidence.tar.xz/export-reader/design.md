# Reuse the owned projection's existing preorder for complete readers

This is one bounded candidate, prepared only in /tmp. A1's reported 1024-pane export phase is approximately 52–75 us; no timing has attributed that whole phase to NodeMap lookup. The candidate has not been built or measured.

## Interface and its actual invariant

```rust
impl<T> NodeMap<T> {
    pub fn iter_preorder(
        &self,
    ) -> impl DoubleEndedIterator<Item = (&NodeId, &T)>
           + ExactSizeIterator
           + FusedIterator;
}
```

The Implementation zips `topology.nodes.iter()` with the existing owned values, yielding `(&row.id, value)`. It does not walk the sorted directory or search an ID. Both sealed cold compilation and raw checked compilation assign dense rows on first Enter in left-to-right DFS order; warm measurements retain that same immutable topology. Runtime Workspaces are trees, so every reachable node appears once in ordinary preorder. The diagnostic-only DAG path preserves once-per-identity first-visit order, rather than promising one result per repeated edge.

This Seam exposes an ordering already retained in the complete result. It adds no slab, metadata, allocation, per-root sorting, Workspace borrow, preprocessing or extra layout pass. The result still retains its complete NodeId, including generation. It does not claim that an old projection authorizes a current workspace or command.

Sorted `iter/keys/values`, Index/get, equality and debug behavior stay unchanged. A caller choosing preorder expressly requests tree order; no existing sorted API silently changes. The same generic method works for rectangles and constraints without a new public row struct or iterator implementation.

## Export Adapter

The complete exporter still uses the actual Workspace tree to determine current root, child ordering, path, split axis, ordered items and selected item. It keeps one preorder iterator per root, passes it through its existing recursion, and for each actual node:

1. reads the next complete projected identity and rectangle;
2. compares the identity with the actual expected NodeId;
3. reads the current Workspace node once and retains that immutable borrow;
4. emits the original full header/item sequence and traverses the real children.

It verifies the iterator is exhausted after the root. An order, generation, missing-node or extra-node mismatch cannot silently associate one node's rectangle with another node's semantic record. The primary matrix remains binary and retains its binary assertion. This is not a serialized cached snapshot: every export continues to produce its fresh owned Vec and read actual semantic state inside the original export interval.

The deleted work is one NodeMap binary search and one identical Workspace node lookup per exported node. For valid 1024-pane resize, the complete roots contain 2047 nodes at one view or 2044 at four views. Each former search becomes one next operation and one full-ID comparison. Export now joins O(N) sequential rows rather than performing N O(log N) identity lookups. Workspace arena lookup and every real semantic read remain. The compiler may already eliminate some duplicate node lookups; the source count is not an instruction count or measured time.

This change removes no output allocation. Path arithmetic, root traversal, all integral/finite checks, all item words and selected intent, header encoding, Vec writes, returned ownership and the normal member/state checks remain. Those are part of the reported export budget, so a 52–75 us improvement is neither predicted nor justified from this source review. At worst, the new explicit ID comparisons or code generation could offset some saved search work; the paired comparison must decide.

## Production consumer

The resize frontier walker already traverses the entire actual root in DFS order. It now consumes `projection.node_rects.iter_preorder()` in parallel, compares each complete identity and checks final exhaustion. Its current-node rect is reused for interval and split checks. The existing root bound check, visited set, incident bookkeeping, source authority, constraint queries, direct-child rectangles, split/gap validation and numerical interval calculations are kept.

The new order match is intentional: equal child extents alone do not establish that retained geometry belongs to the current ordered tree. A legal Builder edit which swaps equal-size descendants while preserving outer handles is rejected rather than borrowing old child positions. This is geometric correspondence, not a replacement command proof. A selection change with identical structural IDs/order still permits ordinary geometry reuse subject to the unchanged current measurements/authority rules.

The first bounded migration leaves one root rect lookup, constraint lookups and the direct-child validation joins in place. It does not need a projection-wide row framework, a multi-map zip authority type, additional topology storage or a new validation/cache Module to be useful.

Scene compilation currently uses identity-sorted record order and has its own error/emission order. That consumer is not changed merely to gain another call site; changing its traversal would need separate semantic review. The real resize reader supplies a production use without that unrelated change.

## Independent checks

The existing sparse/recycled fixture supplies an independently written expected preorder unlike NodeId ordering, nonuniform constraints, n-ary/opposite-axis splits, a central leaf and another root. It now compares each yielded complete ID and rectangle against the frozen keyed oracle, checks exact iterator size and mixed front/back behavior, and retains all original sorted/generation tests. The old-output test traverses saved owned rows after creating a different second output and dropping index and Workspace.

A registered exporter test preserves the previous keyed algorithm locally to the test and compares every fresh exported word after each actual primary interaction: resize/center/edge with one/four roots and cross-view move with four. It also compares the normalized expected-state oracle. No preserved exporter runs on the timed path. A production resize contract test covers the equal-size descendant swap described above. The frozen layout oracle, solver, registered 10k traversal/drop test, full rich output storage and benchmark phase boundaries are untouched.

Root should retain the previous binary/source, compile and execute these contracts serially, then perform the same paired full-work matrix. New and old full exports must agree; source lookup removal alone does not qualify performance or correctness.
