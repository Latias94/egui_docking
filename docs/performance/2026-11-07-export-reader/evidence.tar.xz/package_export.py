"""Archive the leaf-reader checkpoint, including regressions and all raw tails."""
from pathlib import Path
import csv, hashlib, io, json, shutil, tarfile
ROOT=Path('/Users/frankorz/codes/rust/egui_docking')
BASE=Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
OUT=ROOT/'docs/performance/2026-11-07-export-reader'
OUT.mkdir(exist_ok=True)
comparisons=[]
for reference in ('baseline','imgui'):
 rows=list(csv.DictReader((BASE/'export-reader-frozen'/f'against-{reference}/summary.csv').open()))
 cells={}
 for row in rows:cells.setdefault(tuple(row[k] for k in ('group','panes','views','case')),{})[row['condition']]=row
 for (group,panes,views,case),pair in cells.items():
  row=dict(reference='5ea7fbb' if reference=='baseline' else reference,group=group,panes=panes,views=views,case=case)
  for stat in ('p50','p95','max'):
   old=float(pair['baseline']['operation_owned_ns_'+stat]);new=float(pair['candidate']['operation_owned_ns_'+stat])
   row.update({f'baseline_ns_{stat}':old,f'candidate_ns_{stat}':new,f'candidate_over_baseline_{stat}':new/old,f'reduction_percent_{stat}':(1-new/old)*100})
  comparisons.append(row)
with (OUT/'comparisons.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(comparisons[0]),lineterminator='\n');writer.writeheader();writer.writerows(comparisons)
checks=[json.loads((BASE/'export-reader-verified'/name).read_text()) for name in ('checks-fmt,targeted,workspace,clippy.json',)]
assert all(c['normal_counters_enabled'] and c['sources_unchanged'] and all(x['returncode']==0 for x in c['checks']) for c in checks)
receipt=json.loads((BASE/'export-reader-frozen/source-receipt.json').read_text())
assert receipt['sources_unchanged'] and all(all(receipt['sources'][p]==h for p,h in c['sources'].items()) for c in checks)
for reference in ('baseline','imgui'):
 env=json.loads((BASE/'export-reader-frozen'/f'against-{reference}/environment.json').read_text())
 assert env['complete_state_equal'] and env['frozen_executables_unchanged'] and env['source_tree_matches_frozen_candidate_at_finish']
inputs={}
for directory in ('export-reader-frozen','export-reader-verified'):
 for p in sorted((BASE/directory).rglob('*')):
  if p.is_file() and p.suffix in ('.rs','.patch','.json','.csv','.txt','.stdout','.stderr','.log'):
   inputs[str(p.relative_to(BASE))]=p
for name in ('baseline.json','compare_export.py','freeze_export.py','verify_export.py','package_export.py','leaf-export-review.md','leaf-export-review-hashes.json'):
 p=BASE/name;assert p.is_file(),p;inputs[name]=p
for p in sorted(Path('/tmp/export-reader').rglob('*')):
 if p.is_file() and p.name in ('export-reader.patch','design.md','receipt.md','base-hashes.json','candidate-hashes.json'):
  inputs['export-reader/'+str(p.relative_to('/tmp/export-reader'))]=p
raw_rows=sum(sum(1 for _ in csv.DictReader(p.open())) for name,p in inputs.items() if Path(name).name=='raw.csv')
vectors=sum(1 for name in inputs if Path(name).suffix=='.txt' and any(part.endswith('-states') for part in Path(name).parts))
assert (raw_rows,vectors)==(16128,336),(raw_rows,vectors)
manifest={name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(inputs.items())}
with tarfile.open(OUT/'evidence.tar.xz','w:xz',preset=6,format=tarfile.PAX_FORMAT) as archive:
 for name,p in sorted(inputs.items()):
  entry=tarfile.TarInfo(name);entry.size=p.stat().st_size;entry.mode=0o644
  with p.open('rb') as f:archive.addfile(entry,f)
 data=(json.dumps(manifest,indent=2)+'\n').encode();entry=tarfile.TarInfo('manifest.json');entry.size=len(data);entry.mode=0o644;archive.addfile(entry,io.BytesIO(data))
with tarfile.open(OUT/'evidence.tar.xz','r:xz') as archive:
 for entry in archive:
  assert entry.isfile() and not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts
  data=archive.extractfile(entry).read()
  if entry.name=='manifest.json':assert json.loads(data)==manifest
  else:assert data==inputs[entry.name].read_bytes()
(OUT/'checks.json').write_text(json.dumps({'normal_counters_enabled':True,'checks':[x for c in checks for x in c['checks']],'sources_match_formal_receipt':True,'work_probe':'Not rerun: preorder output iteration leaves command/clone work unchanged.'},indent=2)+'\n')
for name in ('leaf-export-review.md',):
 shutil.copy2(BASE/name,OUT/Path(name).name)
(OUT/'archive-check.json').write_text(json.dumps({'regular_input_files':len(inputs),'raw_rows':raw_rows,'complete_vectors':vectors,'all_members_roundtrip_equal':True,'archive_bytes':(OUT/'evidence.tar.xz').stat().st_size},indent=2)+'\n')
(OUT/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print('Archived',len(inputs),'files;',raw_rows,'raw rows;',vectors,'vectors;',sum(x['reference']=='imgui' and x['candidate_over_baseline_p50']<=2 for x in comparisons),'/42 within 2x')
for ref in ('5ea7fbb','imgui'):
 for stat in ('p50','p95','max'):
  values=[x['reduction_percent_'+stat] for x in comparisons if x['reference']==ref]
  print(ref,stat,'range',min(values),max(values),'negative',sum(v<0 for v in values))
