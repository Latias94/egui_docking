# Binary inputs on the retained frame parent

READY / source stationary / tmp only. No compilation, behavior test,
runner, profile, benchmark or timing was run. No repository, fork, cache,
old candidate, Git write, network or sub-agent was used. Root alone owns
verification and performance decisions; this is not qualified.

## Exact composition

base/ equals /tmp/projection-frame-retained/tree across all five
files. That parent is immutable e3 plus only compact frames. Slab and
childrows are absent. This own patch contains only binary input arrays
in layout.rs; it does not reinstall frame or its test.

The original three /tmp/binary-split-inputs-3vec/candidate.patch hunks
(SHA-256 48f8bf0cafdb29d1771728a2a36b5b8c911c10cb44aa91011a2536e026d7c3f0)
match exactly once without content/context adaptation; only line offsets
change. Two actual children use a local AxisConstraint array, and two
actual weights with two children use an exact f32-to-f64 local array.
Overrides retain priority and their complete borrowed f64 precision.
General/mismatched arities still clear/refill the original scratch Vecs
and use the same checked solve_axis_into. Old Vec capacity is never
mistaken for current input. No alternative binary solver, arithmetic,
cache, unsafe, small-container dependency or weakened validation exists.

All code outside prepare is unchanged from the frame parent. The full
raw compiler/reference and e3 slice composition remain unchanged. No
test/framework or fixture/timer/export change is added. Existing mixed
arity/cardinality, constraints/waterfill, central, f64 overrides, raw DAG,
late-error/old-output and complete oracle cases remain root's gates.

Negative cost: local arrays and branch/code layout can cost more than the
saved temporary Vec fill. Generic scratch remains for actual n-ary
inputs. Fresh leaf/output work is unchanged. There is no allocator share
or performance benefit claim.

## Artifact boundary

candidate.patch applies to matching base/ hunks only. Complete base/tree
pairs and unchanged context files are review inputs, not instructions to
overwrite later whole repository files. The next independent slice must
use this exact tree or explicitly rebase it if root rejects a prerequisite.
Both rejected experiments remain absent; fewer owners was not a measured
win. Composition helpers preserve original &[SubtreeMeasurement]
signatures, and reference.rs still uses its original calls/bool records.

Patch SHA-256: `fc5674ab966b59c7830d9c3c13ec0644d851956cb7941e27c2ff06b438dc93d8`.

Five-file base set: `07f1c6efc319077d05910c42c717f6e387e1e2f36a26a52134615c7233f107f7`.
Tree set: `6aff73c1aa124fa3fe02287016de5fcce41e47ac68d2bfddb64d56f1bb6aca90`.

base-manifest.json, rebase-hunks.json, scope-checks.json, manifest.json
and READY.json bind exact identities. Set format is sorted UTF-8 relative
path + NUL + file SHA-256 + newline. Original hunk bodies uniquely match;
the patch passes read-only git apply --check --whitespace=error in its
own temporary base. No Rust behavior was executed. Rust best-practices
was read; no new Rust text beyond the original exact hunks was authored.
