# Initial issuance oracle coverage

All proposed tests are unrun. Direct rustfmt only parsed/formatted the two temporary source files. No Cargo, compiler, test executable, benchmark, timing or Git write was used.

## Two proposed tests in the existing owner_reference module

| Test | Oracle and concrete coverage |
| --- | --- |
| `initial_issuance_uses_actual_mixed_carriers_and_rebuilds_fresh_refs` | Reuses the three-root fixture, adds one leaf/root and reassigns actual carriers to a main-plus-contained surface, a rootless contained-only surface and another main surface. Surface discovery order differs from RootId order. Calls the real Builder twice. The existing `assert_actual_placement` derives full membership, direct parent indices and paths from actual root/child records; it also compares owned carriers to the independent raw roster search. The test verifies equal durable values after rebuild, fresh refs for every rebuilt root and Source-role stale rejection of the original build's refs. It exercises the nontrivial split in root A as well as leaf roots. |
| `initial_issuance_preserves_empty_workspace_and_builder_presentation_errors` | Calls the real empty Builder path and checks equality to Workspace::new, empty root/surface maps, absent root authority and MissingRoot capture. Reuses the existing valid fixture for five malformed cases: foreign main root, missing contained record, duplicate root carrier, empty/unpresented surface/root and contained record referencing a foreign root. For each, captures the strict validator's complete ordered typed errors and requires Builder::build to return the identical `CanonicalizationError::InvalidOutput` collection. No malformed production Workspace is created. |

The mixed-carrier test's oracle stays independent of the new discovery algorithm: it uses actual rooted child traversal and the unchanged per-root `presentation_in_storage` scan, rather than recreating the sorted carrier list under test. It is behavioral coverage, not a source-text count or a mock discovery provider.

The malformed cases are canonical graphs whose only errors are presentation errors, so no earlier rewrite/input error is expected to obscure the strict output comparison. The full validator and gate order are unchanged in source. The tests compare complete typed errors, not only an error count or broad `is_err` assertion.

## Existing oracles retained without edits

- `clone_keeps_exact_refs_independent_build_and_published_aba_reject_them` exercises immutable clone sharing, independent Builder issuance and value-identical published ABA.
- `same_version_index_rejects_changed_and_foreign_issuers_and_retains_unrelated_roots` and the recycling case cover exact root refs, stale/foreign index origin and full generational membership.
- `cross_root_subtree_and_staged_merged_residue_have_actual_placement`, the real newborn/donor stage test and the local/general Item matrix compare the normative directory to actual graph placement.
- `strict_validation_enforces_root_presentation_and_backlinks` and `strict_validation_preserves_the_first_owner_across_three_presentations` in `tests/graph_model.rs` retain malformed-carrier diagnostics.
- Existing import/persistence tests continue crossing Builder's full canonical/validation gate. Their files and serialization format are unchanged.

## Static arguments and limits

Ascending issuance order follows directly from sorting the RootId pairs before calling birth; the public BTreeMap root iteration order alone would not prove allocation/issuance order. The valid workspace has exactly one carrier per root. Actual-root filtering, stable first-match deduplication and the coverage count preserve the previous private missing-carrier/foreign-root behavior without adding another validator. Those internal malformed-input compatibility details were source-traced; no new unchecked publishing seam was added for a test.

The single discovery pass is established by its one surface loop and one nested roster loop, with no per-root carrier search in `issue_storage` or `complete_root_birth`. This is a source complexity claim only. No new work counter or benchmark protocol is introduced. Roster resolution still uses BTreeMap lookups and sorting has O(R log R) work and O(R) temporary storage; full Builder validation/canonicalization and all independent geometry fingerprints remain outside this claim.

Root's later qualification should run the two new tests plus the existing graph/owner/index/placement/import checks. Cold scale fixtures can establish wall-time impact after integration. Primary kernel timing must retain its original timer boundary; no improvement is predicted for a kernel which starts after fixture construction.
