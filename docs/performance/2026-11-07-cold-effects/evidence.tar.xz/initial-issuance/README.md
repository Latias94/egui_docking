# Initial issuance from one carrier discovery pass

Status: temporary proposal only; not applied, compiled, tested or timed. This is an incremental patch after the exact prepared-report + candidate-copy + combined-cold proposals. Repository source and those original temporary artifacts were not edited. Only the two proposed copies in this directory were formatted with direct rustfmt.

Complete patch: `initial-issuance.patch`, SHA-256 `0c18795d42f09e9fce35fec22732f9a37c2ec1939dd9c96fec08ad65c54d7176`.

Runtime-only view: `runtime.patch`, SHA-256 `615423286900b0c7eb7ba8645e75f742cb626cc252d6abe30f066f0a55ccbdac`. It changes one file by +29/−27 lines, deletes the unused refresh method and reuses the existing concrete birth completion. `tests.patch` is an alternative inspection view of the two appended tests, not another patch to apply after the complete patch.

## Confirmed consumer and scope

In the combined cold output, the only caller of `refresh_root_placement` is `issue_storage`. Its only caller is `canonical::build_workspace`, after `canonicalize_data` has run the complete input, item-multiset and strict output gates. WorkspaceBuilder/import share that path; initial default-empty Workspace construction needs no issuance. Actual command births already use `complete_root_birth` and do not need this initial discovery.

`presentation_in_storage` is not unused: `Workspace::root_fingerprint` still needs the actual storage carrier, the independent placement oracle compares it with the owned carrier, and `complete_root_change` retains its existing invariant diagnostic fallback. This proposal keeps that helper and every caller. It removes only the now-unused initial refresh method and its repeated roster searches.

The Module remains the closed graph owner. Its Interface and publishing gates do not change. The Implementation exchanges the old temporary Vec of RootIds for one consumed temporary Vec of `(RootId, RootPresentationOwner)`. There is no new inventory struct, persisted directory, cache, valid bit, provider, executor or public Seam.

## Concrete algorithm and identities

1. Traverse actual surfaces in their existing BTreeMap order. Push each real main root's known Main owner, then each real contained root's known Contained owner in roster order. Each surface and contained roster entry is visited once; contained records are resolved by the existing BTreeMap lookup.
2. Stable-sort the temporary pairs by RootId. For already validated input, there is exactly one pair per root. The small dedup/filter checks retain the old private diagnostic behavior described below; they do not replace or bypass strict validation.
3. Require coverage of every actual root using the original `CommandError::Invariant { stage: "refresh root presentation authority" }` diagnostic.
4. Consume the pairs in ascending RootId order and invoke the existing `complete_root_birth`. It reads the actual root record, assigns actual subtree/parent placement and issues one fresh exact Arc. No roster scan is performed by birth completion.

Initial issuing remains in stable root order, matching the old roots-key loop rather than the order in which surfaces happen to carry roots. A Workspace clone retains existing refs; an independently rebuilt value-identical Workspace receives different refs. No geometry/value fingerprint is substituted for authority.

The input is already fully validated in production. For internal malformed diagnostics, collecting only actual roots also preserves the old handling of foreign presentation root IDs; missing floating records are skipped exactly as the old scan skipped them. Stable sort plus first-entry dedup preserves the old preference for the first surface/main/contained match. After filtering/deduplication, equal root counts imply complete coverage because every retained key is an actual distinct root. A missing carrier therefore keeps the same typed Invariant error. Any partially built private candidate on failure remains unobservable. These checks add no new public acceptance of malformed Builder/import input: its original strict errors still occur before issuance.

The valid empty storage still produces empty carrier/authority/placement tables. A foreign capture on that Workspace still returns MissingRoot. Invalid surface/main/contained references and unpresented or multiply presented roots still fail the unchanged full validator with the same ordered error collection.

## Cost boundary

Let R be actual roots, S surfaces, C contained roster entries, F contained records and N reachable node occurrences. On valid input there is one discovered pair per root and one roster owner per floating record.

The old initial issuer performs up to R complete carrier searches. The discovery term is worst-case `O(R * (S + C * log(F + 1)))`, in addition to its existing subtree assignment and authority-map costs. R main roots on R surfaces exhibit the familiar sum of roster prefixes, `R * (R + 1) / 2`; one surface with R contained roots similarly repeats contained prefixes and record lookups.

The new discovery visits S surfaces and C roster entries once. Actual-root filtering costs BTreeMap lookups, contained resolution costs `O(C * log(F + 1))`, stable sorting costs `O(R log(R + 1))`, and birth insertion/lookups cost `O(R log(R + 1))`. Rooted node assignment remains O(N) expected directory/arena work. A conservative combined expression is `O(N + S + (S + C + R) * log(R + 1) + C * log(F + 1))`. This is not a claim of allocation-free or strictly linear whole-Builder work.

The one temporary pair Vec replaces the previous root Vec. Pair storage and stable-sort scratch are O(R); Arc issuance, BTreeMap storage, subtree work stacks and all initial graph/payload allocations remain real. The temporary pairs are consumed and dropped during initial issuance, not retained in Workspace.

This addresses initial Builder/import cost visible in cold scale setup. Normal single Select/Item Move and the formal docking kernel do not call `issue_storage`; its fresh fixture construction is outside that kernel timer. Do not attribute a primary-kernel speedup or any measured gain to this source proposal. General canonicalization, real geometry/index fingerprint capture and all remaining scans are unchanged.

## Exact base and integration

Apply only after `cold-effects-combined/cold-after-report-copy.patch` (SHA-256 `94668387c35a896e4ac1926c868b719296bc1a605457f19c92bb3b6d1114ab60`) and its two preceding dependencies. The changed inputs must match these hashes:

| Path under crates/dockspace/src | Exact input SHA-256 | Proposed SHA-256 |
| --- | --- | --- |
| graph/authority.rs | `6686d5767ec12dbd4e0ce9c39c6ccb78412b4f742a95ade18c39977dad75b467` | `b1a71a5ca26202f94dd46a6b47676225c22e9d08769a990b3b7c737b28ed4f2a` |
| operation/tests/owner_reference.rs | `22f13bcb417d45bca9c8d9126cd95c8d97e84076c068443de0789814a26582f1` | `4a170b0e6d0f3bc48d888a061db1065795a77d7eaf8f46df802c8d29d20ef869` |

`base/` and `proposed/` retain the exact source pairs; `base-sha256.json`, `proposed-sha256.json` and `receipt.json` provide machine-readable hashes and read-dependency locations. No other source file is part of this slice. The appended tests reuse the existing fixture and actual-placement oracle; see `oracle-coverage.md` for what they establish and what remains unrun. Root owns later integration, qualification and any cold-scale measurements.
