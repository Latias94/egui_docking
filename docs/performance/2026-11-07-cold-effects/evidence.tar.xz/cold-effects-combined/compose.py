"""Compose only these frozen temporary source proposals; never touch the repo."""

from difflib import SequenceMatcher, unified_diff
from hashlib import sha256
import json
from pathlib import Path


ROOT = Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
OUT = ROOT / 'cold-effects-combined'
COLD = ROOT / 'cold-effects-candidate'
REPORT = ROOT / 'candidate-report-slice'
COPY = ROOT / 'candidate-copy'


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def read_manifest(directory, name, tree):
    manifest = json.loads((directory / name).read_text())
    for rel, expected in manifest.items():
        assert expected == digest(directory / tree / rel), rel
    return manifest


def edits(original, changed):
    return [
        (start, end, changed[new_start:new_end])
        for kind, start, end, new_start, new_end in SequenceMatcher(
            None, original, changed, autojunk=False
        ).get_opcodes()
        if kind != 'equal'
    ]


def overlap(left, right):
    a, b, _ = left
    c, d, _ = right
    return (
        max(a, c) < min(b, d)
        or (a == b and c <= a < d)
        or (c == d and a <= c < b)
        or a == b == c == d
    )


report_outputs = read_manifest(REPORT, 'proposed-sha256.json', 'proposed')
copy_outputs = read_manifest(COPY, 'after-prepared-report-sha256.json', 'after-prepared-report')
cold_receipt = json.loads((COLD / 'candidate-receipt.json').read_text())
dependencies = {
    'prepared_report': {
        'path': str(REPORT / 'candidate-report.patch'),
        'sha256': '1b0a17402068d3b2d782bbe5e39538cb3366e30f6b0a45e95236293e815425b9',
    },
    'copy_after_prepared_report': {
        'path': str(COPY / 'candidate-copy-after-prepared-report.patch'),
        'sha256': '9a4e41c222741a944e23ddaf5a45e21a27bd2cec9d76646abe9937116342e2dd',
    },
    'original_cold': {
        'path': str(COLD / 'candidate.patch'),
        'sha256': 'e2585debdd47e94b2582e628b07575ea9259d9636b115cbb89cf38e14f1211c6',
    },
}
for dependency in dependencies.values():
    assert digest(Path(dependency['path'])) == dependency['sha256']
for rel, expected in cold_receipt['patches'].items():
    assert digest(COLD / rel) == expected

patches = []
runtime = []
tests = []
inputs = {}
outputs = {}
file_receipts = {}
original_diff = []
for rel, expected in cold_receipt['files'].items():
    original_path = COLD / 'base' / rel
    cold_path = COLD / 'candidate' / rel
    assert digest(original_path) == expected['sha256']
    assert digest(cold_path) == expected['candidate_sha256']
    original = original_path.read_text().splitlines(keepends=True)
    cold = cold_path.read_text().splitlines(keepends=True)
    original_diff.extend(unified_diff(original, cold, fromfile='a/' + rel, tofile='b/' + rel))

    if rel in copy_outputs:
        base_path = COPY / 'after-prepared-report' / rel
    elif rel in report_outputs:
        base_path = REPORT / 'proposed' / rel
    else:
        base_path = original_path
    base = base_path.read_text().splitlines(keepends=True)
    prior_edits = edits(original, base)
    cold_edits = edits(original, cold)
    assert not any(overlap(a, b) for a in prior_edits for b in cold_edits), rel
    merged = original[:]
    for start, end, replacement in sorted(prior_edits + cold_edits, reverse=True):
        merged[start:end] = replacement

    for tree, lines in [('base', base), ('proposed', merged)]:
        path = OUT / tree / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(''.join(lines))
    difference = list(unified_diff(base, merged, fromfile='a/' + rel, tofile='b/' + rel))
    patches.extend(difference)
    (runtime if rel in {
        'crates/dockspace/src/graph/authority.rs',
        'crates/dockspace/src/canonical.rs',
        'crates/dockspace/src/operation.rs',
    } else tests).extend(difference)
    inputs[rel] = digest(OUT / 'base' / rel)
    outputs[rel] = digest(OUT / 'proposed' / rel)
    file_receipts[rel] = {
        'exact_input_source': str(base_path),
        'input_sha256': inputs[rel],
        'output_sha256': outputs[rel],
        'prior_line_edits': len(prior_edits),
        'cold_line_edits': len(cold_edits),
        'line_edit_conflicts': 0,
        'added': sum(line.startswith('+') and not line.startswith('+++') for line in difference),
        'removed': sum(line.startswith('-') and not line.startswith('---') for line in difference),
    }

assert ''.join(original_diff) == (COLD / 'candidate.patch').read_text()
for name, lines in [('cold-after-report-copy.patch', patches), ('runtime.patch', runtime), ('tests.patch', tests)]:
    (OUT / name).write_text(''.join(lines))

# Scope the seal to all preceding outputs plus the seven cold changed files.
full_inputs = report_outputs | copy_outputs
full_outputs = full_inputs | outputs
full_inputs.update({rel: inputs[rel] for rel in inputs})
for name, content in [
    ('base-sha256.json', inputs),
    ('proposed-sha256.json', outputs),
    ('combined-input-sha256.json', full_inputs),
    ('combined-output-sha256.json', full_outputs),
]:
    (OUT / name).write_text(json.dumps(content, indent=2) + '\n')

receipt = {
    'status': 'temporary-only-uncompiled-untested-not-applied',
    'dependencies': dependencies,
    'files': file_receipts,
    'patches': {
        name: digest(OUT / name)
        for name in ['cold-after-report-copy.patch', 'runtime.patch', 'tests.patch']
    },
    'checks': {
        'dependency_hashes': True,
        'original_cold_exact_diff': True,
        'line_edit_conflicts': 0,
        'original_artifacts_unchanged': True,
        'compiled': False,
        'tested': False,
        'applied_to_repo': False,
    },
}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'patches': receipt['patches'], 'files': len(inputs)}, indent=2))
