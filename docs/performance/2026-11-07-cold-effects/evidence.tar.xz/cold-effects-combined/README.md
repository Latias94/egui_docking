# Cold effects after prepared report and candidate copy

Status: temporary source composition only; not applied, compiled, tested or timed. The independent source review found no confirmed correctness/scope blocker. See `independent-review.md` for the reasoning and qualification limits. This directory does not replace or edit common's original `cold-effects-candidate` artifacts.

Apply ordering for root's later independent integration:

1. `candidate-report-slice/candidate-report.patch` — SHA-256 `1b0a17402068d3b2d782bbe5e39538cb3366e30f6b0a45e95236293e815425b9`.
2. `candidate-copy/candidate-copy-after-prepared-report.patch` — SHA-256 `9a4e41c222741a944e23ddaf5a45e21a27bd2cec9d76646abe9937116342e2dd`.
3. This directory's **incremental** `cold-after-report-copy.patch` — SHA-256 `94668387c35a896e4ac1926c868b719296bc1a605457f19c92bb3b6d1114ab60`.

Do not additionally apply the original cold patch or the A1-only copy variant. Leaf-reader/export-reader paths are outside these changes. The optional no-op-reference and docking-work CSV additions are separate proposals and are not silently included here.

`base-sha256.json` and `proposed-sha256.json` seal the seven paths changed by this incremental patch. `combined-input-sha256.json` seals the preceding report/copy outputs plus the three untouched cold base paths; `combined-output-sha256.json` seals their final combined output. These inventories cover the 19 affected/dependency paths, rather than pretending to be a frozen full repository or build receipt. Root should compare every changed input to its exact base before integration.

The complete seven-path patch is split for inspection into `runtime.patch` and `tests.patch`, with hashes `45dd508471bc003f4ae9e8f3509c4e007445bb49ed8a9dae83f9438eec0e5619` and `8cd4d29cf29671b6966535c0a13b801044e545638198bd0086d654600d068e62`. Use the complete patch once; the split files are alternative views. Runtime remains +162/−165, a net reduction of three lines across the same three runtime files.

Composition uses exact temporary copies, not repository patch application. `compose.py` verifies all three source proposal hashes, every source receipt and the original cold diff's equality to its seven base/candidate pairs, rejects overlapping edited line intervals and writes only this directory. No edited line intervals overlap. The following adjacent/shared-context changes were reviewed explicitly:

| Path | Preserved from the preceding slices | Preserved from cold effects |
| --- | --- | --- |
| canonical.rs | Whole-record NodeStore replacement; read-only store iteration and malformed raw fixture migration | Exact rewrite boolean/result; retired IDs; no fingerprint-based completion |
| operation.rs | Private completed candidate/report; parameterless consuming accessors; exact single Item outcome; one final general equality; borrowed retired Arc | Concrete birth/donor/move/rehome/close completion; private selected/MRU helper; deleted cold dispatch protocol |
| drop_resolver.rs | Prepared candidate read accessor and physical storage ledger definitions | Scoped effect-fingerprint zero expectations; original logical clone inventory retained |
| owner_reference.rs | Prepared read accessor and shared-storage recycling extraction | Existing late-output work checks plus prefix ABA and literal no-op follow-up tests |

`base/` and `proposed/` hold only these seven changed files. The other dependency outputs stay in their original temporary directories. `receipt.json` records their source locations, exact hashes and line-edit counts. No new runtime abstraction, executor, dependency or publication path was introduced during composition. No Cargo, compiler, test, benchmark, timing or Git write was run. Static source/hash composition is the only mechanical evidence supplied here.
