# Item-frontier placement candidate

Prepared for the root agent to review and verify. All writes are under `/tmp/root-frontier-placement/`; the repository, build cache, and other candidates are unchanged. No Cargo command, compilation, test, binary execution, or timing was run.

`base/` holds the exact captured current contents of the three modified files, including the existing fused Tabs MRU work. `tree/` holds the complete corresponding candidate files. `candidate.patch` is the unified change from base to tree; `manifest.json` and `SHA256SUMS` identify the artifacts. `profile-analysis.md` records the attribution boundary.

The change retains one private row builder. Its existing `build` wrapper installs placements as before; `build_after_item_move` uses the same row builder without reinstalling them. `complete_item_move_structure` is used only at the end of `finish_item_move`, after existing source repair, outer flattening, retirement cleanup, root placement, and direct-child refresh. Existing `complete_root_structure`, births/import, raw/full canonical completion, and general command writers retain full placement installation. No public trust flag, new validator, cache, proof, or separate builder is added.

The O(n) root row walk and materialization, directory sort, Arc acquisition/release, joins, postorder, exact root issuance, staged behavior, generational/ABA rejection, and old-output ownership all remain. The measured 2,049-row edge path loses only the duplicate whole-root placement insertions. This slice does not include the separate Arc placement-sharing design.

Existing `assert_actual_placement` and its registered local Item matrix remain unchanged, as do staged, ABA, and old-output witnesses. No additional witness was needed for this interface-only split. The root agent is the sole verification owner and should run the existing Item matrix, owner/reference contracts, full required correctness checks, and fixed performance protocol before accepting a performance claim.

The captured HEAD is recorded for context only: base file hashes are authoritative because the repository includes current WIP. Repository copies still matched all three base snapshots when this package was finalized.
