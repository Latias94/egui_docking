# Item-frontier placement completion: source review

Verdict: PASS. No blocking correctness or ownership gap was found in patch `fc27efcd998edaed8f1b3decf78c1aa38856f80d9bed87c817628be6fdc52c99` against its captured current Item writer.

This review reads the README/profile analysis, the supplied edge analysis, the exact three-file patch, and the necessary Item writer, normalizer, authority and registered contract tests. No Cargo, compiler, product tests, binary, profiler, benchmark, timing, formatter, Git mutation, repository edit or candidate modification was run. Only this report was written. This is source review and artifact verification, not a performance result or a new test-pass claim.

## Exact scope and base

The patch reconstructs exactly from all three saved base/tree pairs: 3,224 bytes, +38/-4. Every manifest file hash and SHA256SUMS entry verifies. All three live repository files matched the saved base when read. Captured HEAD is context only; the exact hashes identify the WIP composition, including fused Tabs MRU.

| Path relative to `crates/dockspace/src/` | Base SHA-256 | Candidate SHA-256 |
| --- | --- | --- |
| `graph/root_structure.rs` | `de30fe16e4587efe9cc181f5d1ca46b66250fa082c5b4363efa5f1c9a1215a62` | `a4746315ca204bad7759db02eaf9d95488b6169ec873dab6207766d669b8e710` |
| `graph/authority.rs` | `c4542993266ad497b50cdd30e00bbf6fc656819925d8d52942290b54d7d121e2` | `28c8ad25d9ccfaa2bfa568a39f9e879407fd0fd36ad4174c15a2d9763a650fe0` |
| `canonical.rs` | `b4d5abe7b5916e41efc8004f294aacf0623716a29e94d50a1fc9185a59fa03d4` | `dda19b95f3a8c29aca4e262b9b4239e1409ca8aceaf85ef2c3432c881aea79be` |

The entire canonical module reverses to its base after restoring only the two completion calls and their comment. The entire authority module reverses after removing only the new private Item completion method. The complete row builder, final directory construction and successful-build hook are byte-identical to the previous builder after restoring the single placement insertion in place of on_node. No arithmetic, diagnostic pass, canonical rewrite, reference issuance or existing test is changed.

## The completion seam remains concrete and private

RootStructure::build still uses the same row walk and installs NodePlacement at each original Enter position. Its new private build_rows callback is the implementation seam, not a public policy/provider Interface. The separate build_after_item_move wrapper invokes that same walk with a no-op placement action. It neither assumes a version stamp nor accepts a caller-supplied trust bool, proof or cache. No new owner state or public entry point exists.

complete_item_move_structure only replaces an existing Editing body after the same row builder succeeds. Missing/retired owner and Ready-body handling match the previous complete_root_structure behavior. An Editing body stays unavailable through root_structure until success; a failing build does not publish a Ready replacement. The only new call sites are the two terminal calls in finish_item_move.

This seam relies on the checked Item writer's actual placement maintenance. That is a private owner obligation, not an inference that every Editing root has a valid frontier. The broader writers retain full installation, as required.

## Successful Item paths and actual placements

The only entry to finish_item_move remains the single MovePayload::Item + policy lane in prepare_transaction_inner (operation.rs:651–691), after executing on a cloned private candidate. Its placements are complete before the new terminal calls:

| Transition | Placement maintenance before row-only completion |
| --- | --- |
| Same-tabs center/no-op/reorder | No structural edit occurs. Existing placements and Ready body remain; checked changed/no-op issuance is unchanged. |
| Center/gap, source remains nonempty | Only Tabs payloads change. Tabs rows retain IDs, so source/target bodies and placements remain valid. |
| Same-axis inner edge | New payload leaf is assigned to target ownership. split_existing_branch refreshes the complete final direct child roster, including shifted sibling indices. |
| Opposite-axis inner wrapper | wrap_target_branch preserves the exact previous ParentLink, replaces that parent's one slot, places the new wrapper, and refreshes its payload/target children. No sibling roster index changes. |
| Wrapper becomes a root | The writer updates RootRecord.node, places the wrapper with no parent, and refreshes its children. complete_root_change also places the current root before finish. |
| Empty noncentral source | The final source path is captured from the actual post-insertion placement directory. Repair retires source/ancestors as needed, publishes the repaired RootRecord.node, places the surviving root with no parent, and refreshes all live rewritten direct rosters. |
| Protected empty central source | The central leaf is retained. No structural removal is manufactured, and actual placements remain. |
| Outer root flattening | finish_item_target_root runs in the existing root diagnostic order. It records/removes flattened wrappers, then the terminal root placement and output_splits refresh install the final direct joins. |
| Cross-root Item move | A moved Item becomes either target Tabs contents or a newly assigned leaf, not an implicitly transferred existing subtree. Source repair stays within source ownership; target insertion assigns its new nodes to target ownership. The distinct final root bodies are each completed once. |
| Entire unprotected source root retires | remove_root_and_presentation clears all subtree placements and removes the owner. The remaining source record is removed through Workspace::remove_runtime_node, which also forgets its placement. Terminal completion skips the absent owner. |

finish_item_move:315–327 handles every raw local-normalizer mutation before either row-only completion. For source removal, the retired source is inserted into results before removal. For ancestor collapse, the retiring parent is inserted into results. For flattening, each retiring child or previously resolved replacement identity already has its result entry. The final results scan therefore forgets the retired local identities. Rewriting allocates no new NodeId between those retirements and the scan.

Every surviving changed split is in output_splits, including an inserted edge split. Later ancestors may retire an earlier entry; refresh_child_placements ignores an absent/non-Split parent. Refreshing a still-live descendant before its ancestor is safe: its owning RootId is unchanged by an Item move, its children receive that root and their actual parent/index, and a later ancestor refresh installs the descendant's final link. Root links are placed first. Unchanged descendants keep their correct immediate links.

The lower/higher outer-target RootId branches change diagnostic order only; both converge on the same final retired-node cleanup, root placement and direct-child refresh. Root IDs cannot collide through result-map aliases because actual NodeIds are globally unique within the sealed forest. No cached pre-detach parent index is introduced.

## Retired generations, births, donors and general prefixes

The directory continues using complete generational NodeIds. Workspace::placement/node_root first require the identity to exist in the live arena; verify_reference still checks root existence, live generation, actual membership and exact RootReference. New Item leaf/wrapper IDs are assigned on creation. Retired source/collapsed/flattened IDs are explicitly forgotten. A recycled slot cannot inherit the old identity or old root authority.

The following paths are unchanged and still install complete placements:

- RootStructure::build, complete_root_structure and complete_root_structures use the installing wrapper.
- Builder/import issue_storage and all complete_root_birth calls retain complete installation. The same immutable payloads, not a copied graph, produce their rows.
- General/multi-command/staged Move uses TransactionDraft::push_command's full source/distinct-target completion (operation.rs:791–799), even when a particular command happens to carry one Item.
- RootContent::Move donor completion remains full (operation.rs:3024–3025), and the new root birth independently installs its complete new scope.
- Terminal canonicalization still withdraws bodies, restores only actually unchanged ones, forgets its retired effects, and uses complete_root_structures for bodies needing reconstruction.
- Open and Resize retain their concrete full completion calls. No raw or general writer selects the new Item wrapper merely because its body is Editing.

Strict issuance, net-zero/ABA handling and retain_original_issuance are untouched. The candidate does not rebuild command references from row values or make a stale output authoritative.

## Atomic failure and shared payload ownership

All frontier validation and its f32 input/output diagnostic witnesses execute at their previous positions before terminal completion. If a canonical rewrite, final validation or row build fails, prepare_transaction_inner returns Err and drops the cloned candidate. If source completion succeeds but distinct target completion fails, that partially completed source exists only in the discarded candidate. WorkspaceAuthority's current placement store is independently cloned; the separate proposed placement-sharing design is not present.

SharedSplit still clones the exact Arc returned by the current NodeStore. Local raw canonical replacements and edge writes finish before row construction, so rebuilt rows retain the final actual split payloads. Existing outputs can retain historical bodies and their Arc payloads; neither those rows nor the live original Workspace are edited. Tabs rows remain IDs only. The callback changes no payload selection, child range, postorder, identity ordering, splitter offset, body allocation or success counter.

## Existing behavior evidence and remaining gate

The retained local_item_moves_match_complete_normalization_and_exact_mru matrix covers both axes, emptied/nonempty sources, central variants, selection variants, same-pane/same-root/cross-root center/gap/all inner/all outer edges. Each successful result calls assert_actual_placement, which independently DFS-derives membership, complete parent/index links and paths, verifies each body row/directory/join, and checks SharedSplit Arc identity against the arena. This is stronger than equality of durable Workspace values alone.

Registered source also retains source-root retirement and discarded-candidate retry, same-shape/new-ID edge, mixed-program fallback, outer-flattening and both f32 diagnostic/rollback witnesses. Owner-reference tests retain donor birth-prefix checks, staged transient state and late rollback, exact ABA and recycled generations. These are relevant unmodified tests, not tests executed by this review. No additional framework or mirrored implementation test is requested before root's normal Item/owner/core qualification.

## Attribution boundary

The supplied diagnostic call-tree description separates actual transaction completion from fixture/initial projection. Its 127/53/31 inclusive sample counts are not exclusive timing shares; this review does not rerun or reinterpret them as a measured gain. The profile's frozen RootStructure source also predates the present fused-MRU WIP composition.

The patch removes the redundant per-row placement insertion only on the completed Item frontier. Full live-node row walking, joins, Vec construction, SharedSplit Arc acquisition/release, directory sorting, authority/store cloning and old-body disposal remain. Successful-build work counters still record the same body outputs. No claim of zero graph visits, constant-cost mutation, zero COW or recovered regression follows from this source review. Compilation, existing behavior gates and uninstrumented fixed-protocol measurements remain root's acceptance work.

## Additional context and artifact hashes

The following necessary unchanged context files were read from the current repository; the verdict depends on this actual writer/reader contract.

| Context relative to `crates/dockspace/src/` | SHA-256 |
| --- | --- |
| `operation.rs` | `b18c0f29b0561af1bbed80600d72d94825d5fb5ac1708abf1af7fe864d15c0b5` |
| `operation/tests/local_item_move.rs` | `68020548cbdbd968b09cbfdcb0dbb5a43217074cd0c504f528546d2a243815d2` |
| `operation/tests/owner_reference.rs` | `8a39eb6df3d844f952af7b550f75f51c51ab6d5c853b47f8748b69adb55158d4` |
| `graph.rs` | `dde95ddfa9e733448a4565404d9b6a612a3f614735bc39ba2cc4233066b80c2a` |
| `graph/shared_storage.rs` | `18c6f75150643779acb9c71c30486634b19f7ccec5677e4cc64ce9043fcc532e` |
| `workspace.rs` | `5cdb89c10b26f95695b9995e5c83e8cc3d2b34029b3213211d608b0c2cea0dd0` |

| Artifact | SHA-256 |
| --- | --- |
| `candidate.patch` | `fc27efcd998edaed8f1b3decf78c1aa38856f80d9bed87c817628be6fdc52c99` |
| `manifest.json` | `88cb3328ab04160cf44d98ee8de18f4b17c69ca8680dc963c3327c36ceb2e711` |
| `capture.json` | `fa8029382e931e98445a9c1b900f6cd43e9eae335595762a2d88843c4a9312e3` |
| `README.md` | `c2bb34a2f55b858bfb01980a00667f2c17584e9726830c9d915ca730e97d0465` |
| `profile-analysis.md` | `d18904a79eeb346047c668be4ad9d4e6303254ada6f4efa134698b36593367eb` |
| `SHA256SUMS` | `da94bb3b42394607e0a0d0bcf12433e9fcb44cebff052bf28894c2858fddd229` |
| `READY` | `26900e0d9e4e551ad951f8aa6f1ce59e3c943f68e260a4a124a2f2576037ee7b` |
| `root-structure-edge-analysis.md` | `a8b8b64507f51d51649af2d024199b8c6b70944dcf8ba229a561fdb235f17339` |

No source correction is requested. This report binds only the exact candidate and context above; later writer or placement-store changes require reassessing the corresponding owner obligation.
