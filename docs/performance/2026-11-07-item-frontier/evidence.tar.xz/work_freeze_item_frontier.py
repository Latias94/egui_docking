"""Run the ordinary complete docking work probe, then freeze the verified candidate."""
import datetime,json,os,subprocess
from pathlib import Path
root=Path('/Users/frankorz/codes/rust/egui_docking')
base=Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
out=base/'item-frontier-verified'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
env=dict(os.environ,CARGO_BUILD_JOBS='1',DOCKSPACE_DOCK_COST_OUT=str(out/'work.csv'))
env.pop('DOCKSPACE_BENCH_NO_WORK_COUNTERS',None)
command=['cargo','nextest','run','--package','dockspace','--lib','--all-features','--locked','--offline','-j1','-E','test(docking_work)','--run-ignored','only']
record={'command':command,'started_utc':now()}
with (out/'work.log').open('w') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
record.update(returncode=r.returncode,finished_utc=now())
(out/'work-check.json').write_text(json.dumps(record,indent=2)+'\n')
assert r.returncode==0
subprocess.run(['python3',str(base/'freeze_item_frontier.py')],cwd=root,check=True)
