# Root frontier placement: context rebase

Status: READY for root-owned verification. This is a context-only rebase of
`/tmp/root-frontier-placement/candidate.patch`, authored by
`root_frontier_placement`; `design_minimal` did not add a design or test.

The base is the exact current graph RootStructure + Tabs-owned MRU + Arc
placement directory, including the existing native-policy correction in the
placement semantic test. No root-record sharing, layout, timer, or exporter
change is included.

| File under `crates/dockspace/src/` | Base SHA-256 | Candidate SHA-256 |
| --- | --- | --- |
| `canonical.rs` | `b4d5abe7b5916e41efc8004f294aacf0623716a29e94d50a1fc9185a59fa03d4` | `dda19b95f3a8c29aca4e262b9b4239e1409ca8aceaf85ef2c3432c881aea79be` |
| `graph/authority.rs` | `2c618031ea69e0dd3b4e6ccd16f7f34bbc4c52b1f733abaa515bf356ad4422d4` | `89c65b0661ae3cc31b38b0157d4767e77c68219186ce78ca784ffb44d6af3fb9` |
| `graph/root_structure.rs` | `de30fe16e4587efe9cc181f5d1ca46b66250fa082c5b4363efa5f1c9a1215a62` | `a4746315ca204bad7759db02eaf9d95488b6169ec873dab6207766d669b8e710` |

`candidate.patch` is 3,239 bytes, three files, +38/-4:

```text
70cfba79fba97372f09fc4dcc8ae8ccc7d6e0ae396b922995aac125c4578b10d
```

All four original hunks and all original added/removed lines are retained.
The only context adaptation preserves the current `Arc::make_mut` argument
in the ordinary full installer. The new method is byte-identical to the
original candidate. The other two output files are byte-identical to the
original candidate outputs. Removing that method restores the complete
current authority base, including its Arc ownership, raw-key removal,
reference issuance, full-placement equality check, and semantic test module.

`base/` and `tree/` contain exact changed-file pairs. `contracts/` contains
the read-only operation, graph, transaction, and existing test context used
for the composition review. `base-manifest.json`, `rebase-hunks.json`,
`scope-checks.json`, `manifest.json`, `review.md`, and `READY.json` bind the
inputs, source checks, and final artifact hashes.

The checked Item path already repairs the actual placement frontier. Its
terminal completion now rebuilds structural rows without inserting every
placement again. Birth, Builder/import, raw/general normalization, and
staged command-prefix completion still use the full installer. The private
rows builder remains one implementation with a placement callback.

Rows construction still traverses the changed roots. A real placement
edit can still detach and copy the shared placement table. This candidate
does not promise O(frontier) total work, zero COW for edge moves, or a
measured performance gain.

Static verification passed: exact in-memory patch reconstruction,
unchanged addition/removal bodies, preserved authority/test bytes, and
`git apply --check --whitespace=error` against `base/`. No Cargo, compilation,
behavior test, benchmark, or timing was run. Root should check base hashes
before applying and run the existing local-item placement matrix, numeric
frontier witnesses, owner-reference/staged/ABA cases, and placement sharing
semantic test under its serial qualification process.
