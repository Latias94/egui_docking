# One ordinary inline hint on the checked numerical executor

READY / source stationary / not qualified. The exact parent is immutable
`eb94cb242722962c9e0d88074d81cf462d784357`, including retained packed child
results. This package changes one runtime file by exactly one added line:
ordinary `#[inline]` immediately before `solve_validated_axis_into`.

The complete immutable source pairs are under base/tree. No live worktree,
SmallVec, persistent NodeStore, fused continuation, axis specialization,
additional hint, dependency or buffer change is included. This package is
independent of `/tmp/axis-inline-retained-packed/`; do not apply both as one
unattributed treatment.

Only this new temporary directory was written. No repository, fork, cache,
Git state or previous candidate was changed. No Cargo, compiler, formatter,
test, runner, timing, nm, disassembler, profiler, network or child agent was
used. Root owns independent review, execution, comparison and retention.

Removing the one attribute recreates the complete parent layout.rs exactly.
The numerical executor body, checked `solve_axis_into` wrapper, public solver,
input validators, weight/constraint/sizes slices, aggregate order, arithmetic,
redistribution, arrays, packed output writes, central routing and dynamic
continuation stack are unchanged. All tests, independent reference, complete
fresh measurement, oracle capture, benchmark inputs, measure and export are
byte-identical. No new test or source-state flag is introduced.

The body is already visible inside this crate. A hint can encourage placing
it at its existing callers, but cannot guarantee inlining, binary-length
propagation, bounds elimination or loop unrolling. The wrapper and joined
binary/nary/override slices can retain dynamic lengths. A larger wrapper can
also become harder to inline into prepare. Code size, duplication, register
pressure and instruction placement can regress.

This is a code-generation experiment with no source-level arithmetic,
validation or allocation deletion. It does not claim an allocator share,
instruction reduction or speedup. The copied static analysis under inputs
explains the mechanism and its limits. A symbol list alone cannot establish
the behavior of actual hot call sites.

Root should use the retained ordinary solver/complete-output semantic oracles
and the unchanged complete operation protocol, including negative cells and
tails. This new binary has not inherited qualification from any prior axis
or inline variant.

`manifest.json`, `source-pairs.md`, `scope-checks.json` and READY bind nine
complete source pairs and the exact one-hunk patch. Set digests sort complete
UTF-8 relative path strings, not filesystem Path components.
