# Independent source review request

Parent: immutable `eb94cb242722962c9e0d88074d81cf462d784357`.
The sole treatment is one ordinary `#[inline]` before the existing
`solve_validated_axis_into` in layout.rs. Removing that line must reconstruct
the whole parent file, including all whitespace and tests.

Please verify one runtime path, +1/-0, no other attributes or mechanisms,
all numerical/checking bodies and the checked wrapper unchanged, all packed
output storage and writes intact, and eight byte-identical context files.
The independent reference, test bodies, complete timer/input/export code and
Cargo profile must remain unchanged.

No compilation, behavior qualification, code-generation observation or timing
has occurred. Ordinary inline does not guarantee inlining or constant
propagation. Root remains the sole verification owner.
