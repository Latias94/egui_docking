# Checked axis solver: a bounded inline experiment

Static analysis, November 7, 2026. The source parent is immutable
`eb94cb242722962c9e0d88074d81cf462d784357`. Only this report was written.
No candidate, repository/fork/cache change, Cargo, compiler, formatter, test,
runner, timing, nm, disassembler, profiler, network or child agent was used.
The separately measured axis-validation plus two-inline variant and every
existing candidate remain unchanged.

**Recommendation:** one ordinary `#[inline]` on the existing private
`solve_validated_axis_into` is a reasonable, very small falsifiable experiment.
It preserves the complete checked boundary and sole numerical algorithm.
It is not sufficient evidence that binary lengths will reach the solver,
that any loop will be unrolled, or that the complete operation will improve.
Do not combine it initially with more hints, cached graph parameters, a binary
solver, validation removal or other pending ownership changes.

## Exact source and boundary

All locations below are relative to `crates/dockspace/src/` at the immutable
parent; they do not refer to the live SmallVec worktree.

| Source | SHA-256 |
| --- | --- |
| `layout.rs` | `ee0bbdadf60b10a3787539e89cdee41411301c3c774e66d53c0146ad1567eaec` |
| `geometry.rs` | `3f4912b953fbb5a39b12f718370be8b133354f7a155609896156680d3d7b6541` |
| `layout/topology_tests.rs` | `67671850120413fbaec896b7eea930b7eb52086ccf4864b8486ab21ed8ea1ad2` |
| `layout/reference.rs` | `4b6ff84c9bed4b65a202e1c771b5f176b161bbb27b99dba25e4875c7b08c07c6` |
| `layout/override_tests.rs` | `f18d00fac60f87cd8fe136df5eb25bb36ffe444bda606ed16db4571568ae7fcb` |
| `docking_cost.rs` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` |

`Cargo.toml` is
`03937455cf6bd2c7124d6c17efc374244324d4d6a64f8c15af430ad7c97d17b7`;
its production profile uses thin LTO and one codegen unit. These settings do
not establish any particular inline decision.

I compared the complete `solve_axis_into`/numerical-executor source block and
the complete `validate_inputs`/numerical-helper block against immutable
07f566a. Both are byte-identical. Their respective block hashes are
`b71fa9e78309ba255d861b914a0ab22ed397604dffccda317b9f9745b246510f`
and `ebee326ce4656169bf7c24bade299495beb0957b74e3c25033d782892733e273`.
Packed child results have changed storage around the call, not this algorithm.

The two concrete entry paths are:

- Public `solve_axis` (`layout.rs:313`) validates inputs, allocates its complete
  sizes Vec, then calls the executor at line 322.
- Projection prepare (`:1003`) builds axis inputs, writes every child's minimum,
  maximum and initial gap state, constructs splitter geometry and output sizes,
  then calls `solve_axis_into` at line 1116. This wrapper (`:343`) performs the
  same full validation and calls the executor at line 352. After success,
  prepare copies every solved extent into the fresh ChildProjection records
  and writes the split outcome (`:1124`).

Both remain checked. No executor or wrapper currently has an inline attribute.
The independently maintained reference solver remains in `reference.rs:589`.

## What binary arrays expose, and where that information can be lost

Prepare constructs `[AxisConstraint; 2]` for a two-child split (`:1043`),
`[f64; 2]` weights when both graph child/weight slices have two elements and
no override is selected (`:1065`), and `[f64; 2]` sizes (`:1104`).
Other arities use the original reusable Vecs. Selected overrides borrow an
already validated f64 Vec slice; their precision and priority remain intact.

Those three choices join into slice references before one common call.
Consequently the compiler sees runtime slice lengths at that call unless it
propagates the branch relationships or specializes the relevant control-flow
path. The source does not instantiate a separate `[T; 2]` numerical function.
An opaque out-of-line executor cannot assume its slice lengths are two.

The executor body is already visible in this crate. The ordinary hint can
encourage placing it at its existing call sites. If the wrapper also becomes
part of prepare and the binary branch facts survive the joins, possible results
include constant loop trip counts,
fewer bounds checks, scalar replacement of local arrays, fewer repeated loads
and less call/return machinery. These are possibilities, not source guarantees.
Even successful executor-to-wrapper inlining may leave a general out-of-line
wrapper with arbitrary slices; that alone does not expose the local arrays.

Override cardinality is semantically validated earlier (`:687–750`), but that
does not by itself encode a compiler-known length of two at the later lookup.
Similarly, private typed graph/Constraints construction is not a compiler
range annotation for every loaded f64. Runtime weights, constraints, extent
and central routing remain dynamic, including in the formal binary fixture.

There is also an adverse possibility: putting the roughly 88-line executor
inside the otherwise tiny wrapper makes the wrapper less attractive to inline
into prepare. A new hint can move the boundary rather than remove it.
The public arbitrary-length path is another consumer, so code duplication,
layout, register pressure and instruction footprint can regress.

Root reported a separate `solve_validated_axis_into` nm symbol. I did not run
nm or inspect its binary here. A symbol proves an emitted body exists; it does
not prove every hot call uses that body, or that no inlined/cloned copy exists.
Likewise, absence of a matching symbol does not establish straight-line binary
arithmetic. Targeted caller instructions would be the relevant later evidence.

## Source work that an inline hint does not authorize deleting

The following is a source inventory, not executed pass counts or cost shares.
Early exits and dynamic redistribution alter which portions run.

| Stage | Actual work and contract |
| --- | --- |
| `validate_inputs`, `:1241` | Extent finite then nonnegative; length agreement; central bound; weights checked in input order for finite then nonnegative; checked full weight sum; no-central zero-total rejection. |
| Executor, `:371–378` | Checked minimum total, then checked maximum total. Both run before the minimum-infeasible return. Reordering maximum computation after that return changes error priority. |
| Infeasible branches, `:380–397` | Write all minima or all maxima and return the original overflow/unallocated result. No desired/clamp/redistribution pass follows. |
| Desired sizes, `:1285` | Without central: checked weight total and every desired-size write. With central: checked sibling-only total, ordered writes, checked desired-size sum, then central remainder. |
| Executor, `:399–425` | Clamp each output; checked assigned total; optional grow/shrink; checked assigned total again. The second total observes potential writes and is not duplicate work. |
| Redistribution, `:1371` | Dynamic capacity/weight eligibility, bounded updates and stable residual order. Arity two does not make the rounding/capacity state constant. |
| Prepare, `:1057`, `:1124` | Actually materialize all child minimum/maximum/gap/extent fields and the outcome. No lazy derivation, missing output or timer movement is permitted. |

The validator does **not** repeatedly validate every constraint's scalar
min/max. `AxisConstraint::new` validates them when constructed; prepare builds
its private axis values from fresh Constraints getters. Its repeated loops are
principally weight checks/sums and the actual numerical work above. Adding a
claim that the current validator rescans constraints for finiteness would
misidentify the source cost.

Finite component types do not make all arithmetic checks redundant. For
example, two public axis constraints each with finite maximum `f64::MAX` can
overflow the maximum sum. Valid finite ordered rectangle corners at `-MAX`
and `MAX` can yield infinite width through subtraction
(`geometry.rs:163`, `:215`). Public weights `[0.0, 0.0]` with no central child
must still reject, while a central route has different semantics. A full
weight-sum overflow precedes minimum/maximum errors. These examples are static
contract witnesses, not newly executed tests.

Compiler simplification may remove checks it can actually prove irrelevant
at one call site, while preserving all other observable paths. The proposed
source experiment itself keeps every statement, sum call, label and ordering.
Do not replace reductions with handwritten two-term formulas or reassociate
floating arithmetic to force a result.

## Comparison with source-level parameter reuse

There is one clear duplicate reduction: no-central feasible execution computes
`checked_sum(weights, "weight")` during validation (`:1277`) and again in
desired sizes (`:1316`), without modifying weights between them.
Retaining the first exact f64 as a call-local scalar could reuse its bits.
That would require changing the validation return/call chain and desired-size
inputs, and would change the numerical function's argument shape. It is a
different treatment from a one-attribute code-generation experiment.

If ever selected independently, such reuse must retain the first sum at its
existing validation position, carry its exact result, and consume it only
where the existing no-central second sum would have run. It must not replace
the sibling-only central sum, move minimum/maximum checks, or reuse an
assigned-size sum across grow/shrink. No persistent RootStructure weight/min/max
summary is justified: fresh constraints and transient overrides make that a
broader ownership and invalidation design.

I would not introduce a parameter object or trust flag for this observation.
Inlining may already permit common-subexpression reuse; conversely, a scalar
parameter can increase argument/register pressure. Inspect and measure the
minimal hint first rather than combine these mechanisms and lose attribution.

## Minimal falsifiable follow-up, owned by Root

The smallest treatment is one ordinary `#[inline]` immediately before
`layout.rs:355`, with zero function-body, call, arithmetic, validator, container,
output or test changes. Do not hint the wrapper or add inline(always) in the
first variant. This is distinct from the existing axis specialization plus
advance/constructor hints, and should not inherit its qualification.

After source review, Root can use the unchanged ordinary axis property oracle
(`topology_tests.rs:56`), bitwise output comparisons, mixed arity/central/raw
coverage, delayed measurement/override priority, late descendant-gap witness
(`:211`), deep tree and complete owned-output suite. No mirrored solver test
or new benchmark boundary is needed. The formal operation still includes
capture, checked mutation, complete fresh projection and owned export at
`docking_cost.rs:441–468`.

The cheapest mechanism check after Root builds is a bounded comparison of the
actual binary prepare/project callers and the wrapper/executor call sites:
did the hot binary route lose the relevant call, did slice bounds become
constant, and did generic and error paths survive? A whole-program symbol list
alone cannot answer those questions. No such inspection ran in this lane.

Use the complete retained-control protocol for adoption, including nary/central
correctness and all size/view cells, raw values and negative tails. If generated
code is effectively unchanged, the source change has no demonstrated mechanism.
If timing improves without proving specialization, describe an empirical
hint-treatment result, not proven constant propagation. If code grows or cells
regress, preserve that negative evidence. There is no allocator-saving claim,
measured solver share or predicted speedup in this report.
