# Complete immutable source pairs

Parent: `eb94cb242722962c9e0d88074d81cf462d784357`. All base files are exact immutable Git blobs; no live worktree source.
Nine complete base/tree source pairs.

| Relative path | Base SHA-256 | Candidate SHA-256 | Bytes (base / candidate) | Role |
| --- | --- | --- | ---: | --- |
| `Cargo.toml` | `03937455cf6bd2c7124d6c17efc374244324d4d6a64f8c15af430ad7c97d17b7` | `03937455cf6bd2c7124d6c17efc374244324d4d6a64f8c15af430ad7c97d17b7` | 1378 / 1378 | unchanged_context |
| `crates/dockspace/src/docking_cost.rs` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` | 30626 / 30626 | unchanged_context |
| `crates/dockspace/src/geometry.rs` | `3f4912b953fbb5a39b12f718370be8b133354f7a155609896156680d3d7b6541` | `3f4912b953fbb5a39b12f718370be8b133354f7a155609896156680d3d7b6541` | 15560 / 15560 | unchanged_context |
| `crates/dockspace/src/layout.rs` | `ee0bbdadf60b10a3787539e89cdee41411301c3c774e66d53c0146ad1567eaec` | `f858bae80d12ca56b4e28dde4060d9796ab9d5073efcc68255bb9d75a036d574` | 50778 / 50788 | production_runtime |
| `crates/dockspace/src/layout/override_tests.rs` | `f18d00fac60f87cd8fe136df5eb25bb36ffe444bda606ed16db4571568ae7fcb` | `f18d00fac60f87cd8fe136df5eb25bb36ffe444bda606ed16db4571568ae7fcb` | 10650 / 10650 | unchanged_context |
| `crates/dockspace/src/layout/projection.rs` | `fb6fb6454034656114bfdcb80049f53fbbc325a780af00f720efd7769fa1494e` | `fb6fb6454034656114bfdcb80049f53fbbc325a780af00f720efd7769fa1494e` | 11059 / 11059 | unchanged_context |
| `crates/dockspace/src/layout/reference.rs` | `4b6ff84c9bed4b65a202e1c771b5f176b161bbb27b99dba25e4875c7b08c07c6` | `4b6ff84c9bed4b65a202e1c771b5f176b161bbb27b99dba25e4875c7b08c07c6` | 28494 / 28494 | unchanged_context |
| `crates/dockspace/src/layout/topology.rs` | `1dd27eb635c84e0d73bf9186eb2e741f400b10e4b36bb6365477ac01c5bd21c6` | `1dd27eb635c84e0d73bf9186eb2e741f400b10e4b36bb6365477ac01c5bd21c6` | 8088 / 8088 | unchanged_context |
| `crates/dockspace/src/layout/topology_tests.rs` | `67671850120413fbaec896b7eea930b7eb52086ccf4864b8486ab21ed8ea1ad2` | `67671850120413fbaec896b7eea930b7eb52086ccf4864b8486ab21ed8ea1ad2` | 46411 / 46411 | unchanged_context |

Set hash format: sort full UTF-8 relative path strings by encoded bytes, then
`SHA256(concat(path + NUL + per-file SHA-256 + newline))`.

Base set: `57fff24239fa8b86e922f63e419fc426fd5fdbb289bb6a144cc5fe47c3a11d01`.
Candidate set: `3c91904c0de1774b651f369f8b3c0fb6e3478060637de3d39d3e12a074057a0b`.

All patch hunks reconstruct their complete target files from the immutable base.
No formatting, compilation, Rust test, runner, nm/profile or timing has occurred.
