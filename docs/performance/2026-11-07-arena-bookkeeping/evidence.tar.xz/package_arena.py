"""Freeze one measured bookkeeping control without changing its raw observations."""
from pathlib import Path
import csv, hashlib, io, json, shutil, tarfile
ROOT=Path('/Users/frankorz/codes/rust/egui_docking')
BASE=Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
OUT=ROOT/'docs/performance/2026-11-07-arena-bookkeeping'
OUT.mkdir(exist_ok=True)
inputs={str(p.relative_to(BASE)):p for p in sorted((BASE/'arena-control').rglob('*')) if p.is_file() and p.suffix in ('.rs','.patch','.json','.csv','.txt','.stdout','.stderr')}
for name in ('baseline.json','compare_frozen.py','profile-center.sample.txt','profile-attribution.json','profile-timed-mutation-attribution.json','arena-review.md','package_arena.py'):
 path=BASE/name
 assert path.is_file(),path
 inputs[name]=path
raw_rows=sum(sum(1 for _ in csv.DictReader(p.open())) for name,p in inputs.items() if Path(name).name=='raw.csv')
vectors=sum(1 for name in inputs if Path(name).suffix=='.txt' and any(part.endswith('-states') for part in Path(name).parts))
assert raw_rows==16128 and vectors==336,(raw_rows,vectors)
manifest={name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for name,p in sorted(inputs.items())}
with tarfile.open(OUT/'evidence.tar.xz','w:xz',preset=6,format=tarfile.PAX_FORMAT) as archive:
 for name,path in sorted(inputs.items()):
  entry=tarfile.TarInfo(name);entry.size=path.stat().st_size;entry.mode=0o644
  with path.open('rb') as f:archive.addfile(entry,f)
 data=(json.dumps(manifest,indent=2)+'\n').encode()
 entry=tarfile.TarInfo('manifest.json');entry.size=len(data);entry.mode=0o644
 archive.addfile(entry,io.BytesIO(data))
with tarfile.open(OUT/'evidence.tar.xz','r:xz') as archive:
 for entry in archive:
  assert entry.isfile() and not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts
  data=archive.extractfile(entry).read()
  if entry.name=='manifest.json': assert json.loads(data)==manifest
  else:assert data==inputs[entry.name].read_bytes()
shutil.copy2(BASE/'arena-review.md',OUT/'review.md')
shutil.copy2(BASE/'arena-control/checks.json',OUT/'checks.json')
(OUT/'archive-check.json').write_text(json.dumps({'regular_input_files':len(inputs),'raw_rows':raw_rows,'complete_vectors':vectors,'all_members_roundtrip_equal':True,'archive_bytes':(OUT/'evidence.tar.xz').stat().st_size},indent=2)+'\n')
(OUT/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print('Archived',len(inputs),'regular data files,',raw_rows,'raw rows and',vectors,'vectors')
