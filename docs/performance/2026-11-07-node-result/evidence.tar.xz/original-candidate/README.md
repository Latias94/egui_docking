# Single owning node-result map

**READY / STOPPED — temporary candidate, unapplied, uncompiled and untested.** No repository, Cargo, tests, benchmark, timing, Git write or other candidate artifact was modified. Rust best-practices skill was read before source edits. Direct rustfmt ran only on this directory's thirteen source copies; the complete patch passed `git apply --check --whitespace=error` against these exact temporary bases. Static source comparison is not execution qualification.

This replaces the uninstalled two-scalar-view proposal. Do not apply `/tmp/node-result-merge/node-result-merge.patch` first. Its artifacts remain untouched.

## Exact composed baseline

Baseline is commit `80403cb4bfe66f65a48da490a2aae660091f5f06` with **only** the sixteen frozen files in `/tmp/root-structure-shared-arc/tree` overlaid on it. All sixteen hashes were checked against that candidate's frozen manifest. Four of this patch's thirteen paths use the overlay (`layout.rs`, `layout/projection.rs`, `layout/topology_tests.rs`, `scene_compiler/surface.rs`); the other nine use the exact commit blobs. Nothing was copied from a drifting live workspace.

- RootStructure patch SHA-256: `8dc1059d026310e0ef26a9ff5bcb1bca92cd8d00cff62a0bcf833a0c1404ad0b`.
- Thirteen-path base set SHA-256: `5eb4713e2edc42a8fd123ee8c5200e28f5cfcb88670899cc91ad5e97ae057237`.
- `base-receipt.json` records the base commit, all sixteen overlay file hashes, and each edited path's precise origin, bytes and hash.
- `candidate-hashes.json` records all thirteen exact base/output hashes. The set hash is ascending path + NUL + per-file SHA-256 + newline.
- `base/` and `tree/` contain only the thirteen edited paths. `contracts/` freezes four relevant unchanged structural/numerical inputs for review.

Use hunks, not whole-file replacement, after live integration. Root's planned ordinary RootStructure counters are outside the runtime/caller changes here. Any later tail additions to `docking_cost.rs` must remain: this patch has no hunk in the formal/ordinary CSV or runner suffix. If a base hash changes, compare and explicitly compose that seam; do not replace the new live file with this older temporary copy.

## Interface and ownership

```rust
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct NodeResult {
    pub rect: LogicalRect,
    pub constraints: Constraints,
}

#[derive(Debug, Clone, PartialEq)]
pub struct LayoutProjection {
    pub nodes: NodeMap<NodeResult>,
    pub splits: SplitMap,
}
```

There is one existing generic NodeMap/NodeIter Implementation. Its exact generational lookup, identity-sorted iteration, double-ended/exact/fused iteration, first-visit preorder, Index, IntoIterator, Debug and logical identity/value equality remain implemented once. No NodeRects/NodeConstraints views, selector trait, provider, macro, compatibility alias, new topology representation or second traversal executor is added.

```rust
let result = projection.nodes.get(&tabs)?;
let rect = result.rect;
let minimum = result.constraints.min();
for (node, result) in &projection.nodes {
    paint_node(*node, result.rect);
}
let rects = projection.nodes.iter_preorder().map(|(id, result)| (id, &result.rect));
```

NodeMap's values Vec is now fully private. The only new constructor reserves capacity N without filling placeholder values. Its private row recorder appends on first Enter (`row == len`) and overwrites an already stored row on completed raw-DAG reuse. The unchanged real DFS records `NodeResult { rect: bounds, constraints: measurements[row].constraints }` at the original rectangle write location. A post-traversal debug assertion checks complete cardinality before returning the owner. There is no validity bitmap, unsafe initialization, public partial constructor, public mutation API, scratch pool or retained capacity between projections.

The immutable RootStructure rows are first-visit preorder. Production projection follows their exact child lists; diagnostic compilation also assigns first-entry rows, rejects active reentry and can reuse only completed immutable subtrees. Thus new rows arrive in order; completed revisits update the final rectangle for that exact identity without duplicating its row. Constraints are fully measured/completed before projection and copied into the same record. Failure drops the private partially filled Vec and cannot expose it to a reader.

The public record fields do not allow mutation through an immutable NodeMap. Each successful output owns its numeric Vec. Clone deep-copies that Vec and shares only the already immutable RootStructure handles. Original and subsequent outputs can outlive their Workspace, measurements and one another. Derived LayoutProjection equality uses NodeMap's existing sorted exact-ID/value comparison and unchanged SplitMap equality, so it does not compare private row order or Arc identity. Debug adopts the honest single-map shape as an intentional breaking Interface change.

## Complete thirteen-path migration

| Path | Added/removed (net) | Change |
| --- | --- | --- |
| `crates/dockspace/src/docking_cost.rs` | +8/−12 (-4) | Standard map over existing preorder for the same full exporter; keyed test and outside-timer counts migrate. |
| `crates/dockspace/src/drop_resolver/preview.rs` | +16/−20 (-4) | Use the single map in center/payload readers; policy and missing-node behavior remain. |
| `crates/dockspace/src/engine/splitter_geometry.rs` | +9/−6 (+3) | Read whole preorder records after the existing exact-ID check; reuse that record for constraints. |
| `crates/dockspace/src/engine/splitter_geometry/tests.rs` | +42/−42 (+0) | Mechanical rect field reads; all geometry, numerical and rejection assertions remain. |
| `crates/dockspace/src/engine/surface_contribution/reuse_tests.rs` | +5/−2 (+3) | Mechanical actual-constraint field reads for retained-facts minima regressions. |
| `crates/dockspace/src/layout.rs` | +16/−14 (+2) | Capacity-only node owner; record actual rect and completed constraints at the unchanged first Enter; migrate four test reads. |
| `crates/dockspace/src/layout/layout_cost.rs` | +2/−3 (-1) | Direct result reads; consolidate the now-identical node cardinality assertion. |
| `crates/dockspace/src/layout/projection.rs` | +22/−7 (+15) | One public NodeResult and one existing NodeMap implementation; private capacity/record; no scalar views. |
| `crates/dockspace/src/layout/reference.rs` | +4/−4 (+0) | Only production capture Adapter reads change; independent expected maps and implementation stay frozen. |
| `crates/dockspace/src/layout/topology_tests.rs` | +128/−36 (+92) | Direct map reads; extend owned clone witness; retain all RootStructure tests; add late-error witness. |
| `crates/dockspace/src/scene_compiler/future_layout.rs` | +8/−6 (+2) | Select rect after the same exact node lookups and keep existing errors. |
| `crates/dockspace/src/scene_compiler/surface.rs` | +19/−15 (+4) | Borrow NodeMap<NodeResult>; select rect locally for sorted scene compilation and exact child geometry. |
| `crates/dockspace/tests/layout_solver.rs` | +18/−18 (+0) | Mechanical rect/key reads for public solver behavior and deep layout cases. |

Total: **+297/−185, net +112**. The two runtime files are **+38/−21, net +17**. The previous two-view proposal was +499/−212, net +287; its two runtime files were net +181. The projection module is now 363 lines versus that proposal's 536. These are source-complexity comparisons across the explicitly different baselines, not a performance result. The large reductions come from not introducing duplicated public view/iterator protocols.

The map cardinality formerly asserted separately for two stored fields is now checked once, because both mandatory fields inhabit every record. No numeric, full-export, policy, error or geometry assertion is weakened. In the splitter frontier, the yielded full NodeId is still compared to the expected live identity **before** reading that row's rect/constraints; both values now come from that same result, avoiding a second lookup. The exporter keeps its existing complete owned Vec and complete NodeId/preorder checks, using only the standard iterator map shown above. It does not create another result Vec or change a timer boundary.

`caller-scan.json` records a read-only scan over the exact commit + sixteen-file overlay + this candidate under crates/integration. Remaining old names belong only to the independent oracle maps and assertions against those expected values. There is no remaining production old-field read or old scalar view family in that composed source.

## Numeric, oracle and benchmark boundaries

`contract-hashes.json` records ten unchanged source regions, including the existing public axis/solver core; overrides, measurement and constraint composition; DFS except its node-record statement; splitter/advance geometry; complete SplitMap implementation; complete existing NodeMap query/iterator implementation; fixture/request/layout/full export writer; and the complete measure timing function and formal/ordinary CSV/runner suffix.

The oracle's capture Adapter alone changes to select rect and constraints from `projection.nodes` into its **independent two BTreeMaps**. Its expected types, solver, traversal and implementation are not migrated:

- Full base oracle SHA-256: `93afdf6e8ad79d81f2efdafc4814a4bb6076fd9f535129f82ce33f9ee12ddf4e`.
- Full candidate oracle SHA-256: `2b2eee151d88bdd83048f0dfe7a4931a769aff6616da59e060200819008b209a`.
- Complete independent implementation from the documented RootMeasurement marker remains byte-identical, SHA-256 `a94d7bafd8d07c4bcfeb934a36c86676baed83e54e4eaf944a7b01bc932b22b3`.

Formal CSV, phase timing, fixture shape, operation capture, full owned export words/ordering, digest and outside-timer oracle remain unchanged. There is no solver arithmetic, allocation-order solver fusion, child slab, frame compaction, weight fusion, RootStructure build, graph ownership or command protocol change in this patch.

## Registered ownership and error witnesses

The existing `dense_projection_keeps_identity_order_and_owned_old_outputs` retains its full frozen comparison, sorted/reverse/preorder behavior and second-output check. It additionally clones the old output and holds a direct borrow of its single map. After dropping Workspace/index/original output, it compares the clone's complete capture, both complete logical field maps, complete preorder records and lengths.

The prior meaningful late-error witness is retained as a single registered new test: `owned_node_rows_keep_previous_outputs_after_late_geometry_error`. Two fixed-width leaves each require 0.375*f64::MAX. The first origin-zero projection succeeds and agrees with the independent oracle. A later valid bounds origin 0.5*MAX, width 0.5*MAX records the root and first child, then overflows the second child's x endpoint. Both paths must return the exact existing Geometry NonFinite/INFINITY error. The earlier map borrow and full clone remain readable after dropping the inputs/original. The test is adapted to the single map rather than two view types; its fixture, expected failure and rollback/lifetime substance are retained.

All functions already in the overlay's topology_tests.rs remain. The four new RootStructure tests are byte-identical here:

- `owned_structure_reuses_rows_with_current_metrics_and_answers`
- `semantic_index_rebuild_keeps_the_actual_unchanged_owner_structure`
- `same_version_owner_layout_never_reads_an_independent_changed_body`
- `same_version_edits_own_new_rows_and_keep_the_original_output_body`

The raw completed-subtree/cycle/leaf-order oracle, sparse retired-generation and mixed/preorder iterator cases, 10k-depth projection, public solver comparisons, both f32 frontier regressions and actual exporter regression stay registered. Source retention is not a passing test result.

## Resource and locality tradeoff

This removes one nonempty node-result backing buffer per root and the corresponding second buffer on output clone, the N-element placeholder rect fill, and the separate N-element constraint-result collect. It also removes one redundant topology Arc handle from the output. Measurements, actual complete rect/constraint payloads, split outputs and all required owned exports remain.

Each record contains four f64 values' worth of rect coordinates plus four f64 values' worth of constraints. Expected stride is 64 bytes versus the former two 32-byte streams; actual size/alignment and padding have not been observed with a compiler. Account for N times any extra padding before claiming memory savings. Final payload remains approximately 64N if no padding is added; the eliminated placeholder writes are approximately 32N, not the actual required rect data. There are no per-row IDs, Options, Arc headers or extra immutable owner allocations.

A raw repeat overwrites the full record, so it additionally recopies that immutable constraint value. Rect-only and constraint-only scans now stride through an interleaved 64-byte record and may fetch unused fields; joint consumers may gain locality. A larger single allocation has different fragmentation/rounding/peak behavior from two smaller allocations. Infallible allocation failure is not a recoverable LayoutError being promised equivalent. Source buffer counts are not malloc, RSS or peak measurements. No speedup, peak reduction or goal qualification is claimed.

## Root-owned next gate

Apply either `node-result-single-map.patch` or its disjoint `runtime.patch` + `callers.patch` pair to the exact composed base after independent review. Then typecheck all test/features callers before treating retained registration as evidence. Example root-owned serial commands, **not executed here**:

```text
cargo check --package dockspace --tests --all-features
cargo nextest run --package dockspace --all-features --lib --test-threads=1 -E 'test(dense_projection_keeps_identity_order_and_owned_old_outputs) | test(owned_node_rows_keep_previous_outputs_after_late_geometry_error) | test(completed_subtree_reuse_keeps_active_cycle_and_leaf_error_order) | test(sparse_) | test(projects_ten_thousand_nested_splits_without_call_stack_growth)'
```

Then run the existing complete numeric/dense oracle, retained RootStructure and splitter/export regressions, ordinary workspace/host/resize gates, and root's unchanged complete-operation comparison and allocation accounting. Reconcile later slab/frame hunks by preserving their split buffers/state and changing only the actual Enter record; do not copy old whole files over them. The candidate and all temporary source are now stationary for independent review and root execution.
