# Shared SplitArc RootStructure candidate

Status: **READY for root-owned integration and serial qualification; no compilation, test, benchmark, or timing result is claimed.** The candidate is confined to this temporary directory. Repository source was read but never edited. The candidate source and patch are stationary after this receipt.

## Frozen artifacts and composition

- Candidate: `root-structure-shared-arc.patch`.
- Patch SHA-256: `8dc1059d026310e0ef26a9ff5bcb1bca92cd8d00cff62a0bcf833a0c1404ad0b`.
- Patch size: 79,151 bytes; 16 paths, including the new graph module.
- Changed-path candidate set SHA-256: `4b6096fc6b411e16479afacec2144f3348613b9c80bfdfc63d896f3b04b1b827`.
- `candidate-hashes.json` records every exact base and candidate file hash and the set-hash format. `base-hashes.json` records the complete captured/composed baseline, including unchanged source.
- `source/` is the captured copy + leaf + export source; `base/` adds the exact cold + initial-issuance preconditions; `tree/` contains this candidate.
- `source-to-precondition-base.patch` makes the precondition composition explicit. Its SHA-256 is `beab874875a75b8feeca7c4948252e38790c98d5b4296d81d0cf0716a2c5d9cf`.

The two precondition patches were applied only to the temporary baseline, with their input/output hashes checked:

| Precondition | Patch SHA-256 |
| --- | --- |
| `cold-effects-combined/cold-after-report-copy.patch` | `94668387c35a896e4ac1926c868b719296bc1a605457f19c92bb3b6d1114ab60` |
| `initial-issuance/initial-issuance.patch` | `0c18795d42f09e9fce35fec22732f9a37c2ec1939dd9c96fec08ad65c54d7176` |

These live under `/tmp/dockspace-imgui-twofold-20261107-ea4161e/`. This candidate excludes solver-aggregate, child-extents-slab, projection-frame, weight-fusion and NodeResult candidates. Do not copy a complete temporary file over later integrated work: recheck exact base hashes and compose overlapping hunks explicitly.

At the final read-only comparison, all 16 candidate paths in the live repository matched this composed baseline exactly, including absence of the new module. See `live-base-drift.json`. This observation is not a lock on future repository changes.

## Module and Interface

The graph Module now owns the actual immutable root body. Layout borrows it rather than compiling a second semantic split representation. Its narrow Interface is `Workspace::root_structure(root) -> Option<&Arc<RootStructure>>`; the existing public `Workspace::node(id) -> Option<&Node>` reader remains unchanged.

`RootOwner` keeps exact command issuance, presentation ownership and `RootStructureState::{Ready(Arc<RootStructure>), Editing}`. Editing is private ownership state: a concrete writer withdraws the current body before changing split payloads. There is no old body reachable through that candidate's layout Seam while it is Editing. This is not a generation marker authorizing an independently mutable cached value.

`RootStructure` stores five root-local vectors: node rows, child-row joins, postorder rows, identity-sorted rows, and split rows, plus splitter cardinality. A split row owns `SharedSplit(Arc<Node>)` taken directly from `NodeStore::shared`. Axis, weights and child identities are borrowed from the same immutable allocation held by the arena handle. A tabs row stores only its complete generational ID. Selection, item order and MRU remain current graph values; no historical Tabs payload is retained by layout.

The child-row joins and sorted directory are derived indexes over that single split payload. They are not another independently writable child-identity roster. Locality stays root-scoped; sparse arena capacity does not determine per-root storage size. The Implementation constructs joins and actual node placements together, iteratively, and then sorts complete NodeIds for existing ordered queries.

## Actual writer completion

| Actual writer / path | Ownership and completion |
| --- | --- |
| Builder / import | Full existing canonicalization and validation precede issuance. Each actual carrier builds its new body and placements once in `complete_root_birth`. |
| Select / Reorder | Tabs/MRU changes renew issuance as before. Split payloads and leaf IDs are unchanged, so the body is shared. |
| Center Open / center Item Move with nonempty source | Only Tabs/MRU values change. Existing structures remain Ready and are shared. |
| Split child removal | `remove_split_child` enters Editing before mutating the actual parent split. Existing unroot/direct-placement updates remain available to subsequent command capture. |
| Edge insertion / same-axis insertion / wrapper | `insert_payload_at_edge` enters Editing before split/root changes. |
| Single Item Move | Source empty-leaf repair and outer flatten enter Editing before raw rewrites. Body completion runs only after all local repair, final weight diagnostics, retired placement cleanup and direct roster refresh. It completes source and distinct target only. |
| General Move prefix | After actual execution and item-ledger update, `push_command` completes only its known source and distinct target. A subsequent capture observes the concrete prefix; no all-roots prefix scan is introduced. |
| RootContent donor | Detach completes the donor's actual body before fresh-root construction and the next command capture. New root birth builds its own structure after the actual carrier is installed. |
| Real Resize | After the complete existing resize validation, only changed entries enter Editing and call `get_mut`. Each actually changed root completes once after the batch's writes. |
| Same-value Resize | Skipped before `NodeStore::get_mut`, preserving both structure Arc and underlying split Arc without premature COW. |
| Rehome / promotion / contained rect / raise | Presentation or metadata changes retain the same structural body. No peer-owner scan or structural rebuild is added. |
| Approved close / owned follow-up | Existing policy/source/multiset checks and terminal full canonicalization remain. Removed roots lose their owner. A successful return has current completed bodies. Failure discards the candidate. |
| Full standalone / general final canonicalization | Takes Ready bodies out of the private candidate before raw rewriting. Restores only bodies absent from actual canonical `changed_roots`; already Editing roots were never captured. Completes the remaining Editing bodies after successful existing checks. |
| Normalized equal general result | `retain_original_issuance` restores references only. It cannot replace the current normalized body with an old owner/body. |

Root birth, `begin_root_edit`, raw rewriting, prefix capture and final seal all stay inside the existing closed graph owner. No new production API exposes an unchecked sealed Workspace or an unfinished candidate for layout compilation. `TransactionCapture` remains its existing narrow facet.

Checked prefixes may contain transient singleton/empty split containers until final normalization. Structure construction deliberately does not add a stricter canonical validator at each prefix. It retains the existing final normalization and diagnostic boundaries instead of changing their error order.

## Root-count and rebuild costs

`complete_root_structure(root)` uses a single owner lookup. A Ready owner does not traverse its tree. An Editing owner rebuilds its reachable rows and placements in O(n), then the existing sorted identity directory in O(n log n); it does not scan peer roots. Single Item finish performs at most two such lookups. Move prefixes, Open, Resize and donor completion use their explicit edited roots. Select and rehome do not perform structural completion scans.

The only production caller of plural `complete_root_structures()` is the terminal full normalizer. `take_root_structures` and that final completion each visit the owners once per full normalization, not once per command. Actual `changed_roots` are produced in ascending BTree root order; restoring previous bodies uses binary search, avoiding an added O(R*C) membership scan. The combined directory/restore work is bounded by O(R log R) plus rebuilding only Editing roots. This does not reintroduce an all-roots scan for every command in sequential cold rehome/recovery.

There is still a genuine source cost: a general structural Move prefix can construct a noncanonical body and final normalization can construct a second body when it actually rewrites that root. Incremental placement maintenance also remains necessary before prefix capture. This candidate does not claim frontier-only structural updates, zero root walks, or any measured improvement.

Persistent graph bodies remove runtime topology construction, sorting and copied-weight storage from fresh layout projection, including the first projection of a sealed Workspace. The body was actually constructed by Builder or a concrete mutation owner, not lazily warmed by an earlier projection. Mutation completion stays within actual mutation work, and Builder work must be reported separately. Benchmark fixtures, timers, the N fresh leaf queries, full projection and owned export are unchanged.

## Layout, numeric contracts, and independent Adapter

`project_root` and minimum measurement borrow the current graph body and produce fresh constraints, measurement rows and complete owned result arrays. Geometry metrics and central metadata are read for the current call. Leaf queries and split composition follow the existing DFS/postorder sequence. Durable f32 weights convert to f64 in the same child order at the existing solve boundary. No scalar, aggregate, extent, maximum or constraint validation is removed.

Public override validation still precedes fresh leaf measurement. The minimum-measurement API still measures before its later override validation. Every source/index reference remains independently verified through the existing owner-reference Interface; structure sharing provides no command authority.

The malformed-draft Adapter remains `cfg(test)` and retains the checked compiler's active/completed HashMap states, DAG completed-subtree reuse, cycle/cardinality/missing-node ordering and central check. It builds the new structural rows only after the corresponding old checks. It does not construct a production unchecked Workspace.

The frozen independent `layout/reference.rs` is byte-for-byte unchanged, SHA-256 `93afdf6e8ad79d81f2efdafc4814a4bb6076fd9f535129f82ce33f9ee12ddf4e`. Its traversal, solve, owned map output and arithmetic are not replaced with a shared helper. `solve_axis` and its caller-owned numeric core, the numeric validation/solver suffix, override validator and splitter math also compare unchanged. See `scope-checks.json`; these are static byte comparisons, not executed behavioral results.

`LayoutError::UnfinishedRoot` rejects a withdrawn private body before leaf callbacks. Its runtime error classification is Internal. Existing public `NodeMap`, `SplitMap`, sorted-key queries, preorder iteration and all slices keep their functionality. They now retain an Arc to the graph-owned structure. A later COW split edit or destruction of every Workspace cannot mutate or invalidate the old projection. No result retains a leaf reader or a Workspace borrow. The flat structure contains no recursive owned child pointers, preserving iterative deep-tree construction and drop.

## Deleted runtime paths

- `RootLayoutTopology` and `LayoutNodeKind` as layout-owned structural types.
- Runtime `RootLayoutTopology::compile`, its copied axis/weight-bits/child-identity representation, and `matches`.
- `WorkspaceRootIndex::layout_topology: OnceLock<...>` and `layout_topology_slot`.
- `WorkspaceIndex::build_reusing_layout` and its cross-revision match/transfer pass.
- `measure_root_minimums_with_index` and the index/version inputs previously used solely to access that cache.
- Engine/scene cache-transfer and cache-slot call sites and their obsolete cache assertions.
- Redundant canonical completion subtree assignment where the new body build now constructs placements itself.

Semantic `FingerprintNode::Split::weight_bits` and the existing semantic root index intentionally remain: they serve presentation/semantic contracts, not the removed layout representation. No compatibility alias preserves the deleted APIs. Module Depth comes from one graph-owned body and a smaller layout Seam, not from an additional generic cache/provider layer.

## Exact changed paths

All paths below are relative to the repository and exist only as edits under `tree/` until root applies the patch:

```text
crates/dockspace/src/canonical.rs
crates/dockspace/src/engine/presentation_authority.rs
crates/dockspace/src/graph/authority.rs
crates/dockspace/src/graph/root_structure.rs (new)
crates/dockspace/src/graph/shared_storage.rs
crates/dockspace/src/graph.rs
crates/dockspace/src/layout/projection.rs
crates/dockspace/src/layout/topology.rs
crates/dockspace/src/layout/topology_tests.rs
crates/dockspace/src/layout.rs
crates/dockspace/src/operation/tests/owner_reference.rs
crates/dockspace/src/operation/tests/split_resize.rs
crates/dockspace/src/operation.rs
crates/dockspace/src/runtime/error_kind.rs
crates/dockspace/src/scene_compiler/surface.rs
crates/dockspace/src/workspace.rs
```

## Contract coverage retained or added

- Extends the existing actual-placement oracle with exact row IDs, kinds, child joins, splitter cardinality, postorder cardinality and `Arc::ptr_eq` against each current arena split. Existing registered local Item repair, prefix, fresh-root, rehome/ABA and generation tests already call this oracle.
- Adds one nonempty center Item Move test proving both owner bodies remain shared.
- Adds one unfinished-body test proving rejection precedes leaf queries, then completing the body and retaining equal owned output after all Workspaces are dropped.
- Extends existing Select/edge/Resize tests to distinguish body retention/replacement; same-value Resize also proves no split payload COW.
- Migrates the existing split-resize stale-reference test's direct internal write through edit/complete, preserving its original stale-source assertion.
- Replaces obsolete cache assertions with actual owner/body sharing and exact stale-issuer rejection. Same-version axis/weights/central/child-order cases still compare every output field against the independent oracle.
- Preserves the existing registered sparse/recycled-generation, current metrics/minima, missing-leaf query order, override precedence, raw DAG/cycle/diagnostic and owned-output tests. The actual registered 10,000-depth projection/drop test is byte-for-byte unchanged. No claim relies on unregistered legacy integration files.

## Verification receipt and remaining gate

Performed: source audit, explicit temporary-file rustfmt with child traversal disabled, exact file/block comparisons, complete base-hash comparison, and a zero-fuzz dry-run application to the saved composed baseline. `patch-dry-run.txt` records the final patch dry-run. No Cargo, compiler, behavior test, benchmark, timing, Git write, new dependency, unsafe code or sub-agent was invoked by the author for this candidate.

`review.md` is the other agent's independent provisional source review. It was written against the draft and must be rebound to this final patch hash before treating it as a final review. Its earlier concern about `changed_roots.contains` is resolved by the final sorted lookup; per-command peer scans are also absent from this final patch. The final receipt makes no claim that this provisional review constitutes test qualification.

Root still owns integration, compilation, complete registered behavior/error/numeric/rollback/native qualification, and controlled paired measurements. In particular, the new graph-owned structure build is not measured by the existing root-fingerprint/full-canonicalization counter fields: zero values in those fields do not prove that an edge mutation made zero root traversals. Any later attribution must name the actual work counted.

Integration overlap is explicit: slab changes overlap `layout.rs` and `layout/projection.rs`; frame changes overlap projection setup/continuation in `layout.rs`; fusion overlaps numeric split preparation/validation; NodeResult overlaps layout result construction/projection and callers. This patch includes none of them. The independent reference and benchmark source must remain unchanged when merging those later candidates.
