# Compact frame on the retained e3 control

READY / source stationary / tmp only. No compilation, behavior test,
runner, profile, benchmark or timing was run. No repository, fork, cache,
old candidate, Git write, network or sub-agent was used. Root alone owns
verification and performance decisions; this is not qualified.

## Exact composition

base/ contains the five actual layout files from immutable commit
e3c517195ddce2c7d1a6dbfd4328f152978968ec, read through Git object access
without changing the index or working tree. All five equal the original
initial/ inputs. Slab and childrows are absent. The current live workspace
already matched this frame tree at capture, reflecting root's own
application; this lane did not write it.

The original nine /tmp/projection-frame-3vec/candidate.patch hunks
(SHA-256 066e6e092a3aa70421e5897a4a896237b5b97b20580c4584c0f499b189563a8e)
match exactly once without any hunk-body or context adaptation. Only
line offsets change relative to that childrows parent. This own patch
contains the compact frame, private direct NodeMap row read, and original
55-line two-case registered error-order test. It does not contain
childrows, binary arrays or unified values.

The pending flag still rereads the exact parent child extent only after
the full descendant DFS returns. Immutable disjoint child ranges and the
raw active-cycle check prevent a child from changing its active ancestor's
segment/recorded bounds. Cursor and original thickness remain unchanged,
with descendant error before parent gap before next child. The complete
fresh output and old-output/clone ownership remain. No arithmetic or
solver variant is introduced. The entire prefix before compact-frame
state and numeric suffix retain e3's original composition/validation.
The original independent reference and raw compiler are unchanged.

Negative cost: smaller ephemeral state adds direct topology/result/extent
reads and bounds checks; compiler/layout effects can outweigh fewer
copied fields. Exact bytes, allocation share and latency are unmeasured.
The existing full oracle, n-ary/central/override/raw DAG, late geometry,
old clone, ordering witness and 10k-depth cases are relevant root gates.

## Artifact boundary

candidate.patch applies to matching base/ hunks only. Complete base/tree
pairs and unchanged context files are review inputs, not instructions to
overwrite later whole repository files. The next independent slice must
use this exact tree or explicitly rebase it if root rejects a prerequisite.
Both rejected experiments remain absent; fewer owners was not a measured
win. Composition helpers preserve original &[SubtreeMeasurement]
signatures, and reference.rs still uses its original calls/bool records.

Patch SHA-256: `88e2d423e16144b05e7d2e07749bc7c60ecd96ae2ec2aaa8f33aa3fe33e306f5`.

Five-file base set: `69fd8e9f4aadf135332c58f9862b9309792aa53ed8c8c603ef228df23bfbd867`.
Tree set: `07f1c6efc319077d05910c42c717f6e387e1e2f36a26a52134615c7233f107f7`.

base-manifest.json, rebase-hunks.json, scope-checks.json, manifest.json
and READY.json bind exact identities. Set format is sorted UTF-8 relative
path + NUL + file SHA-256 + newline. Original hunk bodies uniquely match;
the patch passes read-only git apply --check --whitespace=error in its
own temporary base. No Rust behavior was executed. Rust best-practices
was read; no new Rust text beyond the original exact hunks was authored.
