# Remaining projection work and the actual ImGui boundary

Read-only architecture analysis, November 7, 2026. Rust is immutable
`eb94cb242722962c9e0d88074d81cf462d784357` with retained packed child results.
The included upstream kernel is immutable Dear ImGui
`d88f238d1d363ef387382b2e29ad12cf96f826ac`.
Only this report was written. No candidate, repository/fork/cache change,
Cargo, compiler, test, runner, timing, nm, profiler, network or child agent was
used. Source counts below are not measurements or predicted gains.

**Conclusion:** the current complete operation includes materially different
projection contracts. Rust freshly computes arbitrary leaf constraints,
composed constraints for every node, bounded allocation outcomes and stored
gaps, returning an independent rich owned projection. This ImGui kernel
updates existing binary nodes in place from style/SizeRef state and returns
no corresponding rich projection. Both still export the complete common
state into a fresh owned vector. That difference explains actual extra work;
it does not establish a numeric lower bound, an unavoidable ratio, or that
further optimization should stop.

One different, bounded source direction remains: reuse the first checked
assigned-size total when it equals extent and therefore no redistribution
runs. This stays inside the sole numerical executor and needs no new public
Interface, stored summary or alternate binary math. It is an unmeasured
experiment, described below, rather than an adoption recommendation.

## Exact evidence

Paths in the Rust column are relative to the repository. ImGui sources are
read through its separate local Git object database at the stated pin, not
the current checkout.

| Source | SHA-256 |
| --- | --- |
| Rust `crates/dockspace/src/layout.rs` | `ee0bbdadf60b10a3787539e89cdee41411301c3c774e66d53c0146ad1567eaec` |
| Rust `layout/topology.rs` | `1dd27eb635c84e0d73bf9186eb2e741f400b10e4b36bb6365477ac01c5bd21c6` |
| Rust `layout/projection.rs` | `fb6fb6454034656114bfdcb80049f53fbbc325a780af00f720efd7769fa1494e` |
| Rust `geometry.rs` | `3f4912b953fbb5a39b12f718370be8b133354f7a155609896156680d3d7b6541` |
| Rust `docking_cost.rs` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` |
| Wrapper `integration/product-comparison/imgui_docking_cost.cpp` | `4c74fbb088618dff1c71d4eaaa4094889c4516d4ecef3fd2342eeeb9c855f36c` |
| Pinned `imgui.cpp` | `4a3f6d979763314ff188f2430bce3296afaae876a15d30ea1cef43094219c8ac` |
| Pinned `imgui_internal.h` | `964cba6849d9993c60a9c989fc10cc6ba9690e6802b31df49d07e1ddc612a170` |

Short `layout/...`, `geometry.rs` and `docking_cost.rs` names above are under
`crates/dockspace/src/`. The actual immutable Rust request captures current
source/target directly (`docking_cost.rs:136–173`); older methodology prose
about an all-root WorkspaceIndex is not the current implementation.

## Common work versus additional contracts

Both fixtures freshly create every logical root outside timing. Each root
starts as an alternating balanced binary tree with two tabs per leaf.
Both timed operations apply the real command, lay out every root and export
every node/tab/selection intent; resize changes every root's bounds.
No renderer, host scene, physical viewport or full click is included.

The complete common export is explicit: nine words per node
`[view,path,kind,x,y,width,height,item_count,selected]`, then every ordered
item ID. Both allocate a fresh vector with the same reserve expression inside
export timing (Rust `docking_cost.rs:329`, wrapper `:346`). Both validate exact
integral geometry. Native selection uses pending NextSelectedTabId when
present; Rust uses its current selected ItemId. Full-vector checks occur
outside timing, and vectors survive destruction of their source fixtures.

“Common fresh inputs” must not imply identical leaf-measurement work:
Rust's timed all-root adapter freshly gathers each leaf's Constraints answer
into per-root vectors and consumes it through the actual reader
(`docking_cost.rs:197–256`). ImGui has no matching callback or per-leaf
min/max-answer vector here. It reads existing node SizeRef/visibility and the
current global style. That is an actual asymmetric input contract included
in the declared comparison, not permission to replace Rust's reader with
a fixture constant or move the gather before the timer.

| Contract | Rust eb94cb2 | Pinned ImGui kernel |
| --- | --- | --- |
| Mutation/publication | Checked source/target/policy, complete MRU, independent candidate, typed failure/rollback and exact root authority. | Real DockContextProcessDock mutates context nodes/windows/tab bars and sets pending selection in place (`imgui.cpp:18697–18833`). |
| Fresh constraints | Read every successful leaf once, compose every split's 2D min/max in postorder, validate aggregates. | Pos/size update uses global WindowMinSize, style separator and per-child SizeRef; no arbitrary per-leaf maximum-composition phase (`:20642–20693`). |
| Allocation policy | General N-ary, f64 bounded solver, central semantics, exact diagnostic labels/order, minima overflow and maximum unallocated outcomes. | Binary float allocation with size locks/central SizeRef/rounded ratio paths; stored native visibility and flags. Equal fixture output is a common subset, not identical algorithms. |
| Geometry destination | Three fresh root-local result buffers, complete exact-identity node/split APIs, old immutable outputs and Clone. | Pos/Size overwrite on existing context-owned nodes; no independent old rich projection (`:20621–20625`, `imgui_internal.h:2140–2142`). |
| Additional stored result | Node constraints, child min/max/actual extent, following gap, split overflow/unallocated and central index. | No corresponding separately materialized output fields in this measured routine. Native SizeRef/flags and other context state still exist. |

ImGui is not merely one arithmetic walk overall. The wrapper calls
DockNodeUpdateForRootNode on all roots before its mutation timestamp
(`wrapper:339–342`); that invokes recursive flags/collapse and FindInfo
(`imgui.cpp:19260`, `:19376`). With no central node, FindInfo's central-dependent
early exit does not truncate this fixture. Edge split also calls a local
DockNodeTreeUpdatePosSize inside mutation (`:20554`) before the wrapper's
explicit all-root layout. Phase names therefore do not give symmetric work
partitions; subtracting or summing independent phase medians is invalid.

## Source inventory after packed output

Let P be initial total panes and V logical roots. For successful non-edge
fixture output: leaves L=P, splits S=P−V, nodes N=2P−V, parent-child edges
E=2S and following gaps G=S. Edge adds one leaf, one split, two nodes,
two edges and one gap. Items remain 2P.

| Logical materialization | Count |
| --- | ---: |
| Common fresh export words | 9N + 2P; edge adds 18 |
| NodeResult rectangle components | 4N f64 values |
| NodeResult min/max components | 4N f64 values |
| ChildProjection minimum/maximum/extent | 3E f64 values |
| Materialized following-gap components | 4G f64 values |
| Split overflow/unallocated | 2S f64 values, plus optional central index |
| Fresh rich result buffers | 3 per root, hence 3V |

For 16 panes: one view has N=31/S=15/E=30/G=15 and 311 common words;
four views have N=28/S=12/E=24/G=12 and 284 words. The listed rich numeric
fields total 428 and 368 f64 logical values respectively, excluding optional
indices, padding, IDs/topology and other native/Rust state. These are field
counts, not sizeof values, allocator bytes, physical store counts or traffic.
Node and child placeholder initialization also precedes their final writes.
ImGui's existing native node storage must not be falsely described as only
four floats per node; its SizeRef, flags, pointers and tab state are real.

Rust measurement visits N postorder rows (`topology.rs:149`), invokes the fresh
reader L times on success, and gathers E copied child measurements. Each split
then reduces min/max across both dimensions. Projection makes the separate
preorder bounds/allocation traversal, retaining parent continuations for late
gap construction. It converts actual weights, materializes every child field,
and retains a reusable generic numerical scratch owner. These describe
concrete loops/owners, not their machine cost. Root's SmallVec, fused, axis
inline, numerical inline and persistent-directory queue is not repeated here.

## Dependencies that prevent a simple one-pass replacement

To allocate a parent, its direct children's composed constraints must already
be known; those depend on deeper fresh leaves. Child bounds in turn depend on
the parent's actual available extent and sibling allocation. Postorder
measurement followed by preorder allocation is the current expression of
this dependency. Delayed minimum measurement additionally exists before root
bounds are known (`layout.rs:539–595`); its later maxima completion remains
semantically distinct.

Reader and error order matter. Completing an earlier subtree can fail a
constraint aggregate before requesting a later sibling. Whole-root measurement
also precedes geometry allocation. Allocating an early branch before later
measurement completes can reverse Geometry versus MissingLeafConstraints or
aggregate errors. Raw DAG first-completion reuse, active-cycle rejection and
later projection revisits add another reason not to replace the executor with
an unchecked tree-only traversal.

Fresh node/edge results must remain independently owned even after Workspace
changes or dies; a borrowed view of mutable live nodes cannot satisfy that
contract. Conversely, the contract does not require today's exact three Vecs,
all default writes, repeated dispatches or code placement. Those are
implementations, so no numerical lower bound follows from the contract.

Some field checks are not redundant: LogicalSize construction rejects
nonfinite/negative results; Constraints::new checks width then height ordering;
LogicalRect construction checks newly added endpoints. Finite components can
overflow during sums/subtraction or endpoint addition. Compose computes
minimum then maximum, and the solver computes both totals before its
minimum-infeasible exit. Deriving a solver total by subtracting splitter extent
from the already rounded composed constraint is not generally bit-exact and
can change diagnostics. No such derivation is recommended.

## One new bounded direction: keep an unchanged checked assigned total

In `solve_validated_axis_into`, the first
`checked_sum(sizes, "assigned size")` is at `layout.rs:404`. It then calls grow
only for assigned<extent, or shrink only for assigned>extent. When assigned
equals extent, neither branch writes sizes. Nevertheless line 425 runs the
same checked reduction again over the unchanged slice.

A minimal single-executor change could reuse the first exact total only on
that equality path, and retain the existing second reduction after either
potentially modifying branch. The first total and extent have already passed
finite checks. Thus equality is a runtime fact about this actual solve, not a
binary-fixture tag, cached invariant, alternate solver or approximate tolerance.
No output write, reader, clamp, ordering or error can be removed on other paths.
The repeat over an unchanged finite slice has the same bits and cannot newly
produce an aggregate failure.

This can stay inside layout.rs's existing executor, with a few control-flow
lines and no new parameter or owner. It should retain every reduction inside
grow/shrink and after either branch even if that particular redistribution
ultimately writes nothing. Do not infer “no change” from central/arity tags
or omit the final finite check after real numerical work.

The distinct earlier observation about reusing the validator's weight total
is less local: it needs value propagation across validation/executor/desired
helpers and interacts with the pending extent-only axis treatment. I would
not combine it into this smallest experiment. Nor should a persistent
weight/min/max summary or new validation-parameter framework be introduced.

The compiler may already eliminate the unchanged equality-path reduction,
and extra control flow can affect layout/liveness negatively. No improvement
is claimed. The existing independent numerical property/bitwise oracle,
central/nary/override tests, raw diagnostic order and full owned-output
matrix can qualify a later Root-owned experiment; no duplicate solver or
benchmark-specific shortcut is needed.

All claimed opportunities here remain source hypotheses. The required next
decision uses the complete unchanged operation, full vector equality and
negative/tail evidence after the current queue. Neither the additional rich
contract nor an unmeasured scalar reuse justifies a stopping conclusion,
an allocator share, or a “Rust ownership is inherently slower” explanation.
