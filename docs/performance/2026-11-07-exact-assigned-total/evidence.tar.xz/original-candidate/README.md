# Reuse the exact unchanged assigned-size total

READY / source stationary / not qualified. Parent is immutable
`eb94cb242722962c9e0d88074d81cf462d784357`, including retained packed output.
The sole source change is five added lines and one removed line inside
`solve_validated_axis_into`. There is one production numerical executor.

Only this new temporary directory was written. No repository, fork, cache,
Git state, old candidate or report was changed. No Cargo, compiler, formatter,
test, runner, timing, benchmark, profiler, nm, network or child agent was used.
Root owns independent review, execution and retention.

## Exact change

The first checked assigned-size reduction remains at its original position.
The original comparisons, calls and argument expressions for grow/shrink are
unchanged. At the original second reduction position:

- If that first checked total exactly equals extent, reuse the same scalar.
- Otherwise run the original second checked_sum over sizes, with the original
  "assigned size" error label, after the same potential numerical writes.

The old assigned binding is the value read by the new binding's initializer.
Equality is checked on that original total, not on a new approximation or a
mutated sum. There is no tolerance-based shortcut, new state, saved cross-call
value, persistent summary, arity/fixture tag or extra parameter.

The final allocation_tolerance expression, overflow/unallocated expressions
and outcome construction remain byte-identical. The design deliberately keeps
this shared final tail instead of adding an equality early return.

## Why values and errors are preserved

Both entry boundaries remain unchanged: public solve_axis and the private
projection wrapper first validate extent, lengths, central bounds and weights.
The first checked_sum accepts only a finite assigned total. An error from it
returns before either numerical branch or the new conditional.

For finite first total and finite extent, exact equality implies both original
strict comparisons are false. Neither grow_to_extent nor shrink_to_extent runs.
Nothing else between the two reductions writes sizes, reads user callbacks or
publishes output. The old second reduction therefore reads the same slice in
the same order as the first and returns the same finite bits. Reusing that
already checked scalar removes no newly reachable error. Signed zero does not
change this reasoning: repeating the same reduction over an unchanged slice
would reproduce the first result's bits, not derive a new total from extent.

For unequal totals the old second reduction remains, even if redistribution
eventually changes nothing. Positive residual, insufficient capacity, central
allocation, zero-weight capacity and bounded-rounding behavior continue through
the same helpers and the same checked final sum. No post-write aggregate check
is skipped.

Empty-input, minimum-infeasible and maximum-infeasible returns precede this
change and remain exact. Minimum then maximum aggregate ordering is unchanged,
including maximum aggregate errors before the minimum-infeasible return.
Desired-size computation, clamping and the first assigned error likewise
retain their positions. No NaN/extent check or arithmetic operation is moved,
and every retained reduction keeps its child order. The final overflow and
unallocated tolerance policy is not replaced with a hard-coded zero outcome.

Fresh leaf measurement, postorder composition, raw DAG behavior, central route,
release prefix, geometry/gap error order, all materialized packed result fields,
old output lifetime and Clone remain unchanged. No test or probe source changes.

## Scope, costs and qualification

Nine complete base/tree pairs come from immutable Git blobs. Eight pairs,
including the independent reference, all semantic test modules, raw topology,
geometry, profile and complete benchmark file, are byte-identical.
Removing the single conditional replacement recreates the whole parent
layout.rs. No inline/axis specialization, SmallVec, fused continuation,
persistent directory, dependency or buffer change is mixed in.

This is a source-level redundant-read removal, not a measured speedup. The
compiler may already eliminate the equality-path repeated reduction. The new
comparison and branch can change code layout, liveness and optimization, or
regress unequal-total solves. It does not remove allocation, output, fresh
inputs or any declared timer work. No allocator share or latency estimate is
claimed.

Existing meaningful qualification includes the independent numerical property
and bitwise solver oracle, full layout oracle, central/nary/mixed constraints,
min/max infeasibility, zero weights, raw errors, delayed override priority,
descendant-before-gap failures, old-output clones and genuine 10k depth.
No mirrored solver or storage-form test is added. Root must qualify this exact
binary and compare the complete unchanged operation, including negative cells
and tails, before any retention decision.

`manifest.json`, `source-pairs.md`, `scope-checks.json` and READY bind the exact
one-hunk patch, complete source pairs and copied input analysis. Set digests
sort UTF-8 relative path strings, not filesystem Path components.
