# Independent source review request

Parent: immutable `eb94cb242722962c9e0d88074d81cf462d784357`.
One runtime file, one hunk, +5/-1 inside the sole
solve_validated_axis_into executor. No execution or performance qualification.

Please verify that only the second checked assigned reduction changes.
The equality condition uses the first finite checked total. That exact
equality makes both original grow/shrink comparisons false, so the intervening
slice is unchanged and the first sum's bits equal the former second result.

All unequal paths must keep the original post-write checked sum and label,
even if a grow/shrink helper ultimately writes nothing. Challenge overflow,
underallocation, zero/signed zero, finite/NaN rejection and error ordering.
Minimum/maximum short exits, desired/clamp, helpers and all final tolerance/
outcome expressions must remain byte-identical.

Check the inverse whole-file reconstruction and eight unchanged context pairs:
tests/reference/raw compiler/profile/probe/timers/inputs/export/packed output
are untouched. No inline hint, alternate solver, cache, flag or dependency
belongs in the patch. Root remains the sole execution/qualification owner.
