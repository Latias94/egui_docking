"""Bounded diagnostic of the existing frozen probe; never a formal performance score."""
import datetime
import hashlib
import json
import lzma
import os
from pathlib import Path
import shutil
import subprocess
import sys

root = Path('/Users/frankorz/codes/rust/egui_docking')
base = Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
frozen = base / sys.argv[1]
out = base / 'current-small-profile'
out.mkdir()
receipt = json.loads((frozen / 'source-receipt.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
assert all(sha(root / name) == value for name, value in receipt['sources'].items())
exe = frozen / 'dockspace_docking_cost'
assert sha(exe) == receipt['binary_sha256']
record = {'started_utc': now(), 'frozen_source_receipt': str(frozen / 'source-receipt.json'),
          'frozen_receipt_sha256': sha(frozen / 'source-receipt.json'),
          'binary_sha256': sha(exe), 'sources': receipt['sources'],
          'scope': 'Existing whole probe keeps its10000sample cap and may exit before the requested four-second observation. Fixture also invokes project_all_roots/export_state, and validation and rich-result disposal are outside formal timed operation. Only explicit measure-operation ancestry may support narrower attribution. No complete score, allocator fraction or lower bound.',
          'runs': []}
for views, case in [(4, 'resize'), (1, 'edge_split')]:
    prefix = out / f'16-{views}-{case}'
    raw = prefix.with_suffix('.csv')
    env = dict(os.environ, DOCKSPACE_DOCK_COST_PANES='16', DOCKSPACE_DOCK_COST_VIEWS=str(views),
               DOCKSPACE_DOCK_COST_CASE=case, DOCKSPACE_DOCK_COST_SAMPLES='10000',
               DOCKSPACE_DOCK_COST_WARMUP='8', DOCKSPACE_DOCK_COST_OUT=str(raw))
    env.pop('DOCKSPACE_DOCK_COST_STATE_DIR', None)
    command = [str(exe), '--exact', 'docking_cost::docking_cost', '--ignored', '--nocapture', '--test-threads', '1']
    entry = {'views': views, 'case': case, 'samples': 10000, 'warmup': 8,
             'command': command, 'started_utc': now()}
    with prefix.with_suffix('.stdout').open('w') as stdout, prefix.with_suffix('.stderr').open('w') as stderr:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=stdout, stderr=stderr)
        sample = ['sample', str(process.pid), '4', '1', '-mayDie', '-file', str(prefix.with_suffix('.sample.txt'))]
        entry['sample_command'] = sample
        try:
            result = subprocess.run(sample, text=True, capture_output=True, timeout=15)
            entry['sample_returncode'] = result.returncode
            prefix.with_suffix('.sample.log').write_text(result.stdout + result.stderr)
            entry['workload_returncode'] = process.wait(timeout=55)
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=5)
    entry['finished_utc'] = now()
    assert entry['sample_returncode'] == entry['workload_returncode'] == 0, entry
    entry['raw_bytes'] = raw.stat().st_size
    with raw.open('rb') as source, lzma.open(prefix.with_suffix('.csv.xz'), 'wb', preset=3) as target:
        shutil.copyfileobj(source, target)
    entry['raw_sha256'] = sha(raw)
    entry['compressed_sha256'] = sha(prefix.with_suffix('.csv.xz'))
    record['runs'].append(entry)
    (out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    print(views, case, 'diagnostic complete', flush=True)
record.update(finished_utc=now(), sources_unchanged=all(sha(root / name) == value for name, value in receipt['sources'].items()),
              frozen_binary_unchanged=sha(exe) == record['binary_sha256'])
assert record['sources_unchanged'] and record['frozen_binary_unchanged']
(out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
