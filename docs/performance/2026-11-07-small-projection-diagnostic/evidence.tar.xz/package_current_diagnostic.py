"""Preserve current-runtime location evidence, excluding redundant raw CSV copies."""
from pathlib import Path
import hashlib
import io
import json
import shutil
import tarfile

root = Path('/Users/frankorz/codes/rust/egui_docking')
base = Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
out = root / 'docs/performance/2026-11-07-small-projection-diagnostic'
out.mkdir(exist_ok=True)
inputs = {}
for directory in ['current-small-profile', 'current-long-profile']:
    for p in sorted((base / directory).iterdir()):
        if p.is_file() and (p.suffix in ['.json', '.rs', '.patch', '.stdout', '.stderr', '.log', '.txt'] or p.name.endswith('.csv.xz')):
            inputs[str(p.relative_to(base))] = p.read_bytes()
for name in ['profile_current_small.py', 'profile_current_long.py', 'classify_current_long.py', 'package_current_diagnostic.py', 'binary-measurement-gather-frozen/source-receipt.json']:
    inputs[name] = (base / name).read_bytes()
for name in ['current-small-profile-scope-review', 'current-long-profile-scope-review', 'current-long-profile-evidence-review']:
    inputs['reviews/' + name + '.md'] = Path('/tmp/' + name + '.md').read_bytes()
manifest = {n: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for n, data in sorted(inputs.items())}
with tarfile.open(out / 'evidence.tar.xz', 'w:xz', preset=6) as archive:
    for name, data in [*sorted(inputs.items()), ('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode())]:
        member = tarfile.TarInfo(name); member.size = len(data); member.mode = 0o644; archive.addfile(member, io.BytesIO(data))
with tarfile.open(out / 'evidence.tar.xz', 'r:xz') as archive:
    for member in archive:
        assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
        data = archive.extractfile(member).read()
        assert json.loads(data) == manifest if member.name == 'manifest.json' else data == inputs[member.name]
shutil.copy2('/tmp/current-long-profile-evidence-review.md', out / 'independent-evidence-review.md')
shutil.copy2(base / 'current-long-profile/attribution.json', out / 'attribution.json')
(out / 'archive-check.json').write_text(json.dumps(dict(regular_input_files=len(inputs), all_members_roundtrip_equal=True, diagnostic_observations=1000000, formal_scores_added=0, archive_bytes=(out / 'evidence.tar.xz').stat().st_size), indent=2) + '\n')
(out / 'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(out.iterdir()) if p.is_file() and p.name != 'SHA256SUMS'))
print('Archived', len(inputs), 'inputs;', (out / 'evidence.tar.xz').stat().st_size, 'bytes')
