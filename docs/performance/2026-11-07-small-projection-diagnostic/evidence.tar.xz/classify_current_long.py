"""Report inclusive sampled ancestry, never timing shares or instruction counts."""
import json
from pathlib import Path
import re
import subprocess

base = Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
out = base / 'current-long-profile'
result = {'scope': 'Inclusive samples of disjoint outermost named call subtrees. Excludes fixture ancestry. Inline/unresolved direct probe code and post-return drops are unclassified. No allocator-time fraction, operation clock fraction or lower bound.', 'cases': {}}
for name in ['16-4-resize', '16-1-edge_split']:
    text = (out / (name + '.sample.txt')).read_text()
    graph = text.split('Call graph:\n', 1)[1].split('Total number in stack', 1)[0]
    nodes = []
    stack = []
    for line in graph.splitlines():
        m = re.match(r'^([ +!:|]*)(\d+) (.*)$', line)
        if not m:
            continue
        prefix, count, label = m.groups()
        depth = len(prefix)
        while stack and nodes[stack[-1]]['depth'] >= depth:
            stack.pop()
        node = {'depth': depth, 'samples': int(count), 'label': label, 'ancestors': stack.copy(), 'line': line}
        nodes.append(node)
        stack.append(len(nodes) - 1)
    worker = [n for n in nodes if 'Thread_' in n['label'] and ': docking_cost::docking_cost' in n['label']]
    assert len(worker) == 1
    phases = {}
    selected = {}
    for phase, token in [('timed_layout_with_fresh_leaf_input', 'dockspace::docking_cost::project_all_roots::'),
                         ('timed_candidate_preparation', 'dockspace::graph::operation::prepare_transaction_inner::')]:
        ids = []
        for i, n in enumerate(nodes):
            ancestry = [nodes[a]['label'] for a in n['ancestors']]
            if token in n['label'] and not any('dockspace::docking_cost::fixture::' in a or token in a for a in ancestry):
                assert any('Thread_' in a and ': docking_cost::docking_cost' in a for a in ancestry)
                ids.append(i)
        phases[phase] = {'inclusive_samples': sum(nodes[i]['samples'] for i in ids), 'outermost_roots': len(ids)}
        selected[phase] = ids
    growth = []
    for i, n in enumerate(nodes):
        if 'RawVec$LT$T$C$A$GT$::grow_one::h370c7ae3627027d4' not in n['label']:
            continue
        ancestry = n['ancestors']
        if not any(a in selected['timed_layout_with_fresh_leaf_input'] for a in ancestry):
            continue
        if any('RawVec$LT$T$C$A$GT$::grow_one::h370c7ae3627027d4' in nodes[a]['label'] for a in ancestry):
            continue
        growth.append({'inclusive_samples': n['samples'], 'path': [nodes[a]['label'] for a in ancestry if 'dockspace::' in nodes[a]['label']] + [n['label']]})
    result['cases'][name] = {'worker_samples': worker[0]['samples'], 'phases': phases, 'timed_projection_stack_growth_inclusive_samples': sum(n['inclusive_samples'] for n in growth), 'growth_paths': growth}

exe = str(out / 'diagnostic_docking_cost')
for name, args in [('grow-one-48byte', ['--disassemble-symbols=__ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h370c7ae3627027d4E']),
                   ('project-stack-callsite', ['--disassemble', '--start-address=0x100b3887c', '--stop-address=0x100b388d4'])]:
    command = ['xcrun', 'llvm-objdump', *args, exe]
    r = subprocess.run(command, text=True, capture_output=True, check=True)
    (out / (name + '.asm.txt')).write_text(r.stdout)
    result.setdefault('disassembly', []).append({'command': command, 'returncode': r.returncode, 'output': name + '.asm.txt'})
(out / 'attribution.json').write_text(json.dumps(result, indent=2) + '\n')
assert json.loads((out / 'attribution.json').read_text()) == result
print(json.dumps(result, indent=2))
