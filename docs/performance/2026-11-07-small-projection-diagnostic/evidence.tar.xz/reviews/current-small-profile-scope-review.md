# Current small-root profile: pre-execution scope review

**Execution blocker:** `profile_current_small.py:32` requests `DOCKSPACE_DOCK_COST_SAMPLES=400000`, but the existing probe rejects settings above **10000** (`docking_cost.rs:722–727`). This ceiling is present in immutable `37e388f` as well as the inspected live probe. The workload will panic before fixture construction or timing. Do not launch this version expecting four seconds of valid workload.

Script SHA-256 reviewed: `2ee5afa8ae671797b6b070a53902bae4742c30b106c229c88ab3a90750e918c0`. No script or workload was executed. The eventual retained candidate and binary remain to be selected.

## Probe selection and binding

The environment names and exact ignored-test selector are correct. The two invocations select total **16 panes / 4 views / resize** and **16 panes / 1 view / edge_split**, with eight warmups, fresh per-iteration fixtures and the original alternating resize widths. `STATE_DIR` is removed, so optional state-file dumps are disabled; full ordinary validation and CSV output remain.

The frozen source-receipt and binary hashes are checked before launch and again after the runs. Final selection must use the actual retained receipt, with its recorded compile-time `DOCKSPACE_BENCH_NO_WORK_COUNTERS=1`; setting a runtime environment value cannot substitute for that build condition.

`400000` denotes workload iterations, not profiler stack samples. The requested `sample PID 4 1` means four seconds at a nominal one-millisecond interval. The sample subprocess has a 15-second timeout, followed by a 55-second workload wait and a five-second termination wait. The sample can also attach after a short workload has already exited. A supported iteration count does not establish four seconds of useful stacks. Resolve workload duration within the supported frozen-probe contract, or separately authorize and bind a diagnostic-only repetition change; do not silently present a rebuilt, limit-changed probe as the original frozen binary.

## What is actually timed

`measure` brackets request capture → checked apply → all-root projection → fresh owned export (`docking_cost.rs:441–468`). The exported timestamp is taken before returning the rich `Measured` owner.

| Visible call-tree ancestry | Permitted attribution |
| --- | --- |
| Measured request capture / exact source-target captures | Timed request work. Resize captures new bounds and performs no docking transaction. |
| `apply_request` → transaction apply → `prepare_transaction_inner` and its descendants | Timed checked mutation, including candidate construction, local finish, temporary cleanup and checked publication occurring within that call. |
| Measured call to `project_all_roots` | Timed layout includes the fresh leaf-input gather, every actual root projection, solver, scratch creation/disposal and complete rich output materialization. |
| Measured call to `export_state` | Timed fresh owned normalized export and its identity/integral checks. |
| `fixture` → builder/canonical/validation and initial projection/export | Entirely outside the operation clock. |
| Post-measure `validate`, `expected_state`, digest/CSV writes, fixture drop and rich `Measured` drop | Entirely outside the operation clock. |

Function names alone do not disambiguate this profile. `fixture` itself calls **the same** `project_all_roots` and `export_state` before `measure` (`90–110`). Existing `root-structure-profile/sample.txt:48–49` explicitly shows fixture/builder ancestry; its later projection child under that fixture branch remains setup. Counting every `project_measurements`, solver or projection allocation anywhere in the tree would merge setup with timed work.

Likewise, validation, canonicalization, allocation and destruction need their owning ancestor. A temporary dropped inside transaction apply or layout is timed; `drop(fixture)` and `drop(measured)` at `799,820` are not. Generic allocator or `drop_in_place` frames cannot be pooled into a timed category by symbol alone.

Optimized builds may inline `measure` and phase helpers into `docking_cost::docking_cost`, as the older samples demonstrate. The broad test ancestor includes the complete loop. Unresolved direct samples in that ancestor must stay unclassified unless that exact binary's callsite mapping establishes their location. Older symbol hashes, offsets or category percentages cannot classify the final binary.

Use only disjoint, explicitly owned subtrees for narrower diagnostic claims; do not add parent and child sample counts. These whole-process samples include clocks, setup, postvalidation, disposal, output and the waiting test-harness thread. They establish neither formal phase-time fractions, allocator fractions, counterfactual summed medians nor a performance lower bound.
