Static scope review: longer sampling of the retained small-operation probe

No scope blocker. Prefer the temporary, exact cap-only repository overlay and a separately frozen diagnostic executable over copying the workspace. The reviewed script preserves the runtime, workload, timers, and output checks. This review did not build, execute, test, time, or sample anything and does not establish a performance result.

The reviewed script is `/tmp/dockspace-imgui-twofold-20261107-ea4161e/profile_current_long.py`, SHA256 `3c97fed2a18061a581203c164115c4c756f8d29768e2b27e7d55e4956609911f`. Below, `B` denotes `/tmp/dockspace-imgui-twofold-20261107-ea4161e`.

1. The existing short runs do not support stable hotspot attribution.

`B/current-small-profile/receipt.json` and workload stdout place the two 10,000-iteration processes below 0.3 seconds, with test-reported durations of 0.20 and 0.21 seconds. The resize sample has an empty call graph; the edge sample contains 107 observations on the test thread. Its separate main-thread observations concern libtest waiting and must not be added to the operation sample count. The sampler's successful return and “4 seconds” message do not establish that the workload survived for four seconds.

The present probe has no environment-only escape from the cap: `crates/dockspace/src/docking_cost.rs:722–727` applies `setting()` to both sample count and warmup. Increasing warmup within the same cap gives little additional coverage and changes the warmup workload. Repeatedly launching the old executable does not extend one PID's lifetime and adds attachment and startup boundaries. One exact assertion replacement is the smaller intervention.

2. The new script correctly separates diagnostic source and executable identities.

The immutable runtime is `49baba1b2b7ad8e152e8b4da180a2e130d5fce9f`. Its formal receipt, `B/binary-measurement-gather-frozen/source-receipt.json`, has SHA256 `05616f277085a63cf14fbbc1a217942ff029628417a66445b3581f0d3d580de5` and records 324 source hashes. The initial source comparison found all 324 equal. The formal executable hash is `6d255458eac25cd9dcf629b88cfca6959c78db7ed2bb7ccf08fe2cba6332dcfd`.

Script lines 19–45 require that baseline, save the original probe bytes, require one occurrence of the old assertion, and verify that only the expected probe hash changes. The replacement raises the shared limit from 10,000 to 1,000,000 and updates its diagnostic message. It changes no timer, executor, fixture, visibility, inline attribute, or core implementation.

The saved original probe hash is `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3`; the diagnostic probe hash is `93879195c419a282c7bca446336af0a3b33d1e4854603cd71a6c8df5cb0afbf7`. The saved one-line patch hash is `c9f5a2f5f95c7b465a82714b272806e50ad7d0e483fe20ffebcd7f9c11d53c73`. The latter probe was visible during Root's authorized overlay; it is the expected diagnostic input, not a retained runtime change.

Lines 47–62 reuse the normal target with one build job, the production profile, locked/offline resolution, and `DOCKSPACE_BENCH_NO_WORK_COUNTERS=1`. Cargo JSON selects the test executable, which is copied and hashed separately. Lines 63–69 restore the original probe and require all 324 hashes to match before starting a workload. The equality guard preserves an unexpected concurrent probe edit rather than overwriting it. Final checks also compare both executable identities and the source receipt.

A successful restoration does not make the new executable the formal executable. The cap change can affect optimized code generation even while core source remains identical. Keep its samples and CSVs diagnostic; preserve the existing formal binary, receipts, comparisons, and scores.

3. The proposed longer workload preserves the relevant contracts.

Lines 71–88 select the same 16-pane cases, four-view resize and one-view edge split, with 500,000 measured iterations, eight warmups, one test thread, and four seconds of 1 ms sampling. This is a bounded diagnostic extension. The earlier short durations make additional coverage plausible; they do not prove that either future workload will last a particular duration.

The probe still creates a fresh fixture per iteration (`docking_cost.rs:782–795`). `measure()` still captures the request, applies the transaction, freshly projects all roots, and exports the complete result before its final timestamp (`441–468`). Independent validation, workspace destruction, comparison against expected words, CSV output, and returned rich-output destruction remain in their original positions (`796–820`). No input, output, or actual layout work moves outside the timed operation. Warmup retains its original behavior.

The larger CSV is streamed through the existing buffered writer; increasing iterations does not retain every fixture or projection. File creation still refuses an existing output. The script retains and compresses the raw CSV rather than silently removing validation or export to prolong execution. It does not compute a formal comparison.

4. Attribute only stacks whose ancestry identifies the timed operation.

`measure()` was inlined in the existing sample. `project_all_roots` remains visible, but fixture construction also calls it (`87–110`). Consequently, a layout symbol by itself is insufficient. A `project_all_roots` ancestry without `fixture` identifies the timed projection call in this probe; stacks below `fixture` belong to setup. Transaction preparation under the actual apply path is another useful boundary. Do not add `inline(never)` merely to manufacture a convenient sample boundary.

Exclude identifiable fixture construction, post-measure validation, fixture teardown, and destruction of the returned rich result when reporting timed-operation locations. Temporary-owner destruction inside transaction application remains part of the operation. Leave ambiguous or truncated ancestry unresolved. Inclusive `RawVec::grow_one` samples are location evidence, not allocation counts, exclusive allocator time, formal latency share, or a lower bound obtained by subtracting phase medians.

Two operational qualifications do not block this diagnostic. First, `process.wait(timeout=55)` starts after the sampler returns; it is not an absolute 55-second deadline from process launch. Second, a sampler or workload timeout exits before lines 93–95 append the current run to the receipt. Existing files and the invocation traceback can preserve the failure, but an absent run entry must not be interpreted as success. Require both zero return codes, actual useful test-thread coverage, and the final identity checks before describing a completed diagnostic. No additional profiling framework is needed.
