"""One-line diagnostic loop extension; no formal scores or retained source changes."""
import datetime
import difflib
import hashlib
import json
import lzma
import os
from pathlib import Path
import shutil
import subprocess

root = Path('/Users/frankorz/codes/rust/egui_docking')
base = Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
frozen = base / 'binary-measurement-gather-frozen'
out = base / 'current-long-profile'
out.mkdir()
sha = lambda data: hashlib.sha256(data).hexdigest()
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
formal = json.loads((frozen / 'source-receipt.json').read_text())
hashes = lambda: {p: sha((root / p).read_bytes()) for p in formal['sources']}
assert hashes() == formal['sources']
probe = root / 'crates/dockspace/src/docking_cost.rs'
original = probe.read_bytes()
old = b'assert!(value <= 10_000, "benchmark iteration setting exceeds 10000");'
new = b'assert!(value <= 1_000_000, "diagnostic iteration setting exceeds 1000000");'
assert original.count(old) == 1
modified = original.replace(old, new)
(out / 'original-probe.rs').write_bytes(original)
(out / 'diagnostic-probe.rs').write_bytes(modified)
(out / 'only-probe-change.patch').write_text(''.join(difflib.unified_diff(original.decode().splitlines(True), modified.decode().splitlines(True), fromfile='formal/docking_cost.rs', tofile='diagnostic/docking_cost.rs')))
record = {'started_utc': now(), 'runtime_commit': '49baba1',
          'formal_receipt_sha256': sha((frozen / 'source-receipt.json').read_bytes()),
          'formal_binary_sha256': formal['binary_sha256'], 'formal_sources': formal['sources'],
          'scope': 'Diagnostic only: exactly one iteration-cap assertion changes. Runtime core remains byte-identical. Full fixture/validation/output destruction remains outside timed operation. Only unambiguous timed ancestry may support narrow location findings; no formal score, allocator share or latency lower bound.',
          'probe_original_sha256': sha(original), 'probe_diagnostic_sha256': sha(modified),
          'runs': []}
save = lambda: (out / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
save()
assert json.loads((out / 'receipt.json').read_text()) == record
probe.write_bytes(modified)
try:
    during = hashes()
    expected = dict(formal['sources'])
    expected[str(probe.relative_to(root))] = sha(modified)
    assert during == expected
    record['diagnostic_sources'] = during
    command = ['cargo', 'test', '--package', 'dockspace', '--lib', '--profile', 'production', '--locked', '--offline', '--no-run', '--message-format=json-render-diagnostics']
    record['build_command'] = command
    env = dict(os.environ, CARGO_BUILD_JOBS='1', DOCKSPACE_BENCH_NO_WORK_COUNTERS='1')
    with (out / 'build.stdout').open('w') as stdout, (out / 'build.stderr').open('w') as stderr:
        result = subprocess.run(command, cwd=root, env=env, stdout=stdout, stderr=stderr, timeout=300)
    record['build_returncode'] = result.returncode
    save()
    assert result.returncode == 0
    assert hashes() == during
    artifacts = [json.loads(line) for line in (out / 'build.stdout').read_text().splitlines() if line.startswith('{')]
    exes = [e['executable'] for e in artifacts if e.get('reason') == 'compiler-artifact' and e.get('executable') and e.get('target', {}).get('name') == 'dockspace']
    assert len(exes) == 1
    exe = out / 'diagnostic_docking_cost'
    shutil.copy2(exes[0], exe)
    record['diagnostic_binary_sha256'] = sha(exe.read_bytes())
    save()
finally:
    assert probe.read_bytes() == modified, 'Unexpected concurrent probe edit: preserve and inspect instead of overwriting'
    probe.write_bytes(original)
    record['sources_restored_before_run'] = hashes() == formal['sources']
    record['restoration_utc'] = now()
    save()
    assert record['sources_restored_before_run']

for views, case in [(4, 'resize'), (1, 'edge_split')]:
    prefix = out / f'16-{views}-{case}'
    raw = prefix.with_suffix('.csv')
    env = dict(os.environ, DOCKSPACE_DOCK_COST_PANES='16', DOCKSPACE_DOCK_COST_VIEWS=str(views), DOCKSPACE_DOCK_COST_CASE=case,
               DOCKSPACE_DOCK_COST_SAMPLES='500000', DOCKSPACE_DOCK_COST_WARMUP='8', DOCKSPACE_DOCK_COST_OUT=str(raw))
    env.pop('DOCKSPACE_DOCK_COST_STATE_DIR', None)
    command = [str(exe), '--exact', 'docking_cost::docking_cost', '--ignored', '--nocapture', '--test-threads', '1']
    entry = {'views': views, 'case': case, 'samples': 500000, 'warmup': 8, 'command': command, 'started_utc': now()}
    print('sample', views, case, flush=True)
    with prefix.with_suffix('.stdout').open('w') as stdout, prefix.with_suffix('.stderr').open('w') as stderr:
        process = subprocess.Popen(command, cwd=root, env=env, stdout=stdout, stderr=stderr)
        sample = ['sample', str(process.pid), '4', '1', '-mayDie', '-file', str(prefix.with_suffix('.sample.txt'))]
        entry['sample_command'] = sample
        try:
            result = subprocess.run(sample, text=True, capture_output=True, timeout=15)
            entry['sample_returncode'] = result.returncode
            prefix.with_suffix('.sample.log').write_text(result.stdout + result.stderr)
            entry['workload_returncode'] = process.wait(timeout=55)
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=5)
    entry['finished_utc'] = now()
    record['runs'].append(entry)
    save()
    assert entry['sample_returncode'] == entry['workload_returncode'] == 0, entry
    entry['raw_bytes'] = raw.stat().st_size
    entry['raw_sha256'] = sha(raw.read_bytes())
    with raw.open('rb') as source, lzma.open(prefix.with_suffix('.csv.xz'), 'wb', preset=3) as target:
        shutil.copyfileobj(source, target)
    entry['compressed_sha256'] = sha(prefix.with_suffix('.csv.xz').read_bytes())
    save()
record.update(finished_utc=now(), sources_unchanged=hashes() == formal['sources'], diagnostic_binary_unchanged=sha(exe.read_bytes()) == record['diagnostic_binary_sha256'], formal_binary_unchanged=sha((frozen / 'dockspace_docking_cost').read_bytes()) == formal['binary_sha256'])
assert record['sources_unchanged'] and record['diagnostic_binary_unchanged'] and record['formal_binary_unchanged']
save()
assert json.loads((out / 'receipt.json').read_text()) == record
print('Current-runtime diagnostic complete; source restored; no formal score', flush=True)
