# Independent source review request

Parent: immutable `a2365aa876c51a66a5c9c788bff9056afdbabacd`.
Only this new tmp package was written. No build, test, formatter, runner,
timing, dependency resolution or application has occurred.

Please review the one private NodeStore representation change:
`Arc<SlotMap<NodeId, ()>>` plus
`rpds::HashTrieMapSync<NodeId, Arc<Node>>`, pinned to rpds 1.2.1.

Check the complete-key pairing across birth, mutable access, whole replacement,
successful/missing removal, all-keep and ordered-deletion retain. Ordinary
get/shared should have one directory lookup; iter/values must retain allocator
slot order and fail explicitly for an occupied key missing its value.

Challenge candidate-local allocation/generation/free-head behavior, two
branches with equal numeric IDs, old WorkspaceSnapshot and payload lifetime,
late failure/retry, existing Builder owned-return counts, Send/Sync and
compatibility with the unchanged graph/canonical/authority/RootStructure
Interfaces. The two new tests are semantic witnesses to be executed by Root.

Inspect the counter rename carefully: two store-root owner copies replace the
former N payload-handle fork copies; internal rpds pointer/Entry/Arc copies and
allocator COW are expressly not measured. Logical inventory remains nonzero.
The only work-probe code changes are the field/column and comments; formal
measure/project/input/export code remains byte-identical.

Review default construction, slow reads, small graphs, structural allocator
COW, persistent path destruction and ordered retain's temporary list as
negative costs. No asymptotic or source fact establishes whole-kernel benefit.
Five build lockfiles deliberately await Root's real resolution; no transitive
versions or registry checksums were invented.
