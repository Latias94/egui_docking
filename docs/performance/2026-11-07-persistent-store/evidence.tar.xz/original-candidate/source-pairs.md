# Complete immutable source pairs

Parent: `a2365aa876c51a66a5c9c788bff9056afdbabacd`. All base files are immutable Git blobs, not live worktree copies.
Seventeen complete base/tree pairs; six changed paths and eleven byte-identical context pairs.

| Relative path | Base SHA-256 | Candidate SHA-256 | Bytes (base / candidate) | Role |
| --- | --- | --- | ---: | --- |
| `Cargo.toml` | `03937455cf6bd2c7124d6c17efc374244324d4d6a64f8c15af430ad7c97d17b7` | `65badf3bf40471172e8cc1310b5ea6717497e8e32c28e7e72d47e235aa9260c8` | 1378 / 1394 | dependency_manifest |
| `crates/dockspace/Cargo.toml` | `effacceb9d309c7351ba7e9504101716341ca874e085fea2572e3c79b9e17c03` | `cc4c3221546507926f502345e7fe97b23aed350ac689cf344debe20816e6a9be` | 969 / 991 | dependency_manifest |
| `crates/dockspace/src/canonical.rs` | `b2f1ab4bd5b7e5933966c54792b30f4d257f823f172a75c8686f9260af0ea517` | `b2f1ab4bd5b7e5933966c54792b30f4d257f823f172a75c8686f9260af0ea517` | 39160 / 39160 | unchanged_context |
| `crates/dockspace/src/docking_cost.rs` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` | `e3f01bc25639474ccb05bc03267552f36af3c48f4b59d7e4382f498a1044373e` | 30626 / 30739 | test_only_work_probe |
| `crates/dockspace/src/drop_resolver.rs` | `f8b093f247417b4abe2a79dc13febb0549bf214066c4bc9dc0739a72e2579a7f` | `0cd72e80d13768c5b2011f8ac9e9c3d93d8d775367a28d47889f8775cf51cd9a` | 159234 / 159484 | test_only_work_ledger |
| `crates/dockspace/src/graph.rs` | `ea8aa5ffe7b4b7d67ad80cb289631e05b3da53a8cf01b6441d2d2de180f04951` | `ea8aa5ffe7b4b7d67ad80cb289631e05b3da53a8cf01b6441d2d2de180f04951` | 26950 / 26950 | unchanged_context |
| `crates/dockspace/src/graph/authority.rs` | `89d0d337cdc2365caf62f5dd2d48d6f9132b21c2d4b882e9c24096cc6602a600` | `89d0d337cdc2365caf62f5dd2d48d6f9132b21c2d4b882e9c24096cc6602a600` | 19490 / 19490 | unchanged_context |
| `crates/dockspace/src/graph/copy_tests.rs` | `fa5478d74b3e851fa74f26dfeb6d0f1bd2176b091ceca0bd3048697cc1be39c4` | `4ed46743f2c937adb34de605c8d560cef950dbc8e6edb2f6d975ba19a4ac2713` | 15905 / 22523 | registered_semantic_tests |
| `crates/dockspace/src/graph/root_structure.rs` | `e80a74d1bdef525bd25a9a627bd1c826f41cd1def8fe05583dcea14372938632` | `e80a74d1bdef525bd25a9a627bd1c826f41cd1def8fe05583dcea14372938632` | 8490 / 8490 | unchanged_context |
| `crates/dockspace/src/graph/shared_storage.rs` | `18c6f75150643779acb9c71c30486634b19f7ccec5677e4cc64ce9043fcc532e` | `3d9dcb3cd775703efc2de749665f3a7405e3859de0e44f3406fb64e7c984b668` | 2298 / 3628 | production_runtime |
| `crates/dockspace/src/ids.rs` | `28ab22cb6736b89376b9c3f1c99ed222aa54a172d16a51acaa8c457577b7f5db` | `28ab22cb6736b89376b9c3f1c99ed222aa54a172d16a51acaa8c457577b7f5db` | 8775 / 8775 | unchanged_context |
| `crates/dockspace/src/layout.rs` | `478cf5a1f3c6cf41cd3f21f3dfdc301a350957f18f58f900376edb256e38c05e` | `478cf5a1f3c6cf41cd3f21f3dfdc301a350957f18f58f900376edb256e38c05e` | 50341 / 50341 | unchanged_context |
| `crates/dockspace/src/operation.rs` | `7586ec06b29b77a794133e0c554d4fcca7a6faa16b8c550b86034ad394175862` | `7586ec06b29b77a794133e0c554d4fcca7a6faa16b8c550b86034ad394175862` | 146932 / 146932 | unchanged_context |
| `crates/dockspace/src/operation/tests/local_item_move.rs` | `68020548cbdbd968b09cbfdcb0dbb5a43217074cd0c504f528546d2a243815d2` | `68020548cbdbd968b09cbfdcb0dbb5a43217074cd0c504f528546d2a243815d2` | 19792 / 19792 | unchanged_context |
| `crates/dockspace/src/operation/tests/owner_reference.rs` | `8a39eb6df3d844f952af7b550f75f51c51ab6d5c853b47f8748b69adb55158d4` | `8a39eb6df3d844f952af7b550f75f51c51ab6d5c853b47f8748b69adb55158d4` | 37667 / 37667 | unchanged_context |
| `crates/dockspace/src/persistence.rs` | `bb30a2a4d3383ed633c7a42e2c5d7ddc9246573c12b08a48a569bc5059437b34` | `bb30a2a4d3383ed633c7a42e2c5d7ddc9246573c12b08a48a569bc5059437b34` | 29357 / 29357 | unchanged_context |
| `crates/dockspace/src/transaction.rs` | `0970cc5343f6eec5bc300603e78303782b3e817edb86064b3694fac4544106a2` | `0970cc5343f6eec5bc300603e78303782b3e817edb86064b3694fac4544106a2` | 16612 / 16612 | unchanged_context |

Set hash format: sort UTF-8 relative path strings by encoded bytes, then
`SHA256(concat(path + NUL + per-file SHA-256 + newline))`.

Base set: `eebd88b526b1411ed121d9a6fe5eddb9f72848e14ae66ca4c19bc5e8860bf7d0`.
Candidate set: `d06852f0f07c22105a6a9e63f0ecf589543923085fc7db8a81189e3b556e821c`.

Every primary patch hunk reconstructs its complete target from the immutable base.
No candidate lockfiles are supplied; dependency-boundary.json records the five build locks awaiting real resolution.
No formatting, compilation, Rust test, runner or timing has occurred.
