# Work-counter migration

This is an explicit metric change, not a performance result. Historical
baseline CSVs and archived evidence are unchanged. No new counter framework or
interception inside rpds is introduced.

| Location | Previous definition | Candidate definition |
| --- | --- | --- |
| `graph/shared_storage.rs::NodeStore::clone` | `record_node_store_clone(N)` while cloning all live `Arc<Node>` slots | `record_node_store_clone()` before cloning the allocator Arc and persistent directory root |
| `drop_resolver.rs::WorkspaceStorageWork` | `node_handle_clones` counts the actual N payload-handle clones performed by the former SlotMap fork | `node_store_owner_clones` counts exactly two root-owner pointer clones per fork |
| `drop_resolver.rs::record_node_store_clone` | forks += 1; payload handles += N | forks += 1; store owners += 2 |
| `docking_cost.rs::docking_work` | ordinary work CSV column `node_handle_clones` | same column position named `node_store_owner_clones` |
| Existing workspace-fork test | one store fork, N payload-handle copies, zero Node payload copies | one store fork, two root-owner copies, zero Node payload copies; also require Send + Sync |
| Existing center-move copy test | one store fork and N payload-handle copies | one store fork and two root-owner copies; all logical inventory and exact payload/MRU expectations retained |

The immutable parent's nonarchived source has six occurrences of the removed
field: two ledger references, two work-CSV references and two test assertions.
All six migrate. The original root-reference/scene work counters and formal
timing CSV do not change.

The old N and new 2 describe different operations and must not be directly
subtracted as a measurement of total copies. The candidate metric excludes:

- rpds path-vector/shared-pointer copies and shared Entry copies;
- payload Arc copies caused inside rpds entry COW;
- the old Arc cloned to satisfy successful remove's owned return;
- allocator COW slot copies, vacant slots and free-list metadata;
- allocation events, bytes, hasher work and other Workspace directories.

`node_payload_clones`, `tab_item_copies`, `mru_item_copies`,
`split_child_copies` and `split_weight_copies` still observe actual Node::clone.
The old `cloned_nodes`/`cloned_tab_items` columns remain logical source
inventory, including all nodes/items in one explicit transaction candidate.
They are deliberately not changed to zero or relabeled as physical work.

The existing `DOCKSPACE_BENCH_NO_WORK_COUNTERS` compile-environment early return
is byte-identical. Formal timing still disables these test-only counters.
The normal independent work probe remains the source of concrete payload work;
it cannot provide an uninstrumented total rpds pointer-copy count.
