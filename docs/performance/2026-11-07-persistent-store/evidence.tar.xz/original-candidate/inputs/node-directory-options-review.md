# Challenge of the remaining node-directory alternatives

Independent source review, 2026-11-07. No package selection, implementation, dependency change, compilation, test, runner, profiling, timing, network or delegation. Only this report was written.

**Decision.** Shared SlotMap allocation metadata plus persistent values is a credible bounded experiment, after Root measures the retained layout and four concrete ownership slices. The existing whole-slot copy is demonstrable work, so the idea should not be dismissed as impossible. The evidence does not yet justify the document's unconditional “then implement option 2” sequence. Constant-time candidate cloning is insufficient: the experiment must improve the complete operation with its ordinary readers, allocator writes and destruction included. A slower replacement directory could erase the small mutation saving and regress cells already meeting the target.

The source-local NodeStore boundary is useful. There is no identified need for an engine-wide read trait, second executor, persistent trust state or live undo. An overlay's publication/history problem is correctly described; replacing that problem with a persistent directory does not make its costs disappear.

**Evidence binding.** Reviewed `/tmp/node-directory-options.md`, SHA-256 `65f3f8222a9f2fdd3411d4a103a747e4fa720d820ed26d76d92580aa11e54f12`, against current sources and my earlier small-transaction analysis, SHA-256 `4f2703a4cac9016cd2832a43ecaad0a2ff5fe9a26ca15bbb5f27ffac2dced57b`. Relevant unchanged identities:

| Source | SHA-256 |
| --- | --- |
| `graph/shared_storage.rs` | `18c6f75150643779acb9c71c30486634b19f7ccec5677e4cc64ce9043fcc532e` |
| `canonical.rs` | `dda19b95f3a8c29aca4e262b9b4239e1409ca8aceaf85ef2c3432c881aea79be` |
| `docking_cost.rs` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` |
| Local SlotMap 1.1.1 `src/basic.rs` | `dd4e5c6c87d08086f454b1e062d109582818626f1d8316dcc6a91adb3ed31192` |
| Local SlotMap 1.1.1 `src/lib.rs` | `7ccea0d6d7aef7249e823fa6a6b0644f31ef46eefa93d0116ebcae12ff25d22a` |

Repository paths above are under `crates/dockspace/src/`. SlotMap sources were read from the installed registry, without changing it.

**1. The small graph may be the worst case for the claimed saving.** The formal binary fixture contains `2 * panes - views` initial nodes: only 31 or 28 at 16 panes (`docking_cost.rs:72–98`). Current cloning copies contiguous slot metadata and those occupied Arc handles (`shared_storage.rs:16–23`; SlotMap `basic.rs:967–975`). Persistent first-write path copying may copy a leaf or compact node containing many of those same handles. Two changed Tabs need not imply only two copied handles. Branch width, small-map representation, hashing, allocation granularity and mutable-access implementation are unknown until a concrete directory is reviewed.

The relevant comparison is saved slot copying and handle increments/decrements versus path copying, sibling-value clones, new path owners, lookup overhead and eventual drops. “Only O(log N)” and “bounded machine depth” do not establish a lower constant than direct indexing. Conversely, large or heavily shared histories can benefit even if the smallest dense graph does not. No latency allowance can be derived by adding or subtracting the frozen phase medians.

**2. Reader cost is part of both layout and export.** Current `get/shared` perform a SlotMap lookup and borrow its Arc (`shared_storage.rs:27–33`); SlotMap checks index and generation directly (`basic.rs:656–661`). A persistent key directory introduces hashing or tree navigation. Do not silently add an allocator lookup followed by a directory lookup for every `get` if the closed NodeStore invariant already makes a full-key directory lookup sufficient. Complete-key rejection must remain, but duplicate checking is not automatically necessary.

RootStructure already retains actual shared split payloads, so not every solver access goes through NodeStore. However, the formal fresh constraint gather visits each reachable node through `Workspace::node` (`docking_cost.rs:197–213`), and complete export does so again (`277–325`). Their two full walks remain after layout scratch optimizations. Edge changes also rebuild structure through `NodeStore::shared` (`root_structure.rs:140–146`).

Resize is a particularly strong negative control: it only updates bounds, with no transaction candidate fork (`docking_cost.rs:177–187`), but still performs those complete reads. A clone-only improvement has no fork saving there. Complete resize, center, edge and cross-view cells must therefore decide retention. The historical small-layout medians provide context, not a causal budget or a proof that another improvement cannot help.

**3. Shared allocator does not remove structural linear work.** On first shared insert/remove, `Arc::make_mut(SlotMap<NodeId, ()>)` still copies the initialized slot Vec, including holes, versions and free-list state. It avoids N payload-Arc clones at that step, but does not make edge/collapse O(1). Vacant slots survive removal; current `remove_from_slot` updates free-head and version without shrinking slots (`basic.rs:433–445`).

Distinguish live count, initialized historical slots and reserved capacity. Two 16-pane workspaces can have very different historical slot vectors. Reserved unused backing capacity is not the same thing as slots visited by cloning/iteration. `NodeStore::capacity` must continue to report allocator capacity for canonical reservation hints (`canonical.rs:462,895`), not directory length. A persistent live-value map cannot discard allocator history while preserving future keys.

There are also new constants: an Arc allocator owner, possible empty-directory storage and empty/default construction. Follow-up code uses an empty Workspace placeholder through `mem::take`; these costs must not vanish from the accounting. Old snapshots can prolong paths, and releasing their final owners can move substantial destruction to a later operation.

**4. Ordered iteration and retain need exact treatment.** Public node iteration promises deterministic arena order (`graph.rs:456,519`). Drive it from allocator keys and join values; do not sort, filter missing values away, or rebuild a key Vec for normal iteration. That preserves order but retains sparse-slot scanning and adds a directory lookup per live entry. Cold normalization must see allocated unrooted records as well as rooted nodes.

The author's warning about sorting keys needs one nuance: pinned SlotMap 1.1.1 currently derives KeyData ordering from `idx` then `version` (`lib.rs:245–249`), so ordinary key sorting happens to match occupied arena-index order. Its documentation explicitly leaves key order unspecified. Sorting numeric FFI handles instead is version-first (`283–285`) and can disagree after reuse. Neither incidental relationship should replace the allocator iterator.

Current `retain` calls its predicate once per occupied slot in ascending slot order and immediately removes rejected entries (`basic.rs:575–595`). Removal order changes free-head and the next allocation. Collecting actual removals before COW can preserve the all-keep fast case, but must retain predicate and removal order; a persistent map's native retain order is insufficient. Its temporary removal list and persistent deletions are genuine cold costs.

**5. Two normative owners require a concrete, small implementation.** Exactly one directory value must correspond to every occupied complete allocator key at each observable NodeStore boundary. Raw Builder access can create malformed Node payloads, but must not create occupancy/value divergence. Insert/remove/replace and retain must preserve paired state, stale-key rejection, returned old Arc ownership, generation reuse and candidate-local allocation. Do not repair mismatches by silently skipping them during iteration.

The directory must support a practical `get_mut(&mut self, key) -> Option<&mut Arc<Node>>` path, or an equally concrete implementation preserving NodeStore's existing borrowed mutation interface. A library offering only functional insertion does not automatically satisfy this requirement. Replacement/removal must not deep-clone the payload being discarded. RootStructure sharing, branch isolation, actual staged prefixes and old outputs remain unchanged.

Count root sharing, allocator copying, persistent path copying, sibling value-handle clones and Node payload clones separately. A counter around `Node::clone` cannot observe Arc-handle clones inside a collection. Do not report zero total handle copying merely because NodeStore::clone no longer visits N nodes.

**6. Compatibility does not require two production directories.** NodeStore is private, and persistence enumerates graph nodes through its interface (`persistence.rs:403,555–556`). No existing serialized NodeStore representation requires retaining the old SlotMap-with-values alongside the new values directory. Doing so would duplicate ownership and risk retaining the old copying cost. Historical immutable builds suffice for comparison; a permanent backend feature matrix is not inherently necessary.

Any new dependency still needs Root's later review of license, locked/offline availability, MSRV, existing feature combinations, Send/Sync, mutation and destruction behavior. Collection-specific serde support is not automatically required by the current graph schema adapter. These are prerequisites for a concrete experiment, not a reason to select a package during this analysis.

**Falsifiable next step.** First obtain Root's complete retained results after the current queue. If directory work remains a plausible material cost, qualify one NodeStore-only persistent-values experiment against dense and churned/sparse states, center/Select and actual allocator writes, independently retained snapshots, two allocation branches and late staged failure. Preserve exact key/iteration order, old references and every fresh layout/export word. Include resize and all existing negative tails in the complete comparison. Reject a variant whose read/update/drop costs outweigh the saved copying; do not reject the entire architectural possibility solely from asymptotics or this unmeasured source review.
