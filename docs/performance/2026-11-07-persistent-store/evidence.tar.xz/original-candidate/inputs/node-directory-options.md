# Removing candidate-wide node-handle copying

Read-only source analysis, 2026-11-07. No candidate, dependency, repository/fork/cache change, Cargo, compilation, test, runner, timing, profile, network or child agent. The supplied approximately 0.8 us center / 1.7 us edge mutation costs are context, not measurements by this lane.

**Recommendation:** after the layout/metadata queue, a shared SlotMap allocator plus a mature persistent value directory is the more practical independent experiment. Keep the existing NodeStore Interface and sole executor. A local overlay is useful for evaluating isolation, but a plain delta does not solve indefinite independent publication without growing history or later whole-store work. Neither design establishes a twofold result.

## Current contracts and mechanism

The older B/transaction-design.md correctly deferred directory copying until after closure/local finalization. Its original deep-payload/proof/full-normalization costs are already superseded; do not reimplement those changes.

`graph/shared_storage.rs:12–23` currently clones `SlotMap<NodeId, Arc<Node>>`. SlotMap 1.1.1 actually clones its complete allocated-slot Vec, including vacant slots, and clones each occupied Arc (`basic.rs:80–90,967–975`). Thus work depends on occupied values and historical slots, not only currently reachable nodes. Payload/MRU sharing is already implemented. `get_mut` COWs only a changed Node; replace/remove avoid cloning discarded payloads (`shared_storage.rs:35–55`).

Preparation clones before the Select/Item/general distinction (`operation.rs:635`). The existing local Item path and exact frozen report remain (`:651–700`); general stages validate against each actual prefix and normalize only at finish (`:734–842`). Keep those semantics.

PreparedTransaction exposes an immutable complete Workspace and can relinquish it without publication (`operation.rs:31–64`). Actual consumers include preview projection (`drop_resolver.rs:930–948`), native preflight/barriers (`engine/native_tear_off.rs:497–526`), pointer publication checks (`engine/pointer_transaction.rs:3857–3888`), and recovery followed by another checked Select before further barriers (`engine/surface_runtime.rs:2725–2768`). Snapshots hold Arc<Workspace>; follow-ups can fork through Arc::make_mut (`operation.rs:70–107`). An exclusive undo borrow across all these consumers is insufficient.

## 1. Checked local overlay and before-images

A concrete version is a NodeStore-owned shared immutable base plus local replacements, tombstones and births. Ordinary reads consult the delta before base; first get_mut copies only that actual payload into the delta. Existing graph/operation/canonical writes remain the sole executor. Before-images can serve exact change reporting and local recovery, but are not authority and cannot replace current RootReferences.

This can still return an ordinary independent Workspace: NodeStore hides the representation, and all readers borrow through its existing methods. Do not expose a second PreparedOverlay type plus a generic WorkspaceRead trait to engine/layout. That would spread the Implementation across every consumer instead of deepening the current Module.

“Validate everything first” is limited. Source/target/policy checks already precede detach. Source collapse, post-detach weights, rewritten f32 sums and late geometry/host barriers still need their original ordering. Predicting their complete outcome in another planner duplicates the executor. Instead execute once against isolated overlay state, retain local before-images where needed, and drop the candidate on failure. Before-images alone do not grant isolation from the original.

Center/Select needs only replacements. Edge needs real generational births; source collapse/retirement needs deletions, parent/root/carrier updates and allocator changes. Reusing the existing SlotMap allocator means its first allocation/retirement still forks allocator metadata, or requires the allocator split in option 2. Global monotonic ID reservation, invented free slots, or mutating the original allocator during preparation would change discard/branch semantics.

The publication problem is the decisive cost:

- Flattening a delta into a fresh full SlotMap before returning/publishing costs O(allocated slots/live handles) in the measured operation.
- Returning an overlay which borrows the original cannot provide the existing owned future/snapshot lifetime.
- Owning a chain of parent overlays preserves independence, but lookup/drop depth grows with edits and retained branches.
- Keeping one flat base plus an ordinary copied delta bounds lookup depth, but fork copies the accumulated delta; a long edit history eventually touches the entire workspace.
- Opportunistic folding when the base becomes uniquely owned helps direct apply, but retained snapshots/previews can prevent it indefinitely. Qualification must retain snapshots throughout a long sequence.

A persistent delta solves that last growth but converges on option 2. Therefore this is a larger candidate-lifecycle project unless a bounded flatten policy and its honest cold costs are accepted. Direct apply could eventually consume an exclusive live Workspace with concrete undo; it would be a different ownership entry into the same executor, not an alternative mutation algorithm. It does not replace independent engine preparation and is not the first experiment.

## 2. Shared allocator and persistent node values

The concrete representation is one NodeStore with `Arc<SlotMap<NodeId, ()>>` and a persistent `NodeId -> Arc<Node>` map. Use a mature thread-safe persistent collection; add no provider abstraction. No collection was selected or API-qualified in this source-only lane; the current core dependency list supplies SlotMap rather than this directory. Selecting and reviewing license/MSRV, Send/Sync behavior, mutable-value access and drop characteristics is a prerequisite, not a claimed existing capability.

Clone shares both roots. Select/center modifies only a few persistent value paths and Node payloads; the allocator remains shared. Insert/remove COW the allocator before using the **existing safe SlotMap methods**, then update the directory. No generation is reconstructed from slot-index bits. All structural normalization still uses the current executor.

The two owners store different normative facts: allocator occupancy/generation/free-list versus actual immutable payloads. They are not a proof cache. NodeStore's private operations maintain exactly one value for each occupied complete key. There is no public unchecked constructor or new validator framework.

| Interface/caller | Required implementation or migration |
| --- | --- |
| get/get_mut/shared/replace/remove | Preserve complete-key rejection and existing borrowed/owned return types. get_mut must obtain a COW mutable map value before Arc::make_mut. RootStructure::build_rows still borrows the actual Arc through shared (`graph/root_structure.rs:140`). A collection requiring value extraction needs a small concrete update adaptation, not a new executor. |
| keys/iter/values | Drive traversal from allocator.keys(), joining directory values. Preserve deterministic **arena-slot order** documented by graph.rs:456,519; a HAMT's order or sorted full NodeIds is not a substitute. No sort/materialized key Vec per normal reader. |
| len/capacity/contains_key | Preserve live count and allocator capacity meaning. Capacity is used by canonical SecondaryMap reservations (`canonical.rs:462,895`); directory length is not maximum-slot capacity. Exact reserved bytes are not semantic identity. |
| Builder/raw/import | insert_node/replace_node/set_tab_mru/draft_mut retain actual malformed-data access through NodeStore (`graph.rs:625–647`). Keep replacement's old payload return. into_builder retains IDs; build/import still normalize and issue fresh authority. Persistence remains schema-compatible. |
| Canonical retain/validation | Preserve allocator-order predicate and retirement/free-list ordering (`canonical.rs:475`). Avoid unconditional allocator COW for an all-keep retain; collect actual removals, then remove in the same order. Preserve raw diagnostics and item iteration. This is cold work, not skipped validation. |
| Cloning/reporting/tests | Keep PreparedTransaction/Stage/Snapshot interfaces and report sealing. Update copy-work expectations to the actual storage operations; retain logical inventory columns. A persistent library may clone sibling value handles while copying paths: do not call total handle copying zero merely because candidate fork stopped visiting every node. |

The primary production change can stay in graph/shared_storage.rs plus dependency declarations; the existing graph/operation/canonical/validation/authority/root-structure/persistence readers use that small Interface. Tests/counters need explicit migration. No engine caller changes are inherently necessary. This is better Locality than a parallel read-view hierarchy.

**Remaining linear work:** first shared allocator insertion/removal still clones its slot Vec, although it no longer copies N payload Arcs. Edge/collapse/close/root creation can therefore remain O(historical slots). Persistent updates allocate/copy directory paths, add reference operations and make reads less direct. The formal leaf-input graph walk and complete export call Workspace::node repeatedly (`docking_cost.rs:197–256,277–324`), so slower reads can erase mutation gains. Old snapshots retain old map paths; last-owner destruction and general canonical retains can cost more. No allocator/time percentage is known.

A shared paged generational directory could remove the allocator's remaining whole-Vec fork, but SlotMap's slots/free-list are private. A flat Arc<Vec<Arc<Page>>> still forks the page directory; a persistent page directory adds path work. Implementing generation/free-list pages ourselves, decoding opaque key bits, or changing NodeId plus every SecondaryMap would exceed this bounded slice. Do not hide a custom allocator under “paging.” Evaluate a mature compatible implementation separately only if allocator COW is measured material.

## Identity, failure and lifetime requirements for both

SlotMap increment/reuse/free-head behavior is actual state (`basic.rs:396–445`). Discarding a prepared candidate must not consume the original's slots/generations. Two branches cloned from the same allocator may allocate equal numeric NodeIds; this already follows from independent SlotMap clones. Complete root issuance separates their commands. Never turn a numeric key into globally unique cross-branch authority or share one mutable allocator behind a lock.

Keep the current generation-wrap contract, stale generation rejection, exact per-command issuance, true no-op reference reuse, and strict value-ABA rejection. General staged prefixes may temporarily contain unrooted residue; membership remains the graph owner/placement owner's job, not allocator liveness. Cold normalization must still see every live allocated record. A later error discards node, root, carrier, placement and issuance changes together. Old RootStructures/output payload Arcs and old WorkspaceSnapshots remain independently readable; no success may modify them through an alias.

Existing witnesses: graph/copy_tests.rs:304 late failure, :339 generation reuse; operation/tests/owner_reference.rs:125 independent build/ABA, :518 recycled placement; actual-stage capture/batch, f32 frontier, recovery/close and complete layout/export suites. Add a bounded long sequence with retained snapshots and two allocation branches if implementing either route. Compare exact live iteration/key/order, reused IDs, old references and full outputs—not only counts.

## Next measurement decision

Finish current layout/metadata experiments first. Then implement option 2 as one separately qualified NodeStore slice and compare the unchanged complete kernel, not only fork. Use dense and churned/sparse arenas; Select/center versus edge/collapse; retained snapshots versus uniquely owned follow-ups; staged late failure and cold Builder/import. Keep full fresh measurement/export and every negative p50/p95/max cell. Separate diagnostic clone/path/allocation observations from formal clocks. Reject it if read/update/drop costs outweigh saved directory cloning. The supplied small mutation medians leave no evidence-based latency allowance for either design.

Source identities: shared_storage.rs `18c6f75150643779acb9c71c30486634b19f7ccec5677e4cc64ce9043fcc532e`; operation.rs `b18c0f29b0561af1bbed80600d72d94825d5fb5ac1708abf1af7fe864d15c0b5`; canonical.rs `dda19b95f3a8c29aca4e262b9b4239e1409ca8aceaf85ef2c3432c881aea79be`. SlotMap source is the locally installed 1.1.1, not external performance evidence.
