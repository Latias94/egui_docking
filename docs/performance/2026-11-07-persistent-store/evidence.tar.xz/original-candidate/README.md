# Persistent node values with candidate-local generational allocation

READY / source stationary / not qualified. This is a bounded source candidate
against immutable `a2365aa876c51a66a5c9c788bff9056afdbabacd`, with the retained
command ownership changes and no packed-output overlay. No live worktree input
or older candidate source was used.

Only this temporary directory was written. No repository, fork, cache, Git
state, lockfile or previous candidate was changed. No Cargo resolution,
compiler, formatter, Rust test, runner, timing, benchmark, profiler, network or
child agent was used. Root owns independent review, lock resolution, ordinary
qualification and the complete operation comparison.

## Scope and Interface

The patch changes six paths: two dependency manifests, NodeStore, the existing
test ledger, the existing work CSV adapter and one registered test file.
NodeStore is the only production algorithm change: +55/-14 lines.
Counting the ledger and probe conservatively as runtime paths gives three
paths and +68/-23 lines, below the requested four-path/150-added-line limit.
The complete patch is +256/-26, including +186/-3 in the existing test module
and two manifest additions.

NodeStore keeps all thirteen existing private method signatures. Graph,
canonicalization, transaction execution, membership/issuance, RootStructure,
Builder/import, layout, persistence and engine callers require no migration.
Seventeen complete immutable base/tree source pairs bind those boundaries;
eleven pairs, including the command executor and layout, are byte-identical.
There is no second directory backend, executor, reader trait, proof, trust flag,
custom allocator, hand-decoded key or project unsafe code.

The Implementation now owns exactly:

```rust
slots: Arc<SlotMap<NodeId, ()>>,
nodes: HashTrieMapSync<NodeId, Arc<Node>>,
```

SlotMap remains the sole allocator for opaque complete generational NodeIds.
The one persistent map owns the canonical Node values; allocator entries carry
only unit values. Existing Node Arcs and graph-owned RootStructure split
payloads remain durable. Directory membership is normative state maintained by
this closed Module, not an independently rebuilt cache.

## Read, mutation and retirement behavior

`get/shared` perform one full-key directory lookup without a redundant allocator
check. `get_mut` uses rpds `get_mut` and then the existing `Arc::make_mut`; that
copies only the selected shared Node payload when necessary. Replacement
exchanges that Arc slot and preserves the old owned return without copying its
discarded Node vectors. The library may COW paths even for a missing mutation.

Birth and retirement first COW the allocator on an actual structural change.
They preserve SlotMap's generation, free-list, branch-local allocation,
capacity and historical-hole behavior. Independent candidate branches can
produce the same numeric key, as independent SlotMap clones already can.
Their persistent maps and existing exact RootReferences remain independent.
No global shared mutable allocator or cross-branch authority exemption exists.

rpds removal returns a boolean rather than its value. A successful NodeStore
remove therefore borrows and clones exactly the returned old Arc handle before
deleting its entry. It does not clone Node vectors. Retain does not need an old
owned return, so its deletion path avoids that additional handle clone.

`keys` uses allocator slot order. `iter/values` join those same keys to values
without a fresh key vector, sorting or native HAMT iteration. Occupied keys
missing their value explicitly fail an owner invariant instead of disappearing
through `filter_map`. Missing/stale public keys still return None normally.

Retain calls its predicate once per live slot in allocator order, collecting
actual removals, then deletes them in that same order. This preserves free-head
and subsequent key allocation. The all-keep path returns before any allocator
or directory mutation. Its ordered removal Vec and repeated persistent deletes
are real cold costs. Typed graph validation, raw diagnostics and their order
are unchanged; no new full-store validation is added to the success path.

## Dependency and resolution boundary

The workspace declares exactly `rpds = "=1.2.1"`; core uses that workspace
dependency with default features. `HashTrieMapSync` explicitly selects the
thread-safe upstream pointer kind, and the default std hasher is retained.
The plain Rc-based alias is not used. An existing workspace-fork test now
also requires `Workspace: Send + Sync` at compilation.

The package archive copied under inputs has SHA-256
`e025feb26210bc196b908e72deb063b1b4000754304341cbc168a1e72c857ebc`,
matching the prior research receipt. The published manifest declares MIT and
Rust 1.85.0; the immutable workspace declares Rust 1.95. Relevant published
API source is copied for independent inspection. Upstream dependency internals
contain unsafe code; no project unsafe does not mean an unsafe-free closure.

No lockfile is fabricated. `dependency-boundary.json` binds the five applicable
build locks at the parent and leaves their real Cargo resolution to Root.
Two archived historical evidence locks stay untouched. The earlier research's
transitive versions are observations, not this candidate's resolved closure.
Until Root resolves and compiles, this package is source-ready only.

## Counter contract and semantic coverage

`work-counters.md` lists every affected field, call site and expectation.
The former N live payload-handle fork count is replaced by
`node_store_owner_clones`: exactly two root-pointer clones per NodeStore fork,
one allocator Arc and one rpds directory root. This is not a claim that rpds
performs zero internal handle, Entry, path or payload-Arc copies during edits.
Logical Workspace inventory and concrete Node payload/vector copy counters
retain their original definitions. Only the ordinary work CSV column changes;
formal timing schema, measure, inputs, export and validation remain unchanged.

Two new registered semantic tests use the existing graph test module:

1. Two independent real checked edge preparations allocate equal numeric IDs
   with different payloads and reject each other's issued reference. A retained
   WorkspaceSnapshot stays unchanged. A later duplicate-open failure after
   allocating an edge candidate preserves the original and retry identities.
2. Dense and sparse histories compare node iteration, retain predicate order,
   stale complete-key rejection and each subsequent allocated key against
   SlotMap's independent allocator behavior across three churn rounds. An old
   retained store keeps its earlier values.

Existing payload/Builder return, unique follow-up, canonical no-op, branch
recycling, late batch failure, placement, staged authority, raw diagnostics,
complete numeric/oracle output, old-output Clone and deep-tree coverage remain.
No storage-layout-only assertion or transition simulator was added. The
Send/Sync and two fork-counter changes are bounded adaptations of existing
tests, not additional framework.

## Costs and retention risks

NodeStore clone no longer traverses N payload handles; this is a source fact,
not a whole-operation O(1) or speedup claim. Root authority and other Workspace
metadata still clone independently. Structural insertion/removal still COWs
the allocator's initialized slot vector, including holes, generations and
free-list links. Historical slot extent and reserved capacity remain distinct.

rpds adds hashing and navigation to each ordinary read. Fresh leaf gathering
and complete normalized export still perform their original reads inside the
timer. Resize has no candidate fork saving and is an important negative control.
Existing RootStructure split reads still borrow their actual durable payloads.

Persistent edits can allocate/copy path vectors and shared Entry owners, clone
sibling internal pointers, clone the selected payload Arc, and incur reference
count traffic. Small roots may replace one short contiguous copy with more
indirection and allocations. Retained snapshots prolong paths; final destruction
and the old Workspace's release during publication remain real costs.

Default construction now creates an allocator Arc and a persistent root owner,
in addition to the allocator's own empty state and default hasher. Empty
Workspace placeholders and small/empty workloads can regress. No dependency,
allocation-byte, total pointer-copy or latency saving is claimed.

Root should qualify the ordinary semantic suite, resolve all five lockfiles,
and compare the complete unchanged kernel matrix, raw values and tails.
Measure allocator-writing edge/collapse as well as center/Select and resize,
and keep sparse history/retained snapshots meaningful. Reject the candidate
if read/update/drop/default costs outweigh its eliminated fork traversal.

`manifest.json`, `source-pairs.md`, `scope-checks.json` and READY bind exact
source and artifact hashes using UTF-8 relative-path-string ordering.
`review-request.md` identifies the bounded independent review questions.
