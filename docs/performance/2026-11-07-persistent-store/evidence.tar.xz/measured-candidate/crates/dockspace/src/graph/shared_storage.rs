//! Shared canonical payloads behind the graph owner's existing value access.

use std::sync::Arc;

use rpds::HashTrieMapSync;
use slotmap::SlotMap;

use super::Node;
use crate::ids::NodeId;

/// Complete generational keys join an allocator and one persistent value directory.
#[derive(Debug, Default)]
pub(crate) struct NodeStore {
    slots: Arc<SlotMap<NodeId, ()>>,
    nodes: HashTrieMapSync<NodeId, Arc<Node>>,
}

impl Clone for NodeStore {
    fn clone(&self) -> Self {
        #[cfg(test)]
        crate::drop_resolver::structural_work::record_node_store_clone();
        Self {
            slots: Arc::clone(&self.slots),
            nodes: self.nodes.clone(),
        }
    }
}

impl NodeStore {
    pub(crate) fn shared(&self, node: NodeId) -> Option<&Arc<Node>> {
        self.nodes.get(&node)
    }

    pub(crate) fn get(&self, node: NodeId) -> Option<&Node> {
        self.nodes.get(&node).map(Arc::as_ref)
    }

    pub(crate) fn get_mut(&mut self, node: NodeId) -> Option<&mut Node> {
        self.nodes.get_mut(&node).map(Arc::make_mut)
    }

    pub(crate) fn insert(&mut self, node: Node) -> NodeId {
        let id = Arc::make_mut(&mut self.slots).insert(());
        self.nodes.insert_mut(id, Arc::new(node));
        id
    }

    /// Replacing a whole record must not copy the payload being discarded.
    pub(crate) fn replace(&mut self, id: NodeId, node: Node) -> Option<Arc<Node>> {
        let slot = self.nodes.get_mut(&id)?;
        Some(std::mem::replace(slot, Arc::new(node)))
    }

    /// The returned payload needs one handle clone before its directory entry is retired.
    pub(crate) fn remove(&mut self, node: NodeId) -> Option<Arc<Node>> {
        if !self.slots.contains_key(node) {
            return None;
        }
        let previous = Arc::clone(
            self.nodes
                .get(&node)
                .expect("occupied node slot must have a directory value"),
        );
        Arc::make_mut(&mut self.slots)
            .remove(node)
            .expect("occupied node slot must be removable");
        assert!(
            self.nodes.remove_mut(&node),
            "occupied node slot must have a directory value"
        );
        Some(previous)
    }

    pub(crate) fn retain(&mut self, mut keep: impl FnMut(NodeId, &Node) -> bool) {
        let removed: Vec<_> = self
            .iter()
            .filter_map(|(id, node)| (!keep(id, node)).then_some(id))
            .collect();
        if removed.is_empty() {
            return;
        }
        let slots = Arc::make_mut(&mut self.slots);
        for id in removed {
            slots
                .remove(id)
                .expect("retained node slot must be occupied");
            assert!(
                self.nodes.remove_mut(&id),
                "occupied node slot must have a directory value"
            );
        }
    }

    pub(crate) fn iter(&self) -> impl Iterator<Item = (NodeId, &Node)> {
        self.slots.keys().map(move |id| {
            let node = self
                .get(id)
                .expect("occupied node slot must have a directory value");
            (id, node)
        })
    }

    pub(crate) fn values(&self) -> impl Iterator<Item = &Node> {
        self.iter().map(|(_, node)| node)
    }

    pub(crate) fn keys(&self) -> impl Iterator<Item = NodeId> + '_ {
        self.slots.keys()
    }

    pub(crate) fn len(&self) -> usize {
        self.slots.len()
    }

    pub(crate) fn capacity(&self) -> usize {
        self.slots.capacity()
    }

    pub(crate) fn contains_key(&self, node: NodeId) -> bool {
        self.slots.contains_key(node)
    }
}
