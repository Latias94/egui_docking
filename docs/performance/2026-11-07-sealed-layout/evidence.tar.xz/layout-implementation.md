# Dense complete layout projection implementation

Status: READY FOR ROOT VERIFICATION. This lane has finished its source edits and local formatting. No build, test or timing result is claimed for this implementation.

## Ownership and changed paths

Exclusive scope was recorded in `lanes.md` before the first repository write. Repository writes began only after root confirmed that the independent arena-control timing binary had been frozen.

Changed files:

- `crates/dockspace/src/layout.rs`
- `crates/dockspace/src/layout/projection.rs` (new file; currently untracked)
- `crates/dockspace/src/layout/topology.rs`
- `crates/dockspace/src/layout/reference.rs`
- `crates/dockspace/src/layout/topology_tests.rs`
- `crates/dockspace/src/layout/override_tests.rs`
- `crates/dockspace/src/scene_compiler/surface.rs`
- `crates/dockspace/src/drop_resolver/preview.rs`
- `crates/dockspace/src/engine/splitter_geometry.rs`
- `crates/dockspace/src/engine/splitter_geometry/tests.rs` (announced read-interface migration)
- `crates/dockspace/tests/layout_solver.rs` (announced read-interface migration)

The assigned `docking_cost.rs`, `scene_compiler/future_layout.rs` and `scene/records/layout.rs` did not require changes: their existing result reads are supported by the new container Interface. No fixture, timer, operation scope, export work, reference repository, dependency, or unowned core file was changed by this lane.

## Implementation and Interface

`LayoutProjection` now owns two `NodeMap<T>` values and one `SplitMap`, instead of three output BTreeMaps. Each owner shares one immutable `Arc<RootLayoutTopology>`. The root-local directory stores dense rows and an identity-sorted row list. Lookup binary-searches the complete generational `NodeId`; it never indexes an arena slot into a per-root allocation. Node values remain contiguous in traversal row order. Iteration uses ascending `NodeId::Ord`, preserving the previous BTreeMap order.

`NodeMap<T>` retains `get(&NodeId)`, `contains_key`, `len`, `is_empty`, `keys`, `values`, `iter`, `Index<&NodeId>` and borrowed `IntoIterator`. It offers no mutable collection Interface. Equality compares logical ordered keys and values, not topology pointer identity or allocation capacity.

`SplitMap` owns flat arrays for all child minima, child maxima, solved child extents and splitter rectangles. Split metadata holds the central-child index and residuals; each topology split row holds its direct-child range, gap range and split ordinal. Lookup/iteration returns a cheap `Copy` `SplitProjection<'a>` containing slices plus scalar outcomes. `splits[&id]` becomes `splits.get(&id).unwrap()` at known-present call sites. Callers that deliberately freeze resize results into owned command state use `to_vec()` for that ownership transfer.

Example:

```rust
let bounds = projection.node_rects.get(&node);
if let Some(split) = projection.splits.get(&split_node) {
    let extents: &[f64] = split.child_extents;
    let frozen_for_resize = extents.to_vec();
    // Frozen command state owns its copy; normal scene reads borrow the arrays.
}
for (node, split) in &projection.splits {
    inspect(node, split.child_minimum_extents, split.splitter_rects);
}
```

The iterative projection stack now stores only indices/ranges, cursor/bounds and continuation state. It no longer retains per-split vectors. Solved extents write directly into the projection's final flat child range. Constraint, durable-weight conversion and redistribution eligibility scratch buffers are reused across splits. The public standalone `solve_axis` keeps its owned `AxisLayout` return value while using the same caller-owned numerical implementation internally.

No cached answer or geometry substitutes for complete work. Cold standalone calls compile and measure from the current workspace and explicit constraints. Warm engine calls still validate the structural topology hint and remeasure the current metrics/minima. A new complete projection owns new numeric arrays; only immutable topology is shared. Outputs neither borrow live workspace storage nor mutate old output storage.

## Preserved semantic boundaries

- Compilation and leaf measurement remain interleaved depth-first; a late cycle does not outrank an earlier missing leaf answer.
- Public projection still checks root and override authority before measurement. Scene-minimum projection still measures before validating overrides.
- Completed DAG subtrees remain permitted by the raw diagnostic path. Projection still enters each edge occurrence and overwrites that node's final row on later visits, preserving the former map's last-write behavior. It does not project only unique rows once.
- The projection and measurement traversals remain iterative. Output ownership is flat and nonrecursive.
- Axis validation order, sum order, central behavior, saturation, floating-point residue distribution, splitter compression and geometry construction order were preserved. No f32 conversion, epsilon change, binary-only special case or removed constraint result was introduced.
- All node rectangles, composed constraints and complete split min/max/extents/gaps/residuals remain present.

## Workspace closure migration

The concurrent Workspace owner now supplies `Workspace::storage()` as shared Data, `Workspace::into_builder()` for editing, and test-only `WorkspaceBuilder::draft` / `draft_mut`.

Production topology compilation accepts read-only `WorkspaceData` obtained from the sealed workspace. Ordinary valid tests use Builder replacement/build to retain IDs. Deliberately invalid DAG/cycle/missing-node tests use one `cfg(test)` layout-private `project_draft` Adapter. That Adapter compiles raw Builder Data and invokes the same `project_measurements`/projection Implementation; it never manufactures an invalid sealed Workspace. The frozen reference has its own raw-draft adapter.

The former same-version hint test's missing-node branch was moved to a raw-draft diagnostic regression, since an invalid committed Workspace is no longer constructible. Its legal axis/weights/central/child-order edits still verify hint misses and original-hint retention after a checked Builder build.

## Oracle independence

Before replacing the production containers or solver, the old complete output types and old numerical solver/helpers were frozen into `layout/reference.rs`. Reference traversal owns BTreeMaps and per-split vectors. It computes its answers with its own old `solve_axis`, `desired_sizes`, grow/shrink/redistribution and numeric helpers.

Production results are captured into those independent old owned value types for comparison. Reference answers never pass through NodeMap, SplitMap, the dense projection writer or the new solver. The existing full-tree differential property and scenario tests now compare these complete values.

The frozen solver and helper source were compared with the saved pre-edit `/tmp/layout-before/layout.rs` segments after whitespace normalization. Both matched exactly. Raw Data access and validation binding are adapters around the frozen traversal; common geometry validation and composition helpers were not modified by this lane.

## Added or maintained regressions

New tests:

- `caller_owned_axis_matches_frozen_solver`: randomized finite bounded inputs, zero weights, empty axes, optional central child, minima/maxima and exact bit comparisons for sizes and residuals against the frozen solver.
- `dense_projection_keeps_identity_order_and_owned_old_outputs`: deterministic key/reverse iteration, complete split ordering, changed bounds/metrics with two outputs alive, and output use after dropping workspace/index.
- `sparse_arena_projection_rejects_retired_generations`: hundreds of retired arena slots, a recycled live node, one-root result membership, rejection of every retired generation and output use after workspace destruction.
- `raw_missing_node_keeps_depth_first_measurement_error_priority`: earlier missing leaf answer versus later missing node, compared with the independent traversal.

Maintained/migrated coverage includes full cold/warm oracle comparison, current metrics/answers, same-version topology invalidation, frozen override authority and error priority, malformed DAG/cycle order, full direct-child constraints, compressed splitters, exact residual behavior and the existing ten-thousand-level iterative test. No expected numeric values were changed in integration/splitter tests.

## Verification and remaining risk

Performed only permitted local checks:

- Direct `rustfmt --edition 2024 --config skip_children=true` on each changed Rust file; successful parse/format.
- `git diff --check` limited to this lane's paths; no whitespace errors.
- Source audits for all `LayoutProjection` / `SplitProjection` constructors, split indexing, map-typed consumers, direct Workspace field writes and frozen solver/helper identity.

Not run: Cargo, Rust/C++ compilation, tests, benchmarks, timing or Git writes. The earlier 2024 passing core tests belong to the conservative arena-control slice, not this layout implementation.

Root should first compile with the concurrent Workspace ownership slice, then run the layout module tests, `layout_solver`, and engine splitter/surface reuse coverage before the full serial core qualification. Explicitly include the existing DAG/error-order and ten-thousand-depth cases. The new generic iterator lifetimes and cross-field mutable borrows have only been syntax-checked by rustfmt; root compilation is the next required gate.

Performance claims await the unchanged frozen workload. This removes output BTreeMap insertion and per-split result allocations, but cold topology compilation still owns one root-local HashMap and performs identity sorting once. Warm matching and current measurement still traverse reachable structure. Root-local storage is proportional to reachable nodes/edges/gaps, not the highest arena slot. These are source-level cost predictions, not measured conclusions, and this lane does not claim the twofold target has been reached.

## Ready source hash

SHA-256 of the sorted sequence `UTF-8 relative path`, NUL, then file bytes for the eleven changed files listed below:

`fda937c7676d3ee3c2391eeaa3ef3b6fe5622c2763c289411c1f22b7e9a74bf6`

- `crates/dockspace/src/drop_resolver/preview.rs`: `103826cd4cbfbb00f8b210ec7c6f9d9523114dab6ff428efaf3049d7aeeb9905`
- `crates/dockspace/src/engine/splitter_geometry.rs`: `bdb69158fa29c8ba2621081264973a45cea4c2d2370d41813eb79aa28f90d9de`
- `crates/dockspace/src/engine/splitter_geometry/tests.rs`: `baff61a23542ec9c3453d6b1df886c039277d9bef279740319e9810c187267a8`
- `crates/dockspace/src/layout.rs`: `ec44b2ddd4ac9bc529222de44950f1cc6c1e2cd894d357e7c6593c23ba95bca9`
- `crates/dockspace/src/layout/override_tests.rs`: `021ef5012a4ff7bae53c57407c22ec18f58beaaa333e98e6b833500f8d6e0676`
- `crates/dockspace/src/layout/projection.rs`: `c31bfdad6ec84a8714f1d93fa93f97fdb96cb96226349263018da09c62dd742e`
- `crates/dockspace/src/layout/reference.rs`: `93afdf6e8ad79d81f2efdafc4814a4bb6076fd9f535129f82ce33f9ee12ddf4e`
- `crates/dockspace/src/layout/topology.rs`: `6776c07f2ea7172aa3a41d95e2f6ecd93bc4efcac0fc18a4d5f1144a21dd49c4`
- `crates/dockspace/src/layout/topology_tests.rs`: `0b7293be7358ad66ccb268aaec619e290541d595ce4bd7111c3b82ec672f6c94`
- `crates/dockspace/src/scene_compiler/surface.rs`: `f1b18633f701241a2bd476abe91aee60c01362861ca7e0ce4bede9ec4f82539c`
- `crates/dockspace/tests/layout_solver.rs`: `b64d99a54be54f719531b2bfb0962fb322764ee0a28cd87dd690f520fbc611d0`

## Test registration correction: active ten-thousand-depth regression

Root confirmed `crates/dockspace/Cargo.toml` has `autotests = false` and does not explicitly register `tests/layout_solver.rs`. The earlier statement that the existing ten-thousand-depth regression was maintained referred only to source maintenance; it was not active ordinary-core coverage. The reported 2032 passing core tests did not execute that legacy test. Other unregistered legacy assertions likewise must not be counted as executed evidence.

Under the follow-up authorization, only `layout/topology_tests.rs` was edited. The existing alternating 10,000-split fixture was compactly migrated into its real `cfg(test)` module as `layout::topology_tests::projects_ten_thousand_nested_splits_without_call_stack_growth`. The test projects a checked Builder-built workspace with 10,001 leaves and asserts all 20,001 node rectangles, all 20,001 composed constraints, all 10,000 split outcomes and every split's complete child/gap slice cardinalities. It drops the workspace and leaf answers before reading the owned projection and explicitly drops the complete output at the end. It adds no production cfg or public module exposure.

Status: READY for root verification; source edits stopped. Direct rustfmt and limited diff whitespace check succeeded. No Cargo, compilation or tests were run by this lane.

Updated topology_tests.rs SHA-256: `1cbe351a68ff1554b987cee35a40826281e50ce406435ec1cb4ad117b0bd908d`.
