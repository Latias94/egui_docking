# Core-owner and local Item Move review

Status: COMPLETE — BLOCKED by one correctness finding with two distinct reachable witnesses. Read-only source review; no Cargo, compilation, repository tests, benchmarks or timing run by this reviewer. Root-reported 2032 passing ordinary core tests do not cover the numeric witnesses below.

## Blocking finding: local inner-edge insertion can publish an invalid weight sum

Severity: P1; blocks the sealed Workspace invariant and equivalence with the full route.

Locations: `operation.rs:631–650`, `operation.rs:3247–3255`, `canonical.rs:222–268`; existing acceptance rule in `canonical.rs:613–625` and `validation.rs:718–720`.

A public Builder can seal a canonical split with weights `f32::from_bits(0x3c75c28f)` and `f32::from_bits(0x3f7c284e)`: their f64 sum is `0.9999900003895164`, within the existing `1e-5` tolerance. No topology normalization rewrites that already canonical split, so these exact bits are preserved.

Move an Item from a populated source leaf in another root to the first target leaf's same-axis InnerEdge with `DockFraction::new(0.3)`. The real roster writer computes `branch * fraction` as `0x3b9374bd` and `branch - payload` as `0x3c2c0830`. The new three weights sum to `0.9999899999238551`; the deficit exceeds `1e-5`. Every individual f32 weight remains positive.

The single-Item local completion sees neither an empty source nor an outer wrapper and returns success without checking this changed split. `PreparedTransaction::publish` can therefore publish a Workspace rejected by the complete strict validator. The general route instead rejects during its ordinary input weight validation before canonical normalization, leaving the original workspace unchanged.

The numeric witness was calculated from exact f32 bit conversions in a short untimed scalar script; no Rust execution or test was performed. The branch setup is reachable via the public `Node::Split` variant and checked `SplitWeight::new`, followed by Builder build.

Required regression: construct this valid two-weight target in a checked Builder, retain a populated source, execute the real same-axis inner-edge move through both local and general preparation, assert equal rejection and full workspace rollback, and keep a strict validation assertion for any successful candidate. Preserve the existing tolerance and diagnostics; do not enlarge epsilon or silently renormalize a case the full route rejects. Check only the actual modified split frontier, avoiding an unrelated global pass.

### The same blocker also affects source-path normalization output

Checking only the direct edge-insertion roster is insufficient. `rewrite_split` calls `SplitWeight::normalize`, whose final f32 prefix compensation is not guaranteed to keep the f64 total within the existing strict tolerance for a wide legal split. The full path has a strict output validator; the local path currently has none.

A separate reachable witness: create a canonical flat horizontal split with 2000 singleton tabs children. Give the first 1999 children `SplitWeight::new(f32::from_bits(0x3a03126f))` and the final child `SplitWeight::new(f32::from_bits(0x3a030f3f))`. Their f64 sum is exactly `1.0`, so checked Builder build preserves and accepts it. Move the first leaf's sole item to a populated tabs leaf in another root using Center. Input weights are still legal after the item removal; local source repair removes that empty child and invokes the existing normalizer for the remaining 1999 entries.

The normalizer produces 1998 entries with bits `0x3a032338` and one final entry `0x39fdb800`. Their f64 total is `0.9999837139621377`, violating the unchanged `1e-5` bound. The general route rejects with `CanonicalizationError::InvalidOutput` containing `SplitWeightsNotNormalized`; local completion publishes it. The same exact-f32 scalar derivation was checked outside any repository build/test/timer.

The required fix must cover both the edited roster before rewriting (full input rule) and every actual split rewritten by the local frontier (full output rule). Preserve the complete diagnostic semantics where required; merely applying `normalize` again is not a proof that its f32 output meets the validator's aggregate bound. A regression for this second shape is needed in addition to the small inner-edge case.

## Other reviewed boundaries

### Sealed graph ownership

`graph.rs:387–418` makes committed storage private and exposes only shared Data. Construction audit found valid empty/default, clone, consuming Builder build through `canonical::build_workspace`, and graph-child operation completion as the actual Workspace sources. Builder raw mutability cannot construct a committed Workspace. There is no `DerefMut`, mutable committed storage escape, or production unchecked constructor. Persistence still strictly validates raw Builder input before build and before application item-registry queries. The module move gives mutation authority to operation/canonical without exposing it crate-wide.

This is a substantive Module/Interface ownership change rather than an eligibility flag. However, that closure makes the local completion bug more serious: all consumers now rely on successful graph-owner completion being sufficient to preserve the complete invariant.

### Single Select

`operation.rs:594–606` authorizes the same command then calls the existing source-verifying `select` implementation. That implementation updates selected and promotes the same item in the exact selected-first MRU; no topology, item membership, owner or weights change. Errors discard the private candidate. Selection remains permitted under arrangement lock, matching the general route's policy semantics.

The success property now explicitly compares with `prepare_general_candidate`; it no longer compares a wrapper with itself. The rejection fixture still compares two calls which delegate to the same preserving route (`local_selection.rs:107–110`), so that equality alone is no longer an independent diagnostic oracle. Both calls use `unwrap_err`, which still locks rejection; stale/missing/foreign and same-root source/target diagnostic behavior also has direct existing checked-move coverage. This does not add another blocker, but if editing this small test, use the actual general helper for its expected result as already done by the success property.

### Empty-source and outer-wrapper structure

Apart from numeric postconditions, source inspection found the local topology frontier coherent:

- Source removal changes the exact MRU and selects its next MRU member before structural repair. A protected central source may remain empty and is preserved.
- The ancestor path is located after insertion, so a newly installed same-root outer wrapper and a new inner wrapper are part of the actual path. There is no stale parent index or cached branch weight carried across detach.
- Bottom-up rewrite removes the emptied source, collapsed parents and actually flattened split containers. A collapsed same-axis child remains when its parent collapses, while flattened containers are retired when the parent survives. The root is updated to the final replacement.
- Inner targets are tabs-only; an inner wrapper's axis differs from its existing parent, so a populated-source inner insert needs no other topology cleanup. An outer target is the complete root and its same-axis wrapper is explicitly normalized even when the source stays populated.
- Distinct source/target roots are repaired in stable root order. A source surface can become vacant only when the original source is an unprotected singleton root, which is the scope captured before execution. Main/contained retirement updates the actual owner's backlinks, then prunes only that now-vacant surface.
- Same-tabs center and noncentral singleton self-edge no-ops retain their prior behavior; same-tabs gaps reorder. The final single-Move outcome flag is recomputed from actual complete Workspace equality, and PreparedTransaction's report uses the same candidate equality.

The new deterministic matrix compares the real local and full routes, preserves all fields through Workspace/report equality and independently validates successful candidates. It covers central source/other/no central, both axes, same/cross root, selected/unselected payloads, all edge directions and no-op shapes. It does not cover near-tolerance accepted input weights or large split fanout, which is why it does not catch the blocker.

### Atomicity, general batches and recovery

Public transactions clone once and publish only after preparation succeeds. A failing local repair therefore leaves the original Workspace and its old IDs untouched. Close, recovery, empty programs, mixed programs, multi-command programs and non-Item moves choose `prepare_general_candidate` before any command execution; the complete input/canonical/output checks and item ledger remain at `operation.rs:664–691`.

Recovery policy bypass is still restricted to an exact private recovery program plus its matching frozen roster; it cannot enter the single-Item local route. Move authorization still checks arrangement lock, fresh source and independently current target fingerprints, semantic scope, and actual live drop/tab policy before mutation. Target authority is not inferred from a current same-root source proof.

The owned follow-up method temporarily leaves a valid empty Workspace on failure (`operation.rs:702–712`). Its two production callers were checked: journal staging (`engine.rs:3500–3511`) and roster recovery selection (`engine/surface_runtime.rs:2742–2751`) return immediately and discard the whole local candidate on every error branch. Neither can publish the empty placeholder. Successful follow-ups still perform full canonicalization and reconciliation. No additional native lifecycle or rollback regression was found in these call sites.

### Same-version and raw-invalid fixture migrations

Native stale-roster, semantic snapshot, source Arc replacement and manifest/index tests now perform checked Select/Builder edits while deliberately retaining the engine/index version. They still change the actual selected/MRU, identity or topology evidence and exercise pointer/fingerprint fallback, rather than merely advancing a revision to make the test trivially stale. Builder build does not mint replacement IDs for already-canonical legal edits. The recycled-node fixture explicitly rewires a real new generation through Builder.

Replacing a malformed runtime Workspace fixture with Builder rejection is appropriate for the stronger sealed Interface. The host-frame test still stages a successful Select, drops the unpublished frame and asserts original Workspace/version/focus, then checks a stale Select after real publication. It no longer tests runtime rejection of an impossible malformed replacement, but that is not a production input under the new API. Existing failure-append/publication/native barriers remain necessary broader coverage; no source changes to those barriers were found in this slice.

## Required resolution and verification

Do not freeze this implementation as correctness-qualified until both numeric witnesses are captured as real Rust behavior tests and fixed at the actual changed split frontier. Keep input weight acceptance/rejection, final strict aggregate invariants, rollback, and the general route's diagnostic surface. A numeric revision, unconditional `normalize`, larger epsilon, or restoring a global pass to every common center move is not required to fix the actual issue.

After the bounded fix, run the two new local/full tests and the existing local Item Move, arrangement lock, checked move, Select, general batch, rollback and layout/output acceptance suites through root's serial verification. This reviewer has not executed those suites. No further source-level blocker was found within the reviewed scope; that statement is limited to this inspected implementation and is not a performance or runtime-test claim.

## Reviewed source hashes

Hashes below capture the inspected files before the requested numeric fix. Root formatting may have changed presentation but the reviewed runtime branches are the current source.

- `crates/dockspace/src/graph.rs`: `cbe27a19fa3c9612f33b87f702ec56acd3aad40d03e3c7f1fb0ca872468de166`
- `crates/dockspace/src/operation.rs`: `9dde88947b107c4e4cc6943aada137ce8463aebf02836164ddc9a33994eb1396`
- `crates/dockspace/src/canonical.rs`: `381c1ff4921831a279abfeff3cd982cdf632496461b671f9b8111eef5a1d3f3d`
- `crates/dockspace/src/transaction.rs`: `2a8d8f07cb0ce6d7a6a1c5ac661e6b5ced58b2296de026c129fcd5b98611a67d`
- `crates/dockspace/src/validation.rs`: `ff1b1718f88f7ea80468dd9201d07b557b85ea05f31953b9903976cb42f410ff`
- `crates/dockspace/src/operation/tests/local_item_move.rs`: `092a67db1ae032ed79145dac56374fa0f936db0dbbf8b0fd4243a2a57cbb917c`
