# Sealed Workspace and local Item Move: implementation handoff

Date: 2026-11-07. The implementation started from the handed-off SecondaryMap changes, now independently committed by root as `dbac00f`. This lane has not run Cargo, any tests, benchmarks/timing, a global formatter, Git writes, or child agents. Local rustfmt with `skip_children=true` parsed and formatted the owned files. Root owns compilation, semantic verification and measurements.

**Source is stationary for root's first `cargo check --tests --all-features`.** This is a compile-integration handoff, not a claim that verification has passed. No repository edits will be made by this lane while root compiles.

## Implemented scope

- `Workspace` now owns private `storage: WorkspaceData`. Only graph and its child Implementations can mutate that committed storage. Crate queries receive only `&WorkspaceData` through `storage()`.
- `WorkspaceBuilder` owns raw Data, and `into_builder()` consumes a Workspace while retaining runtime NodeIds. Builder has test-only `draft`/`draft_mut` access for diagnostics. Raw Data cannot construct a runtime Workspace outside graph's Implementation.
- `operation` and `canonical` are graph child modules loaded from their existing source files, with crate aliases retaining existing caller paths. No `DerefMut`, unchecked committed constructor, mutable committed map accessor, validity/dirty bit, or numeric trust cache was added.
- Snapshot is an immutable Arc carrier. Removed `selection_ready`, its mutable raw escape and the redundant `CanonicalWorkspace` wrapper. The single Select preserving route is now in the same prepare owner used for ordinary Workspace transactions, retaining zero multiset/global-finalization work. Snapshot delegates to it.
- Ordinary exactly-one `Move(Item)` uses the existing checked executor, then local source/target structural completion. It retains one whole candidate clone and current fresh proof reconstruction. Every other program, including mixed batches, tab/subtree moves and recovery, selects the complete existing general candidate route before execution. There is no partly executed local/fallback restart.
- A normal populated-source center/cross-root move performs no normalization traversal. Last-item removal repairs the current emptied leaf's path bottom-up, explicitly deletes emptied/collapsed/flattened records, preserves central identity, and prunes only a vacated source presentation. An outer edge also repairs a same-axis root wrapper even when the source remains populated. Weight rewriting reuses the existing normalizer's exact computation.
- Independent source/target-root normalization preserves ascending root error order. A failed local finalization discards its private candidate. An owned follow-up takes its discardable Workspace out of the caller before editing; failure leaves only a valid empty value observable, and callers already discard that failed candidate.
- Full raw normalization/strict validation remain for Builder, import, fallback, close/recovery and diagnostics. Consuming Builder build normalizes its owned Data without an unnecessary atomic-wrapper clone; mutable Builder canonicalization still clones and preserves its draft on failure. Persistence callers need no production change and keep strict restore ordering.

## Changed owned files

Core: `graph.rs`, `operation.rs`, `transaction.rs`, `canonical.rs`, `validation.rs`, `workspace.rs`, `lib.rs`, and `operation/tests/{local_selection.rs,split_resize.rs,local_item_move.rs}`. The new local-item test file is untracked until root stages it.

Caller/ledger migration: `engine.rs`, `engine/pointer_transaction.rs`, `engine/pointer_timed.rs`, `drop_resolver.rs`, `engine/presentation_authority/snapshot_tests.rs`, `engine/tests/native_lifecycle.rs`, `engine/contained_projection/{authority_tests.rs,measurement_tests.rs}`, and the relevant `scene_manifest.rs` test. Valid same-version tests now issue checked edits while deliberately retaining the engine/index version. Raw corruption tests use Builder.

No layout worker file was edited. Its current Data/Builder diagnostics changes were observed in the shared worktree. This tool surface exposes no working collaboration message tool; the shared seam and required malformed-fixture migration were reported to root in commentary.

## Remaining known integration edit

`engine/tests/local_selection.rs:117–123` remains outside this lane's granted file list and still performs `invalid.tab_mru.remove(...)` on a committed Workspace. It must be changed by root or explicitly reassigned before the first full test build can succeed:

```rust
let mut invalid = engine.workspace().clone().into_builder();
invalid.draft_mut().tab_mru.remove(&tabs);
assert!(invalid.build().is_err());
drop(frame);
// Retain the existing original workspace/version/focus rollback assertions.
```

This moves invalid-state rejection to the construction Interface while keeping staged Select/frame-discard behavior. Do not reintroduce a production unchecked Workspace solely to preserve an invalid replacement input. A separate existing host-frame suite covers failed-append rollback; a new frame protocol abstraction is unnecessary here.

Other cross-module symbol/privacy/type issues may surface in root's first compile; no successful compilation is claimed. Root can return the exact diagnostics for a bounded follow-up patch after the compile has stopped.

## Added verification surface

`operation/tests/local_item_move.rs` compares local completion with the actual complete general candidate route, not a mock executor. Its deterministic matrix covers two axes, selected/unselected moved item, singleton/populated source, source/other/no central leaf, same-pane/same-root/cross-root destinations, center/tab-gap and all four inner/outer edges. Successful candidates run the complete strict validator and compare before/after multisets outside the local work ledger snapshot.

Additional cases verify full-root presentation retirement for main/contained owners, candidate discard/retry, an unchanged Select plus Move selecting the general batch route, and a real late f32 outer-flattening weight underflow rejecting atomically with the same general error. Existing checked-move/policy/same-version/late-output tests remain the broader acceptance surface.

Added two tiny fields to the existing disabled-for-formal-timing work ledger: `canonical_full_passes` and `workspace_full_validations`. Local Item Move asserts both zero, `item_multiset_scans == 0`, and exactly one counted candidate clone. The new ledger calls use the existing `update` compile-env bypass, so they do not introduce a hidden O(N) formal-timing walk.

Single Select's property oracle now explicitly invokes the general candidate helper; it does not compare the preserving route with itself. Old raw-snapshot eligibility tests were migrated to raw Builder cleanup/rejection, while recycled node and valid same-version source/target semantics remain behavioral locks.

## Expected work and limitations

For an ordinary single Item Move, expected full global multiset, normalization and strict-validation counters are zero; deep candidate clone remains one; current root fingerprint build/visit costs remain unchanged. No local mutation timing or end-to-end ratio has been measured by this lane. Caller all-root request proofs still remain within the timer and already threaten the 2x budget on their own; the next owner-reference slice is intentionally not mixed in here.

The repair result table is temporary generation-aware storage and is empty/allocation-free on ordinary populated-source center/inner-edge fixture paths. Last-tab repair still searches the affected current root path and may grow the result table by global slot id; this slice removes global final settlement rather than claiming all mutation work is O(height). The exact single-command equality checks and full candidate clone also remain visible.

Before freezing timings root should run compile integration, the new/local checked suites, ordinary full-feature tests and the layout oracle suites, plus the existing complete output equality. Required existing guarantees include source-first stale errors, independently stale same-root target, forged target facts, exact MRU, arrangement policy/no-op policy, batch staged validation and all late publication/native barriers. Formal timing must retain current request capture, checked apply, all-root actual layout and fresh owned export; no new work is moved out of that timer.


## P1 numeric frontier correction — READY, source stationary

Root confirmed the two exact-f32 tests failed on the pre-fix runtime: both complete-general oracles rejected the reachable checked-Builder witnesses, while local apply incorrectly returned success. Evidence: `combined-checks/weight-witness-red.log`. This lane has not run Cargo, tests, benchmarks, or timing.

The correction is limited to `canonical.rs`, `operation.rs`, and the two regression tests already added in `operation/tests/local_item_move.rs`:

- Edge insertion returns the actual split roster it changed (existing same-axis parent or newly created wrapper). This optional NodeId travels through the existing private execution return. Center, tab-gap and no-op moves return no split. No extra root lookup/DFS or alternative executor was added; general/owned callers ignore the receipt and retain their full settlement.
- The local finisher checks that exact roster before any rewrite. Cardinality, scalar checks, f64 accumulation order and `1e-5` tolerance use an extracted private `validate_split_weights` helper also called from the original complete input validator. A failed frontier invokes the original complete input validator, preserving its canonicalization error type and deterministic ordering.
- The local repair records surviving outputs of its source-path and outer-wrapper repair steps, together with the inserted split. Only final live split records are checked after all rewrites. Retired intermediate outputs are skipped. The output gate covers strict minimum arity, matching cardinality, finite positive scalars and the unchanged aggregate sum rule. A failed gate invokes the original complete strict validator to produce its full `InvalidOutput` diagnostic collection and order.
- Output checks are deferred until canonical rewrites finish, so a later canonicalization failure retains priority over an earlier numeric output defect. An impossible disagreement between the narrow gate and its complete diagnostic validator fails closed with the existing TraversalInvariant type.
- Known vacated source-surface pruning now precedes local finalization, matching the general route's prune-before-canonicalization order and preventing a temporary empty presentation from appearing in strict failure diagnostics.
- No epsilon, normalizer, proof/policy/rollback contract, Builder/import rule, batch route, or dependency changed. The populated-source center success path has no split frontier allocation/check; edge and last-item routes perform only their local frontier checks. Complete diagnostic passes occur only after a failed frontier.

Regressions: `inner_edge_input_weight_sum_witness_matches_general_rejection_and_rolls_back` asserts the exact general `WeightsNotNormalized` rejection; `source_collapse_output_weight_sum_witness_matches_general_rejection_and_rolls_back` asserts the general `InvalidOutput` with `SplitWeightsNotNormalized`. Both compare the actual transaction error to the independent complete-general result and verify complete Workspace rollback. Existing success-matrix assertions still require zero global normalization/strict-validation/multiset work and independently strictly validate successful outputs.

Only local rustfmt (skip_children=true) and read-only diff/occurrence checks were performed after the edit. Root must confirm both witnesses turn green, then run the focused/deep/full qualification and retain timing work in the existing formal boundary. This READY entry is a source handoff, not a claim that the fix compiled or passed tests. No further source editing or owner-proof design will be performed by this lane until root assigns a follow-up.

Final source SHA-256 at handoff:

- `crates/dockspace/src/canonical.rs`: `ba82d77b16aff98cf049a6cd0ced922aec7412cbd7443025579b5c204845628d`
- `crates/dockspace/src/operation.rs`: `f89cc23fe15c7626e145ec2434853be6a01bedd3b3db07b1310650d9f312c586`
- `crates/dockspace/src/operation/tests/local_item_move.rs`: `6448016ecf97272fb1432d26c6e540eb9077427c6613ef1deb89e0d2738307c5`
