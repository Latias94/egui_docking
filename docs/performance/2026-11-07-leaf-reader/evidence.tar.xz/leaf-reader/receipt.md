# Fresh DFS leaf reader: prepared patch receipt

Status: PREPARED IN /tmp ONLY; STOPPED pending root's A1 + linear freeze and apply decision. No repository source edit, Cargo/build/test execution, benchmark or timing. The candidate has not been typechecked or executed, and no gain is predicted or claimed. It is independent of the temporary solver-aggregate patch.

## Artifacts and exact base

- `leaf-reader.patch`: unified patch with accurate `a/crates/dockspace/...` and `b/crates/dockspace/...` labels.
- `base/`: byte-for-byte copies of the 11 current workspace files.
- `tree/`: the corresponding complete candidate files.
- `base-hashes.json` and `candidate-hashes.json`: exact per-path SHA-256 values and diff counts.
- Patch SHA-256: `9e5536d3d29d927e1f3ed0db088243e6f20e75c1daef58635185485671e31efc`.
- Aggregate base SHA-256: `4416429dc57aaa8a7186cb41afa021a22ea7539912997a1050f621c0be8609c8`.
- Aggregate candidate SHA-256: `5832e67919b285e801a8e97297695e66f55a9e5d27692f825b45a71fd14a4e31`.
- Aggregation uses sorted relative path bytes, NUL, then complete file bytes.
- Total diff: 245 added, 55 removed lines across 11 files. All 11 live workspace files still equal their saved bases when this receipt is generated.

The layout base is exactly the solver candidate's base: `354f015c74a2e942d006d7c1e510a26df3f43ebf49e42bf0763687ab38fdd44f`. The solver's aggregate changes and test are absent from this patch. The two candidates should be applied/measured independently against the frozen baseline before considering a combination.

## Complete proposed path inventory and base hashes

| Proposed path | Exact base SHA-256 |
| --- | --- |
| `crates/dockspace/src/docking_cost.rs` | `16639841318fce154f3c4b020d87c0af4b9b9d1534d6f63bf17d4fab149c101e` |
| `crates/dockspace/src/engine/splitter_geometry/tests.rs` | `3694db011d46f2bbe1ba68b91bbe31c113a26c9a4f89860a7c7e7ffd52509679` |
| `crates/dockspace/src/layout.rs` | `354f015c74a2e942d006d7c1e510a26df3f43ebf49e42bf0763687ab38fdd44f` |
| `crates/dockspace/src/layout/layout_cost.rs` | `96aaf313cf240345fc03c05d3b166fa3dc39bb5c4da9618b762a3d2180b5ac6e` |
| `crates/dockspace/src/layout/override_tests.rs` | `dc06845930e2379862be78d66b9a6041728c1f7428a6ec088d03191b9d813cc9` |
| `crates/dockspace/src/layout/topology.rs` | `7bc045245503a4ebd329349e6cf92676c40bdb78201a04069ca6fa5f0c230fb1` |
| `crates/dockspace/src/layout/topology_tests.rs` | `bb8611a47a0b8c4d804165a2c721cbca62de7bd3461fe1cc5b6fce1bfa44ee64` |
| `crates/dockspace/src/presentation_hit/geometry_reuse_tests.rs` | `96696fdcb977d72a6db19e0efcd725aed184efc5e87e14e5824aeab9bc4aa5db` |
| `crates/dockspace/src/presentation_hit/touch_tests.rs` | `b453c94e7c519647a6f966f81ecd19e79338280024325ecc1fd249d809b3d992` |
| `crates/dockspace/tests/layout_solver.rs` | `b64d99a54be54f719531b2bfb0962fb322764ee0a28cd87dd690f520fbc611d0` |
| `crates/dockspace/tests/model_properties.rs` | `a4890413be53c1db57685e16a62d181d0c337d48c4d98067ecfbc3b89367cd00` |

Only `layout.rs`, `layout/topology.rs` and `docking_cost.rs` have production/input implementation changes. The other eight paths migrate actual callers or tests. The two `crates/dockspace/tests/` legacy files are mechanically migrated but remain unregistered under `autotests = false`; no coverage claim relies on them. No other crate is changed. Source search found no direct project_root caller outside dockspace.

## Small Interface and shared Implementation

```rust
pub fn project_root(
    workspace: &Workspace,
    root: RootId,
    bounds: LogicalRect,
    read_leaf: impl FnMut(NodeId) -> Option<Constraints>,
    metrics: LayoutMetrics,
) -> Result<LayoutProjection, LayoutError>;
```

`project_root_with_overrides` accepts the same callback plus its existing override slice. Keyed callers supply `|node| constraints.get(&node).copied()`. Inline temporary map expressions are materialized once before constructing the closure, rather than rebuilt per query. A formerly inferred collect in the layout unit fixture gains an explicit BTreeMap result type.

The existing sealed production compiler takes `&mut impl FnMut(NodeId) -> Result<Constraints, LayoutError>` and the actual `minimums_only` geometry mode. The complete-constraint public entry turns None into `MissingLeafConstraints` at the original leaf Enter, then calls that compiler and the existing `project_measurements`. The existing `measure_root` passes `leaves.get(node)` through the same compiler, retaining its real geometry/conversion errors and deriving the mode from the unchanged Copy enum. No provider trait, container abstraction, cache, compatibility entry or unused reader API is added.

The unchanged warm-minima path still uses `topology.measure` with keyed leaf inputs. `LeafMeasurements` remains Copy with its original Constraints/Minimums map variants and get method. The raw draft compiler retains its old keyed traversal and completed-DAG behavior. The independent frozen reference is untouched; its SHA-256 remains `93afdf6e8ad79d81f2efdafc4814a4bb6076fd9f535129f82ce33f9ee12ddf4e`. It still owns its old traversal, BTreeMap output type and solver.

## Actual cold workload and ownership

`docking_cost.rs::collect_constraints` keeps its complete recursive node traversal and every actual tabs match. Each leaf appends its real complete NodeId and its explicit Constraints value into a newly allocated Vec. It does not use a constant-return reader or avoid the N leaf materializations. No reserve-counting traversal or fixture hint is added.

Each root passes that fresh Vec through an owning Peekable iterator. A query consumes the next explicit answer only when its complete NodeId equals the actual leaf being measured; otherwise it returns None. The actual producer uses the same left-to-right DFS ordering as the compiler. Vec growth, all leaf work, iteration and drop remain inside the original `project_all_roots` call between the mutation and layout timestamps. Request/mutation timers, complete export, normalized state checks and member checks are unchanged.

The reader and its state are used only during measurement. Neither topology, RootMeasurement nor LayoutProjection stores it. The public cold entry still compiles from the actual sealed Workspace on every invocation and never uses an index/hint or topology prewarm. Normal scene/future-preview minima callers keep their existing measurement/policy preflight and map paths.

The existing opt-in layout_cost probe receives only the keyed closure migration; its separate prepared/cold workloads and timer positions are unchanged. It is not used to move cold comparison materialization outside timing.

## Order and numerical preservation

The public complete-constraint entry checks requested root and every override before invoking the first leaf callback. The minima path still measures first and validates overrides only in projection. A missing leaf stops at that exact DFS Enter; an earlier subtree's aggregate error still occurs at Exit before later leaves are queried. There is no global callback preflight or late error collection.

No solver, composition formula, numerical fold, f32 conversion, central handling, rich output slab, identity directory or export implementation changes. Raw DAG/cycle diagnostics continue through the original keyed test-only adapter, so a sequential reader is never consumed once per diagnostic DAG edge. Arbitrary unused keyed entries remain ignored through the map closure; sequential input is explicitly DFS ordered.

## Focused registered coverage

Two existing/registered test seams carry the change, without a new fixture framework:

1. `sparse_recycled_tree_keeps_ordered_identity_and_cold_warm_oracle_results` is extended to feed real nonuniform DFS Vec rows to the cold callback, assert the exact complete-ID query sequence and full consumption, and compare every rich output field to the unchanged keyed reference. Its n-ary/opposite-axis/central/recycled identities, high-slot second root, sorted queries and warm minima oracle remain.
2. New `constraint_reader_preserves_depth_first_errors_and_override_precedence` uses one four-leaf n-ary tree. First/middle/last omissions assert exact missing IDs and the queried DFS prefix against the frozen reference. An invalid override asserts zero leaf queries. An earlier vertical subtree with overflowing finite maxima outranks a later missing answer and asserts only the first two leaves were queried.

Existing cold/warm minima-before-override, raw completed-subtree/cycle/missing-node, full projection property, old owned output and registered 10k tests are preserved. Their input adapters are migrated where needed. No test has been run by this lane.

## Preparation checks and next gate

Direct rustfmt with edition 2024 and skip_children ran only on temporary copies. The complete unified patch was read back; all production hunks are confined to the reader seam and fresh DFS input representation. The 11 live files were reread for byte equality to their saved bases; frozen reference identity was also checked. These are source preparation checks, not compilation or execution evidence.

Root should freeze the A1 + linear comparison first, decide whether to apply this exact-base patch, then run its serial compile and the registered reader/override/raw/minima/ownership tests before an unchanged full paired comparison. This lane has stopped without applying any repository patch.
