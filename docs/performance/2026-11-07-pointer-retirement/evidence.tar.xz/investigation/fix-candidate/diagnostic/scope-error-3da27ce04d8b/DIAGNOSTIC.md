# Superseded candidate with a test scope error

Do not apply this patch. The 14-line retained local sample capture block was inserted into `release_child_preserves_scroll_correlation_for_the_provider_terminal`, whose child variable is `child_binding`, while its uses were in `destroyed_child_route_retires_only_after_tombstone_commit_and_quiescence`. The patch therefore referenced `second` in the wrong function and left `point` / `retained_local` undefined in the intended test. This archive preserves the exact erroneous patch, test source, and packaging receipts; the corrected active candidate is two directories above. The archived SHA256SUMS describes the former package root and is retained only as historical evidence.

Archived patch SHA-256: `3da27ce04d8bd8fb1310f4577cc37ba9d5dcbc70330576ef98d85c520e172690`.
