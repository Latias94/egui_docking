# Registered verification targets for Root

These registrations were confirmed from source; no Cargo listing or test execution was run by this worker. `dockspace` has `autotests = false`, so registration was traced through `src/lib.rs` -> `behavior_tests` -> the explicit `#[path = "../tests/desktop_global_pointer_journal.rs"]` module. The following desktop cases therefore run in the dockspace **lib** binary. The other entries likewise have an actual `#[test]` plus a registered module chain.

| Binary/package | Exact test selector | Boundary exercised |
| --- | --- | --- |
| egui_dockspace_native lib | `coordinator::tests::retirement::destroyed_child_route_retires_only_after_tombstone_commit_and_quiescence` | Current fix: original RED, preserved facts/ordinal, independent retired delivery, real retained local sample, no current receiver/gesture/workspace change, strict roster capture, exact input retirement, forgetting and foreign rejection |
| dockspace lib | `behavior_tests::desktop_global_pointer_journal::stale_native_capture_on_release_cannot_authorize_delivery` | Real active drag with stale complete source binding on release; DeliveryOwnerLost cancellation, unchanged workspace, Idle and no preview |
| dockspace lib | `behavior_tests::desktop_global_pointer_journal::stale_native_capture_on_move_cancels_the_fresh_drag` | Same exact-incarnation loss on active move; cancellation before mutation |
| dockspace lib | `behavior_tests::desktop_global_pointer_journal::stale_native_capture_after_binding_reincarnation_cancels_without_reducing_later_edges` | Reincarnated binding followed by delayed capture-change/move/release batch; cancellation and later-edge suppression |
| dockspace lib | `behavior_tests::desktop_global_pointer_journal::platform_destruction_before_release_prevents_stale_cross_window_drop` | Actual platform snapshot precedes provider-contiguous release at the next reducer ordinal; stale cross-window delivery blocked |
| dockspace lib | `pointer_journal::tests::desktop_route_rejects_a_reused_window_token_with_an_old_incarnation` | Full incarnation equality despite reused surface/window token |
| dockspace lib | `engine::tests::host_authority::native_surface_local_lease_cannot_freeze_a_reincarnated_binding_frame` | Local lease cannot freeze against a successor incarnation |
| dockspace lib | `engine::tests::host_authority::native_surface_local_lease_cannot_cross_a_workspace_binding_reincarnation` | Local authority cannot cross workspace binding reincarnation |

The exact active-release assertion is in `tests/desktop_global_pointer_journal.rs:4589-4671`: the common helper submits an old binding as both delivery and capture during an already-active drag, requires `InteractionCancelReason::DeliveryOwnerLost`, and checks the complete workspace, Idle status, and absent preview. Both public wrappers are `#[test]`. This is established registered source coverage, not a passing result for this candidate.

Existing foreign handoff atomicity, pointer sequence/batch savepoint/replay, work-area freshness and overload/recovery suites remain unchanged. The final worker patch deliberately adds no second harness or large role matrix.

Limit: the added native fixture checks real retained local coordinates after retirement, and the registered lower-level tests separately exercise ABA and active release. There is no newly added single end-to-end native fixture combining a saved local sample, a same-surface successor with changed geometry, and an active release. Root can run the registered cases together before deciding whether that combined witness is necessary. The original physical CI smoke is still a separate execution gate.
