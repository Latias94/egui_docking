"""Serial integration, lint and documentation checks for the retained-input fix."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess
root=Path('/Users/frankorz/codes/rust/egui_docking')
out=Path('/tmp/physical-pointer-retirement/executed')
checks=[
('workspace',['cargo','nextest','run','--workspace','--all-features','--all-targets','--locked','--offline','-j1','--no-fail-fast']),
('clippy',['cargo','clippy','--workspace','--all-features','--all-targets','--locked','--offline','--','-A','warnings','-D','clippy::correctness','-D','clippy::suspicious']),
('docs',['cargo','doc','--package','dockspace','--package','egui_dockspace','--all-features','--no-deps','--locked','--offline']),
('doctests',['cargo','test','--doc','--workspace','--all-features','--locked','--offline','-j1']),
('fork-workspace',['cargo','nextest','run','--manifest-path','integration/egui-fork-workspace/Cargo.toml','--workspace','--all-features','--all-targets','--locked','--offline','--target-dir',str(root/'target'),'-j1','--no-fail-fast']),
('native-without-debug-assertions',['cargo','nextest','run','--manifest-path','integration/egui-fork-workspace/Cargo.toml','--package','egui_dockspace_native','--lib','--all-features','--locked','--offline','--target-dir',str(root/'target'),'-j1','--no-fail-fast','--config','profile.test.package.egui_dockspace_native.debug-assertions=false']),
('dependencies',['python3','scripts/check_core_dependencies.py'])]
paths=sorted((root/'crates/dockspace').rglob('*.rs'))+[root/'crates/egui_dockspace_native/src/coordinator/tests/retirement.rs']
hashes=lambda:{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
record={'started_utc':now(),'sources':hashes(),'checks':[],'normal_counters_enabled':True}
env=dict(os.environ,CARGO_BUILD_JOBS='1');env.pop('DOCKSPACE_BENCH_NO_WORK_COUNTERS',None)
for name,command in checks:
    print(name,flush=True);entry={'name':name,'command':command,'started_utc':now()}
    check_env=dict(env)
    if name=='docs':check_env['RUSTDOCFLAGS']='-D warnings'
    with (out/(name+'.log')).open('w') as f:r=subprocess.run(command,cwd=root,env=check_env,stdout=f,stderr=subprocess.STDOUT)
    entry.update(returncode=r.returncode,finished_utc=now());record['checks'].append(entry)
    record.update(sources_unchanged=record['sources']==hashes(),finished_utc=now())
    p=out/'integration-checks.json';p.write_text(json.dumps(record,indent=2)+'\n');assert json.loads(p.read_text())==record
    print(name,r.returncode,flush=True)
    if r.returncode:
        print((out/(name+'.log')).read_text()[-12000:],flush=True);raise SystemExit(r.returncode)
assert record['sources_unchanged']
