# Physical pointer retirement: pinned X11/fork analysis

The strongest platform-side candidate is a late, real child-window pointer callback during route restoration/teardown, while Adapter mapping still identifies that child and core pointer admission has already ended. The source supports this sequence, but the CI log does not identify the failing ingress or fact role, so it is not an established root cause. In particular, a capability/snapshot failure at roster 9 would falsify attribution to a raw callback and belongs to the parallel core analysis.

No source, cache, fork, test, build, binary or timing command was changed or run. Only this report was written. The current inspected native sources equal CI commit b662164; the egui checkout exactly matches f94ee58b3914de7ad71dab36919b329ef36b4035. Its actual winit dependency and cache source match 2664589f0bd6fd03b2a5490f23bcd692853e63dd.

## What the run establishes

Run 42297763668 passes root inspection, both drag thresholds and routing, exact Center targeting, merge, physical release and route restoration. At 22:06:58.0194139 it reports phase Retired with center_merge_verified=true. The root release is step 52; child route restoration is sequence 2, enabled=false. Roster 9 appears at .0347689; InvalidPointerFacts becomes fatal at .0438922 during await-retirement-quiescence. These facts exclude the earlier inspection-repaint failure as the immediate failing stage.

The last Center point is (640,421). It lies inside both the root and the still-reported child rectangle (560,226)–(1280,746). Thus restoring the child input region can cause a genuine pointer enter without any new physical motion. The test stage/log alone does not prove whether the fatal is CursorMoved, CaptureChanged, a query receipt, or a snapshot/capability operation.

## Actual fork behavior

1. eframe host_seam.rs:3104–3113 applies passthrough=false by calling set_cursor_hittest(true). Pinned winit x11/window.rs:1719–1754 implements this by restoring the full X11 input shape. It also retires explicit capture for that window. This is a native operation, not merely a UI flag.
2. Pinned x11/event_processor.rs:1700–1737 handles XI_Enter by emitting CursorEntered, then CursorMoved with the actual event-window position, root desktop position, independently queried hover and capture facts. No second XTest move is required to obtain the CursorMoved callback.
3. NativeWindowEventRecord freezes delivery from the actual WindowId and hover/capture from their own winit route fields (event.rs:449–477). Window IDs not in the map become Unknown, not invented foreign routes. pointer_binding_for_event/window only exclude pointer_suppressed routes (viewport_map.rs:637–651). In contrast, local coordinate and focus readers also check prepared retirement (663, 695–697). Therefore the mapping layer can still expose a retiring child's exact binding before its Destroyed suppression boundary.
4. The callback is frozen and enqueued atomically under the mailbox lock (mailbox.rs:6198–6217). It is not rebound to a different viewport when reduced. coordinator.rs:1755–1766 translates those original frozen facts and records them in core.
5. core validates every Native hover/delivery/capture binding before recording the edge (native/pointer.rs:878–880, 1040, 1082, 1099, 1114). A correct historical child binding with revoked admission is sufficient for InvalidPointerFacts. The required reproduction is consequently a lifetime/order disagreement, not necessarily a fabricated capture owner or invalid coordinate.

The explicit mismatch to investigate is: a real pointer callback names the child through the still-retained host route, while producer admission for that exact binding has ended. Destroyed processing later installs stream cancellation/suppression, but it cannot retroactively alter an earlier captured record.

## Capture-reset branch: possible, not inevitable

winit also has a second legitimate source of late child callbacks. UnmapNotify calls reset_window_pointer_captures (event_processor.rs:265–274); destroy_notify invokes that reset before Destroyed (1200–1222). For each device still owned by the window, the reset emits PointerCaptureChanged { capture: Unknown } to that same old WindowId (714–722). Adapter translates this as CaptureChanged with delivery still derived from the window mapping. Core can therefore reject its delivery binding even though capture itself is Unknown.

However, this must not be asserted as the normal post-release sequence: pointer_facts.rs:561–563 ends the device stream when the last button releases, and for_button_state also ends it for a no-buttons mask (688–690). reset_window selects only owner==Window(old_window) (733–747). A fully observed last release normally leaves no such implicit owner, so DestroyNotify alone does not force another CaptureChanged. Any capture-reset diagnosis must first establish remaining owner/device state or an earlier queued reset. Simply suppressing all CaptureChanged events would be unjustified.

The Adapter's retained mouse state does not fill an unknown event capture with an old owner. Its native_input function takes delivery and capture directly from the record's frozen routes (pointer_event.rs:573–605). The mouse.capture field is used for local state/tail handling, not serialized as a substitute capture fact. Cursor moves are still forwarded when no button remains; the captured-move filter applies only while an active button exists (813–828). This supports the post-release XI_Enter/CursorMoved candidate without requiring any capture disagreement.

## Snapshot and destroy boundaries

window_snapshot.rs:137–170 compiles window size, scales, bounds, presentation and ReceivesInput/PassThrough. It does not construct a Native pointer delivery/capture owner. eframe capture_window_snapshot similarly reads input state and actual window facts (host_seam.rs:2504–2516). A pointer-owner failure is therefore not caused by that Adapter geometry conversion itself; a core capability update performed while processing its roster remains a separate possibility.

Destroyed ingress first suppresses future pointer route/local-coordinate capture (event.rs:425–429). At reduction, coordinator.rs:1734–1745 records native input-binding retirement and then retires the translator's binding references before other destroy settlement. Later capture_window_destroyed updates the exact capture duty. These are precise boundaries and should stay intact. They do not prove that an earlier real callback, or a callback captured before suppression but reduced later, remains admissible in core.

The eframe host's forget_presented_window (3465–3514) retires exact-window property requests and removes presentation/input bookkeeping; late forget does not retire a successor. Its state is not the same owner as the Adapter's viewport map or core admission. No evidence was found of eframe rewriting a late X11 event to a successor window or of the Adapter synthesizing a captured old binding from egui pointer position.

## Minimal discriminator and narrow behavior test

Before choosing a fix, preserve the exact failing operation/record identity. A single temporary diagnostic at the existing error boundary should distinguish raw record_pointer from pointer-observation/capture receipt and roster capability/snapshot processing. For a raw record, capture ordinal, event variant, WindowId, frozen binding, delivery/hover/capture roles and whether each exact binding still has producer admission at reduction. For the competing snapshot path, record the roster ordinal and which capability/roster conversion raised the error. The existing fatal log lacks this information; no retry, event dropping or weaker facts are needed to obtain it.

The narrow regression should use the actual Adapter journal and lifecycle fixture:

- Accept the original child Primary press, real root release and Center merge, retaining the child's window route until the normal physical destroy boundary. Use the existing real lifecycle transition that revokes its pointer admission; do not manufacture a malformed binding or bypass validation.
- Restore that exact child's hit test while the stationary pointer lies within its native rectangle. Feed the real pinned XI_Enter-derived CursorMoved shape: child WindowId, finite same-event desktop point, independent hover, and capture=None after final release.
- Interleave that callback and the retirement roster/Destroyed boundaries in the observed order, including the case where the record was captured while the map still owned the route. Verify the original route facts and ordinal remain intact, release/merge are not repeated, the exact binding's retirement is recorded once, the live root can still receive a fresh pointer event, and teardown reaches quiescence without fatal.

First reproduce and classify current behavior; the expected corrected ownership boundary should come from the native/core lane's actual lifetime contract. A control with the same event while the child is live must remain ordinary accepted input. If testing the capture-reset variant, keep an actual remaining owner/button so it exercises winit's real reset precondition; do not use that variant to explain an ordinary final release without evidence.

This test targets the pointer/lifetime handoff. It must not remap Native roles to Unknown/Foreign, delete callbacks, ignore validation errors, extend input authority by a retry, or relax old-binding rejection. No patch or runtime redesign is proposed here.

## Exact source binding

| Artifact/source | SHA-256 |
| --- | --- |
| second-physical-failure.log | f211b87dc5c14fa2e5447b09cae6b086aa3ceafd6bad5264bc2076d9dd621286 |
| Adapter pointer_event.rs | 6f9a99e35ad0edae31b46d1144b0a408f0f4271b91f98f272497ecf8a0d03949 |
| Adapter event.rs | a57b1aa1cdd5eedffb9c58ec127583889e20c785bfd5afe1fbd5ff25d2dd867c |
| Adapter viewport_map.rs | f0e61a34bfbad0bb4d77732b1b966899b967e809531c3e3ece50d8e1157cc97b |
| Adapter window_snapshot.rs | 4ef5747bebf7a1c9a107ce37c459a7620f865bfb1be217ca571873f9fd4d5993 |
| Adapter coordinator.rs | e592e5d9e5585710570ab5cf1354cdc682473a71545005e7252566ad320e25e1 |
| core native/pointer.rs | 4f830aa26aea09c5d0cf63c1a81309e7f05a7bbe9ce4d0a22b3a9b6697ebc03e |
| eframe host_seam.rs at f94ee58b | 888fd9211930b4dea8dcb1ade13f11110bcf7e5d45828c65f93e9c85f35cc9e5 |
| winit X11 event_processor.rs at 2664589 | a93c45f1eab3475bab989d04149b9327ac7b2994e408cc97795cc12f6fc7662e |
| winit X11 pointer_facts.rs at 2664589 | a06584a5847bd8324bcb0c8060693decf9e3d47c0e5cbfbb4f3f9e589a643b69 |
| winit X11 window.rs at 2664589 | 75afcd696201b15ab1186853c0b733467d6ceaaf51265a6b85ec5646f2977862 |

These exact file bytes were compared to their named Git revisions using read-only Git objects. No claim of an executed causal reproduction is made.
