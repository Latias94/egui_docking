"""Preserve exact retained-pointer RED/GREEN sources, reviews and check receipts."""
from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile
root=Path('/Users/frankorz/codes/rust/egui_docking')
base=Path('/tmp/physical-pointer-retirement')
out=root/'docs/performance/2026-11-07-pointer-retirement';out.mkdir(exist_ok=True)
green=json.loads((base/'executed/green-checks.json').read_text())
rest=json.loads((base/'executed/integration-checks.json').read_text())
assert green['sources_unchanged'] and rest['sources_unchanged']
assert all(c['returncode']==0 for r in [green,rest] for c in r['checks'])
for r in [green,rest]:
    assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==digest for name,digest in r['sources'].items())
red=json.loads((base/'executed/causal-red.json').read_text())
assert red['returncode']==100
assert 'the retained pre-suppression callback must drain without InvalidPointerFacts: NativeRuntimeError' in (base/'executed/causal-red.log').read_text()
control=subprocess.check_output(['git','rev-parse','c98569d'],cwd=root,text=True).strip()
paths=['crates/dockspace/src/runtime/native/pointer.rs','crates/dockspace/src/runtime/native/session.rs','crates/egui_dockspace_native/src/coordinator/tests/retirement.rs']
inputs={}
for p in sorted(base.rglob('*')):
    if p.is_file() and (p.suffix in ['.rs','.json','.md','.patch','.log','.py'] or p.name in ['READY','SHA256SUMS']):
        inputs['investigation/'+str(p.relative_to(base))]=p.read_bytes()
for name in paths:
    inputs['actual-control/'+name]=subprocess.check_output(['git','show',control+':'+name],cwd=root)
    inputs['actual-candidate/'+name]=(root/name).read_bytes()
inputs['actual-control/commit.txt']=(control+'\n').encode()
inputs['actual-candidate/runtime-and-test.patch']=subprocess.check_output(['git','diff',control,'--',*paths],cwd=root)
for name in ['second-physical-failure.log','remote-ci-latest.json']:
    inputs['original-remote-ci/'+name]=(Path('/tmp/physical-smoke-ci/executed')/name).read_bytes()
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(inputs.items())}
with tarfile.open(out/'evidence.tar.xz','w:xz',preset=6,format=tarfile.PAX_FORMAT) as archive:
    for name,data in [*sorted(inputs.items()),('manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())]:
        member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644;archive.addfile(member,io.BytesIO(data))
with tarfile.open(out/'evidence.tar.xz','r:xz') as archive:
    seen=set()
    for member in archive:
        assert member.isfile() and member.name not in seen and '..' not in Path(member.name).parts and not Path(member.name).is_absolute()
        seen.add(member.name);data=archive.extractfile(member).read()
        assert data==((json.dumps(manifest,indent=2)+'\n').encode() if member.name=='manifest.json' else inputs[member.name])
    assert seen==set(inputs)|{'manifest.json'}
for name in ['admission-review.md','admission-test-supplement.md']:
    shutil.copy2(base/name,out/name)
checks={'normal_counters_enabled':True,'causal_red':red,'checks':green['checks']+rest['checks'],'sources_unchanged':True,'actual_control_commit':control,'source_sha256':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths},'physical_x11_confirmation':'pending fresh pushed-head CI; local macOS unit qualification does not prove physical callback chronology'}
(out/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(out/'archive-check.json').write_text(json.dumps({'regular_input_files':len(inputs),'all_members_roundtrip_equal':True,'actual_control_commit':control,'actual_changed_sources':len(paths),'archive_bytes':(out/'evidence.tar.xz').stat().st_size},indent=2)+'\n')
(out/'SHA256SUMS').write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.name}\n' for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS'))
print('Preserved',len(inputs),'inputs;',len(checks['checks']),'passing checks; causal RED retained, physical CI pending',flush=True)
