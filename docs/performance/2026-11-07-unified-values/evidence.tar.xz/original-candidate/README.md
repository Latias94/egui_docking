# Unified node values on the retained slice-composition parent

READY / source stationary / tmp only. This is a separate candidate after
both slab and childrows were rejected. Root owns all compilation, tests,
normal qualification and paired timing. No such execution occurred here.
No repository, fork, cache, old candidate, Git write, network or sub-agent
was used. Rust best-practices was read before writing Rust.

## Exact retained parent

initial/ is the immutable e3c517195ddce2c7d1a6dbfd4328f152978968ec actual
five-file layout source. Its bytes equal the original initial inputs,
with the original slice composition helpers and original raw/reference.
base/ is exactly initial + `/tmp/projection-frame-retained/candidate.patch`
then `/tmp/binary-split-inputs-retained/candidate.patch`. Both preceding
packages have their own complete pairs, manifests and READY receipts.
They contain no slab or childrows hunk. parent-composition.json binds
these exact inputs/stages; parent.patch reconstructs this composed base
from initial/ for review only. It is not part of the primary unified delta.

Prerequisites remain independent root-owned performance decisions. If
frame or binary is rejected, explicitly rebase rather than carrying a
rejected optimization back through this parent. This lane does not
qualify either prerequisite or call fewer buffers a measured benefit.

## Original slice arithmetic and raw Adapter retained

compose_constraints, compose_minimum and compose_maximum retain their
entire original &[SubtreeMeasurement] signatures and function bodies.
No iterator/generic childrows helper is restored. The entire independent
reference.rs remains the immutable e3 original. compile_draft's complete
checked body is byte-identical to that parent: active/completed rows,
checked joins, leaf/error order, cycle/cardinality checks, child_values
scratch, bool propagation, central check and directory completion stay.
The raw check_central body is likewise unchanged, merely cfg(test) now
because only raw diagnostics call it.

Production measurement still has a root-local child_values Vec and
materializes each split's child inputs in the original order. It gathers
the existing SubtreeMeasurement wrapper from each NodeResult.constraints,
with contains_central fixed false. The unchanged compose functions read
only constraints. This deliberately retains the original scratch owner
and scalar reduction path instead of repeating the rejected childrows
optimization or inventing a new provider/type. Delayed minimum-only
maximum completion likewise retains its original child_values Vec,
slice call and evaluation schedule, using the same false-bool wrapper.
The SubtreeMeasurement declaration stays available in production for
those two scratch uses. No standalone replacement type was added.

The false scratch bool does not become a central-membership claim.
Production central handling is exclusively the concrete scalar route
below; the checked raw compiler still computes every real bool unchanged.

## Own unified storage and scalar route

One fresh private Vec<NodeResult> is initialized and its constraints are
written in the same postorder using every fresh leaf answer. A matching
Tabs seeds central_leaf_row only after its reader succeeds. All
measurements finish before the same requested-but-unreached central error.
RootMeasurement retains the values Vec, scalar leaf row and existing
measurement metadata until its consumer supplies bounds/overrides.

The Vec moves into NodeMap without another N-value production result
allocation or per-row constraints-to-output conversion. Geometry writes
only rects. Every Enter executes a normal release row<=visited_prefix
assertion before indexing, increments on equality and allows earlier raw
revisits. The final complete-prefix check remains debug-only. Prefilled
values do not stand in for actual traversal coverage. No filled-length
shortcut, N visit flags or new validator is added.

The private production CentralRoute keeps only leaf/next scalars and
starts next at root. Only the containing-frontier split picks the last
direct child preorder start <= leaf and advances next. The matching Tabs
clears the route. Completed owner-built tree subtrees are contiguous and
ordered; unrelated branches never receive central treatment. Total
selection work is bounded by the central ancestors' direct-child counts,
at most O(N), with no central Vec/reverse/binary search in production.

After successful raw compilation, the original true bool rows are
collected in ascending row order. The cfg(test) Raw route uses all of
them in the same projection executor, preserving central membership in
multiple DAG parent branches and original first-child selection. Raw
revisited geometry still overwrites already visited rows. It does not
apply the tree argument to a shared DAG.

The scalar route, release prefix and raw-success adapter are unchanged
from the frozen scalar3Vec candidate; only the necessary composition
integration differs. No second solver/executor, public stage, proof,
trust flag, answer cache, provider, generic framework, unsafe or dependency
is introduced.

## Numerical, error and lifetime boundary

The single solver, every checked sum/feasibility exit/desired normalization/
water-fill pass, compose arithmetic, splitter geometry and compact
continuation/cursor calculations are byte-identical to base. Binary
constraint/weight arrays, generic fallback and full f64 override priority
are preserved. Public override validation still precedes fresh reader
calls; minimum measurement still precedes delayed bound/override work.
No earlier error is moved behind a geometry step. All roots, leaf reads,
full fresh outputs, normalized export words and timing boundaries remain.
No benchmark source is changed.

Partial values remain private until geometry returns success. Completed
outputs and clones own their buffers and immutable split payloads across
later calls, Workspace edits/destruction and subsequent failures. Public
NodeResult shape, complete generational identity, sorted/preorder access,
SplitMap and its retained three child-extent Vecs are unchanged.

## Costs and limitations

The candidate removes one production N-element measurement owner/copy into
an independent result buffer; it intentionally does not remove child
scratch gathering. Each gather now constructs the original wrapper with
a false bool, retaining that storage/padding and potential writes. Both
full measurement and delayed maxima keep their root-local scratch Vecs.
The three split extent Vecs remain after the slab rejection. No reduction
in allocator time or bytes is inferred from this owner inventory.

NodeResult initialization includes a zero rect before actual bounds exist.
Full projection overwrites it. Minimum-only/contained clipped consumers
may discard the measurement and pay extra rect initialization and residency
without receiving a later unified-output saving. Central frontier scanning
can be O(N) in a deep/n-ary tree, and the release prefix adds explicit
scalar checks. Raw diagnostics intentionally retain their own checked
measurement and adaptation cost. ABI sizes, code size, allocations,
latency and target progress are unmeasured. These negative paths belong
in retention decisions; success on complete layout alone is insufficient.

## Tests and static checks

The original two added registered semantic tests are preserved byte for
byte: central_ancestor_depths_keep_fresh_reader_order_and_delayed_minimum_projection,
and raw_shared_central_subtree_keeps_membership_in_both_parent_branches.
All existing test bytes, including the frame 55-line ordering witness,
late-error/old-clone, raw completed reuse/cycle, sparse generation,
minimum/override precedence, full independent oracle and registered 10k
depth remain. No new test or framework was added beyond those original
two tests. None was run here.

The three runtime paths contribute +131/-69, below 150 added lines;
one test module contributes +139/-0. The main candidate.patch contains
only this own slice, with no frame/binary prerequisite hunk and no
reference.rs delta. Static checks compare all numeric/continuation/raw
functions, slice signatures, original test bytes and exact stage joins.
All three primary packages and the separate complete parent patch were
reconstructed against their exact inputs in memory. Primary and parent
patches also pass read-only git apply --check --whitespace=error in their
temporary inputs. Only unified tree layout.rs/topology.rs were locally
rustfmt-formatted, edition 2024 skip_children=true. These are not Rust
typechecking or behavior/performance qualification.

| Source under crates/dockspace/src | Retained base SHA-256 | Tree SHA-256 |
| --- | --- | --- |
| `layout.rs` | `02a94c4c811b47214f0ca930f69b68bb94d18f25ec9c9d28644102536ad38f21` | `478cf5a1f3c6cf41cd3f21f3dfdc301a350957f18f58f900376edb256e38c05e` |
| `layout/projection.rs` | `d82120c1f004511128e65ad7a57f907583c150545ff286acfead2bc4cbfeeed4` | `1a54741ad89e01e2011a35d1f60c4896f2af7fe5b375d4df4d105318b8b4cfa9` |
| `layout/reference.rs` | `2b2eee151d88bdd83048f0dfe7a4931a769aff6616da59e060200819008b209a` | `2b2eee151d88bdd83048f0dfe7a4931a769aff6616da59e060200819008b209a` |
| `layout/topology.rs` | `d2d06077b9a5bfb03f764b0ed9c862de4e9aca3a65946059e480b8412f356f56` | `1dc1264af676b5a083a299332203057b02004d174c8d4e27e45c6074f513a26c` |
| `layout/topology_tests.rs` | `e7bacde83b6d7c957ee8d749cdaf70fb06ca6f85c5850515169e2bd279b1d729` | `31c5e094b6c48cd58922de2642a08e223d1f5606f00463d1387e94a08ff93a2b` |

Primary patch SHA-256: `f866a91d48521dec4931fac1b0e2002ee237cb5b86e39d5ff03c0390af184ea1`.
Base set: `6aff73c1aa124fa3fe02287016de5fcce41e47ac68d2bfddb64d56f1bb6aca90`.
Tree set: `109d73f5d982031e413a70b3d4481330ed729de4f36b588587ec166f696cd9e3`.
Parent patch SHA-256: `b9581f2081cb6619195389f49f1bd8354a0838222e715cfeffc17f41ff8a06b2`.

Set format is ascending UTF-8 relative path + NUL + file SHA-256 + newline.
base-manifest.json, parent-composition.json, rebase-adaptations.json,
scope-checks.json, manifest.json and READY.json bind all stationary
sources/artifacts and the negative scope. Apply exact matching hunks;
do not overwrite a later repository file with these complete copies.
