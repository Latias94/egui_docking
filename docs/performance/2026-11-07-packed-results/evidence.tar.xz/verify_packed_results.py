"""Serial correctness gates for materialized child projection results."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path('/Users/frankorz/codes/rust/egui_docking')
out = Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e/packed-results-verified')
out.mkdir(exist_ok=True)
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
env = dict(os.environ, CARGO_BUILD_JOBS='1')
env.pop('DOCKSPACE_BENCH_NO_WORK_COUNTERS', None)
sources = list((root / 'crates/dockspace').rglob('*.rs')) + [root / 'Cargo.toml', root / 'Cargo.lock', root / 'crates/dockspace/Cargo.toml']
hashes = lambda: {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
start = hashes()
record = {'started_utc': now(), 'normal_counters_enabled': True, 'sources': start, 'checks': []}
checks = [
    ('fmt', ['cargo', 'fmt', '--all', '--check']),
    ('targeted', ['cargo', 'nextest', 'run', '--package', 'dockspace', '--lib', '--all-features', '--locked', '--offline', '-j1', '-E', 'test(semantic_edits_share_placements) | test(tab_mru) | test(mru) | test(history_only) | test(copy_tests) | test(layout) | test(owner_reference) | test(split_resize) | test(local_item_move) | test(local_selection) | test(transaction) | test(canonical) | test(close) | test(surface_recovery) | test(presentation_authority) | test(splitter_geometry)', '--no-fail-fast']),
    ('fixes', ['cargo', 'nextest', 'run', '--package', 'dockspace', '--lib', '--all-features', '--locked', '--offline', '-j1', '-E', 'test(structural_drop_work_has_deterministic_scale_baselines) | test(real_host_frame_tab_press_and_release_have_bounded_clone_work) | test(engine_presented_drop_reuses_the_requirement_workspace_index) | test(changed_source_item_rejects_frozen_close_without_mutation)', '--no-fail-fast']),
    ('core-production', ['cargo', 'nextest', 'run', '--package', 'dockspace', '--lib', '--all-features', '--cargo-profile', 'production', '--locked', '--offline', '-j1', '--no-fail-fast']),
    ('public-integrations', ['cargo', 'nextest', 'run', '--package', 'dockspace', '--tests', '--no-default-features', '--locked', '--offline', '-j1', '-E', 'kind(test)', '--no-fail-fast']),
    ('workspace', ['cargo', 'nextest', 'run', '--workspace', '--all-features', '--all-targets', '--locked', '--offline', '-j1', '--no-fail-fast']),
    ('clippy', ['cargo', 'clippy', '--workspace', '--all-features', '--all-targets', '--locked', '--offline', '--', '-A', 'warnings', '-D', 'clippy::correctness', '-D', 'clippy::suspicious']),
    ('docs', ['cargo', 'doc', '--package', 'dockspace', '--package', 'egui_dockspace', '--all-features', '--no-deps', '--locked', '--offline']),
    ('doctests', ['cargo', 'test', '--doc', '--workspace', '--all-features', '--locked', '--offline', '-j1']),
    ('dependencies', ['python3', 'scripts/check_core_dependencies.py']),
    ('host-default', ['cargo', 'nextest', 'run', '--manifest-path', 'integration/dockspace-host-harness/Cargo.toml', '--target-dir', str(root / 'target'), '--locked', '--offline', '-j1', '--no-fail-fast']),
    ('host-serde', ['cargo', 'nextest', 'run', '--manifest-path', 'integration/dockspace-host-harness/Cargo.toml', '--target-dir', str(root / 'target'), '--features', 'serde', '--locked', '--offline', '-j1', '--no-fail-fast']),
]
selected = sys.argv[1:]
for name, command in checks:
    if selected and name not in selected:
        continue
    print(name, flush=True)
    entry = {'name': name, 'command': command, 'started_utc': now()}
    check_env = dict(env)
    if name == 'docs':
        check_env['RUSTDOCFLAGS'] = '-D warnings'
    with (out / (name + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=root, env=check_env, stdout=log, stderr=subprocess.STDOUT)
    entry.update(returncode=result.returncode, finished_utc=now())
    record['checks'].append(entry)
    record.update(sources_unchanged=hashes() == start, finished_utc=now())
    (out / ('checks-' + (','.join(selected) if selected else 'all') + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(name, result.returncode, flush=True)
    if result.returncode:
        print((out / (name + '.log')).read_text()[-14000:], flush=True)
        sys.exit(result.returncode)
assert hashes() == start
