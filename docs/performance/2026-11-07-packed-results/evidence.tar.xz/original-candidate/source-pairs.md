# Exact immutable source pairs

Base commit: `07f566ac8fbddfab819f46f613d55bc2069507dd`.

| Path | Base SHA-256 | Candidate SHA-256 | Delta |
| --- | --- | --- | --- |
| `crates/dockspace/src/docking_cost.rs` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` | +0/-0 |
| `crates/dockspace/src/engine/splitter_geometry/tests.rs` | `735d87c0b79e887b873006a9b12df17566ec6fe55897ad24f59fc345b7cd96b0` | `c5b7ef20d74c5ef496227c9e5685fef5ace1c14cdb66a981866190934e105d65` | +31/-15 |
| `crates/dockspace/src/engine/splitter_geometry.rs` | `2019f0ad456794ae23b4c4aabeb14f7e7554d17104d7ceb8a5b0e88e90ba4f36` | `4a3970fcdf922ac74b1fbcfbea4efeb59996d9c3812b16dd55cf8efeb568497e` | +42/-24 |
| `crates/dockspace/src/graph/root_structure.rs` | `e80a74d1bdef525bd25a9a627bd1c826f41cd1def8fe05583dcea14372938632` | `a89bf210b4836d10380007e1d5594ad6c76281a338b12d10f0408ba7ee98eca7` | +0/-5 |
| `crates/dockspace/src/layout/layout_cost.rs` | `420140d7cca7915966e0103c06ad27453d8b8fddba5f13a090dcab0d9691250e` | `420140d7cca7915966e0103c06ad27453d8b8fddba5f13a090dcab0d9691250e` | +0/-0 |
| `crates/dockspace/src/layout/projection.rs` | `1a54741ad89e01e2011a35d1f60c4896f2af7fe5b375d4df4d105318b8b4cfa9` | `fb6fb6454034656114bfdcb80049f53fbbc325a780af00f720efd7769fa1494e` | +26/-25 |
| `crates/dockspace/src/layout/reference.rs` | `2b2eee151d88bdd83048f0dfe7a4931a769aff6616da59e060200819008b209a` | `4b6ff84c9bed4b65a202e1c771b5f176b161bbb27b99dba25e4875c7b08c07c6` | +12/-4 |
| `crates/dockspace/src/layout/topology.rs` | `1dc1264af676b5a083a299332203057b02004d174c8d4e27e45c6074f513a26c` | `1dd27eb635c84e0d73bf9186eb2e741f400b10e4b36bb6365477ac01c5bd21c6` | +0/-3 |
| `crates/dockspace/src/layout/topology_tests.rs` | `31c5e094b6c48cd58922de2642a08e223d1f5606f00463d1387e94a08ff93a2b` | `1c95593313304e7c0660b3191804d71cf22cff345a207b1cd00c6cfa7bf6cd26` | +2/-4 |
| `crates/dockspace/src/layout.rs` | `478cf5a1f3c6cf41cd3f21f3dfdc301a350957f18f58f900376edb256e38c05e` | `ee0bbdadf60b10a3787539e89cdee41411301c3c774e66d53c0146ad1567eaec` | +33/-14 |
| `crates/dockspace/src/operation/tests/owner_reference.rs` | `8a39eb6df3d844f952af7b550f75f51c51ab6d5c853b47f8748b69adb55158d4` | `0d6a8d0f5931976a1561790a48d53273c8f68e5983d6ad25c8ff7989d4aa7199` | +1/-5 |
| `crates/dockspace/src/scene_compiler/surface.rs` | `abf030c112a4d6290d573d5f77669d94247a6dbd92d572d9109209fa87795feb` | `ae62a422ebc931988068625a8fc1ff253a02c99a754beac25809abaea09ce01f` | +37/-34 |
| `crates/dockspace/tests/layout_solver.rs` | `4b750cd3f85457f26a86529011b5e8396ea04a0dcd46648180969d55943014ee` | `8980597f86765c12dc3313b5d481cb6c62f20782e71c8a57861d715857639413` | +41/-11 |
