# Packed child results on the retained parent

READY / source stationary / not qualified. This is the same packed-output
ownership candidate rebased to immutable retained commit
`07f566ac8fbddfab819f46f613d55bc2069507dd`, without the axis-validation
specialization. It is not a new optimization. Neither this package nor the
original packed candidate has been executed. Root alone owns compilation,
behavioral qualification, timing and retention.

Only this new temporary directory was written. No repository, fork, cache,
previous candidate or Git state was changed. No Cargo, compiler, test,
runner, benchmark, timing, profile, network or child agent was used.
Rust best-practices was read before edits; only temporary changed Rust
files were formatted with edition 2024 and skip_children=true.

## Immutable base and exact rebase

All thirteen `base/` files came from Git blobs of
`07f566ac8fbddfab819f46f613d55bc2069507dd` using one read-only
`git cat-file --batch` request. None came from the live working tree.
`base-manifest.json` records each full commit/path origin, Git blob ID,
SHA-256 and length. `tree/` contains the corresponding complete candidate
files. The two cost probes are unchanged context pairs.

Original package: `/tmp/packed-child-results/`.
Original packed patch SHA-256:
`b1253ea66cafbaa4a991584201758bb6b6c0c8a132adb605ee1cb1c4767f8995`.
Its frozen patch, manifest, READY, source checks and README are copied
under `inputs/`; the original directory remains unchanged.

All fifty original packed hunks were replayed. Forty-seven original
old/new hunk bodies remain exact; three layout hunks adapt the absent
axis specialization:

1. The SplitMap constructor hunk's surrounding call is the retained
   `project_subtree(...)`, without a const argument.
2. The min/max/None-store hunk's following context retains the original
   direct `weight_overrides.get(&node_id)` selection.
3. The temporary sizes and immediate copy hunk calls the retained
   `solve_axis_into(...)` with `extent - splitter_extent`, rather than
   entering the validated solver after a specialized check.

`rebase-hunks.json` binds original/applied hunk-body hashes and stage
before/after file hashes. Eleven of the thirteen resulting files are
byte-identical to the original packed tree. The only differences are
`layout.rs` and `layout/topology_tests.rs`, because the retained parent
has neither the axis specialization nor its two dedicated tests.
The axis-only LogicalPoint import is also absent from both base/tree.

The complete public solve, private `solve_axis_into`, input validation,
numeric executor and helper functions are byte-identical to the retained
parent. `solve_axis_into` remains the sole projection entry: it always
calls full `validate_inputs` before the one numeric executor. The new
binary/nary temporary sizes are passed to that entry. No const wire,
extent-only helper, override-presence shortcut or direct projection call
to `solve_validated_axis_into` is introduced.

Any later command-ownership raw-root COW test change is a separate hunk.
It is not included here. Apply matching hunks against that later tree;
never replace a repository file with this complete frozen context copy.

## Unchanged packed slice

The output still keeps NodeMap's fresh NodeResult buffer and its separate
SplitOutcome buffer. The three child-extent arrays and separate stored
gap-rectangle array are replaced by one parent-edge buffer of materialized
ChildProjection records:

- `minimum`, `maximum` and `extent` are stored f64 values;
- `following_gap` stores the already computed Option rectangle, absent
  after the final child.

`SplitProjection.children` borrows these records.
`splitter_rects()` only visits stored rectangles and allocates nothing.
The former three scalar slices and rectangle slice are removed, without
compatibility slice families or lazy value derivation.

During prepare, minimum/maximum values are stored at the original phase
and following gaps are reset to None. Binary output uses a fresh local
`[f64; 2]`; other arities clear and zero-resize one reusable sizes Vec.
The checked entry solves that contiguous slice, then every actual extent
is immediately copied into its parent-edge record before descending.
Suspended parents read their owned edge extents, so descendants can reuse
the scratch. All initialization, solve and copying remain timed work.

The continuation still adds the original solved extent after its child
returns, constructs the gap at the original late point, stores Some(rect),
and advances by the original thickness. Numeric reductions, both assigned
sums, scalar/error ordering, desired allocation, redistribution and
central routing are unchanged.

Separate parent-edge ranges preserve raw DAG allocations under different
parents or axes. Repeated visits overwrite the same split's own range
and outcome, retaining the original last-write result. The release
first-visit prefix guard, raw cycle/reader diagnostics, delayed maxima,
override precedence and private failure/discard behavior remain.
NodeMap, generational identity joins, sorted/preorder iteration and
logical split equality are unchanged; physical edge-vector order is
not used as logical identity. Old outputs and clones own complete buffers.

Only unused RootNodeKind gap ranges and RootStructure gap counts are
deleted from committed/raw builders. The split ordinal/directory,
placement logic, capacity hint and actual local splitter arithmetic and
errors remain. The placement oracle drops only the obsolete field
binding and its gap-directory length assertion.

## Scope and source evidence

Eleven paths differ: six production files (+138/-105), one cfg(test)
oracle capture (+12/-4), and four mechanical test files (+75/-35).
Total: +225/-144, within the original eight-runtime-path and
approximately 350-added-runtime-line budget. No new test, fixture,
framework, provider, proof, trust flag, cache, dependency, counter,
unsafe conversion or numeric executor is added.

Production changes remain confined to:

- `src/layout.rs`, `src/layout/projection.rs`, `src/layout/topology.rs`;
- `src/graph/root_structure.rs`;
- `src/scene_compiler/surface.rs`;
- `src/engine/splitter_geometry.rs`.

The independent reference changes only capture into its original owned
containers. Its complete traversal and arithmetic stay byte-identical.
Existing test names/counts and semantic assertions remain; the two tests
belonging exclusively to the unretained axis candidate are not imported.
All original frame, central, raw DAG, late-error, Clone and 10k coverage
from the retained parent remains.

Both `src/docking_cost.rs` and `src/layout/layout_cost.rs` are entirely
unchanged, including their untimed validation. Capture, checked mutation,
fresh leaf input, complete projection/export, clocks, schemas and
measurement protocol remain exact retained-parent bytes.

Independent source review at `/tmp/packed-child-results-review.md`,
SHA-256 `0efa11d91e814c8fe7e3a542c56def46a98cbd8e3df1d3e2d757d93938bcc566`,
reported no Rust source blocker and identified a metadata sorting mismatch.
This package now computes set digests using ascending UTF-8 relative-path
strings, as declared, rather than Python Path component order:
base `0e00253f20d62bddb4b3b0cbe0006fb9cb1b506087156ac4a609f391883a3035`,
tree `20e9c516e5d36a78fa39e83d65506b0cec47a0d43f294209cebf84285ac0b840`.
All individual source hashes, source bytes and candidate.patch are unchanged.
The README, manifest and READY bindings were refreshed and rechecked.
The copied original package remains historical input with its original bytes.

`scope-checks.json` records 76 static preservation checks, including all
immutable base hashes; full checked entry and numeric functions; retained
weight selection; absence of axis wire/tests; unchanged reference execution
and probes; original packed-tree equality outside the two axis-dependent
files; and source budgets. Exact patch reconstruction and read-only
`git apply --check --whitespace=error` in the temporary base also pass.
These are source checks, not Rust compilation or behavioral evidence.

## Negative costs and review

Three published result buffers do not mean three allocations overall.
The generic output scratch is an additional possible allocation.
Binary/nary temporary zero initialization and actual-extent copies are
additional work; raw repeated split visits copy again. Minimum-only
NodeResult initialization retains its existing cost.

Every edge reserves an Option gap slot, including final children.
Discriminants, padding and wider strides can increase payload size,
Clone bandwidth and scalar-scan working sets. Gap reset stores and
temporary sizes also affect peak live memory. Scene resize facts still
need a continuous `Arc<[f64]>`; collecting that from records may involve
additional staging. No copy, allocation or output field is omitted from
the timed path or hidden in setup. No allocator share, byte saving or
performance gain is claimed.

`review-request.md` identifies the requested retained-difference reviewer,
`root_frontier_placement`. Review should verify the three context
adaptations and full checked entry, plus the unchanged packed invariants.
Root must subsequently qualify complete oracle values and errors,
raw shared-parent/last-write behavior, both axes and arbitrary arity,
minimum-only projection/discard, old-output lifetime and full operation
comparisons. This package is stationary and not qualified.
