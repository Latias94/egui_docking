# Packed parent-edge projection results

READY / source stationary / not qualified. This is a temporary source candidate,
not an applied repository change or a performance result. Root is the sole
owner of compilation, behavioral qualification, timing and retention. No Cargo,
compiler, test, runner, benchmark, timing, profile, network or child agent was
used here. Only files under this new directory were written. Repository, fork,
cache and previous candidates remain unchanged.

## Exact parent and source package

The parent is `/tmp/committed-axis-inputs-unified/tree`, whose candidate patch
is SHA-256
`8098b3d4c0a6aa190c1d31ef38fc01efec8ee6954fb5018316c06b441943ff03`.
All five files in that parent's manifest were checked against their exact
candidate hashes before copying. Thus the parent includes unified fresh
NodeResults, the scalar central frontier, release first-visit prefix rejection,
compact continuation frames, binary inputs and the private committed/raw axis
validation wire. It excludes the rejected slab and childrows variants.

That parent artifact contains five complete files. Other required consumers
were captured once from the live repository into this package's immutable
`base/`: graph root structure, scene surface compiler, splitter geometry and its
tests, public layout tests, and both cost probes. Their exact byte hashes and
origins are recorded in `base-manifest.json`. Later repository progress is not
part of this frozen package. Apply matching hunks, not complete-file replacement.

The copied parent manifest, READY and independent review, and the independent
three-buffer design challenge are under `inputs/`. They bind the inputs; they
do not constitute independent review or executed qualification of this candidate.
`base/` and `tree/` contain all thirteen source pairs, including unchanged probes.
`candidate.patch` contains only this ownership slice.

## Interface and implementation

The output keeps the existing `NodeMap<NodeResult>` and separate SplitOutcome
vector. Only four backing arrays are replaced: the minimum, maximum and actual
child-extent vectors plus the stored gap-rectangle vector become one E-entry
parent-edge vector. A ChildProjection owns four freshly materialized fields:

- minimum and maximum f64 extents along its parent split's axis;
- the solver's actual f64 extent;
- `following_gap: Option<LogicalRect>`, with a stored gap after every nonfinal
  child and no gap after the final child in a successful projection.

`SplitProjection.children: &[ChildProjection]` is the common borrowed Interface.
`splitter_rects()` iterates stored optional rectangles; it performs no geometry
or allocation. The old three f64 slice fields and rectangle slice are removed.
There is no replacement compatibility slice family, lazy min/max derivation,
rectangle-to-extent reconstruction, proof, trust flag, cache, provider,
dependency, unsafe conversion or numeric-storage abstraction.

NodeMap, NodeResult, complete-key lookup, sorted/preorder node iteration and
the separate split-outcome ordinal remain unchanged. SplitMap's logical
identity-ordered equality and iteration still join each split's own edge range;
they do not compare raw physical edge-vector order. This matters because raw
and committed compilation allocate edge ranges in different traversal phases.
Clone copies the owned node, outcome and edge buffers while retaining immutable
graph structure through the existing Arcs.

## One unchanged numerical solver

Every numerical function is byte-identical to the parent, including public
solve_axis, solve_validated_axis_into, desired sizes, grow/shrink redistribution,
capacity, bounded delta, both assigned-size sums, tolerance and checked sums.
The full/raw/selected-override validation and committed extent-only selection
stay at their original prepare position.

After that same validation, binary splits use a local zero-initialized
`[f64; 2]`. Other arities clear and zero-resize one `ProjectionScratch.sizes`
Vec, reusing capacity across successive splits. Both branches call the same
existing solver with a contiguous mutable f64 slice. On success, every solved
extent is immediately copied into its parent-edge record before descending.
The scratch is not borrowed by a continuation or output. Mixed arities may
reuse old capacity, but clearing and zero-resizing prevent stale lengths or
values from entering the solve.

This deliberately adds temporary initialization and E actual-extent copies
per ordinary tree projection; raw repeated split visits add copies per visit.
All work remains inside projection and the existing timer. No temporary sizes
work is moved into fixture setup or advertised as free. Binary output scratch
has no heap allocation; general arity may allocate another temporary vector.

Minimum and maximum extents are stored during the original prepare phase from
the same axis constraints. The prepare loop resets following gaps to None.
The same pending-child continuation then adds the original solved extent,
constructs each gap only after its descendant returns, stores Some(rect), and
advances by the original splitter thickness. No geometric arithmetic, loop
order, constraint reduction, error label or central routing changes.

## Root and raw-draft behavior

Results belong to parent-edge occurrences, not unique child rows. Raw DAGs
therefore retain independent allocations under distinct parents, including
different axes. A repeated visit of the same split rewrites that split's own
edge range and outcome, preserving last-write semantics. Its incoming parents'
edge results remain independent. Cycles still fail in the original raw checked
compiler. Failed private partial projections do not publish or change older
owned outputs.

The graph RootNodeKind split gap range and RootStructure stored gap count have
no remaining consumers and are removed from both the actual builder and raw
compiler. The split ordinal, split_rows directory, missing-node checks,
placement callbacks, capacity hints and all local splitter-count arithmetic
and typed errors remain. Raw compilation differs only by those three dead
bookkeeping lines. No runtime traversal or validator is deleted.

## Vertical caller migration

Six production files change:

1. `layout/projection.rs`: materialized child records and borrowed split view.
2. `layout.rs`: output initialization, temporary solved sizes, edge writes and
   reads, with unchanged solver and arithmetic.
3. `layout/topology.rs`: remove unused raw gap-directory bookkeeping only.
4. `graph/root_structure.rs`: remove unused gap-directory bookkeeping only.
5. `scene_compiler/surface.rs`: read ordered records, adapt neighboring gap hit
   geometry, and collect continuous resize extents.
6. `engine/splitter_geometry.rs`: direct record comparisons, complete gap-shape
   checks, indexed min/max access and the existing frozen resize-array gathers.

The scene compiler still creates one continuous `Arc<[f64]>` per rendered split
and shares it between that split's records. It now collects fresh stored
extents from ChildProjection records. This may entail a staging allocation in
the standard iterator-to-Arc construction; that cost is not hidden or claimed
absent. No per-gap slice compatibility copy is introduced. SceneRecord and
interaction frozen-array Interfaces stay unchanged.

The independent `layout/reference.rs` changes only its capture adapter; all
reference types, traversal, raw compiler and numerical executor are unchanged.
Four existing test files receive mechanical field/iterator assertions.
Registered test names/counts and expected numeric/diagnostic assertions remain.
The owner-reference placement oracle drops only its deleted gap-range binding
and that range's now-obsolete length assertion; all its placement checks remain.
No framework, new tests, mirrored implementation tests or fixture is added.

The complete `docking_cost.rs` and `layout/layout_cost.rs` are byte-identical
base/tree context files. Their split count/outcome reads still use unchanged
SplitMap methods, so even their untimed checks require no changes. Timed
capture/apply/project inputs, fresh leaf collection, export, clocks, sample
protocols and schemas are untouched.

## Source checks and qualification still required

`scope-checks.json` records 54 static preservation checks, including exact
parent binding; byte-identical numerical functions, constraints, metrics and
central/prefix blocks; unchanged independent reference execution; exact
bookkeeping-only topology changes; unchanged cost probes; and path/line budgets.
The patch reconstructs every tree file exactly from base and passes read-only
`git apply --check --whitespace=error` in the temporary base. Only changed tmp
Rust sources were formatted, edition 2024 with skip_children=true. These checks
do not compile or execute Rust.

The patch has eleven paths: six production files (+138/-105), one cfg(test) oracle
capture (+12/-4) and four test files (+75/-35), for +225/-144 overall. This is
below the eight-runtime-path and approximately 350-added-runtime-line budgets.
Complete per-file hashes, byte counts, diff counts and ordered path-set hashes
are in `manifest.json`; READY binds that manifest and the artifacts.

Root should retain the existing independent oracle matrix, central/override
validation and error priorities, raw shared-subtree and last-write cases,
mixed/n-ary/binary constraints, overflow/unallocated, both axes, compressed gaps,
old-output/Clone after graph destruction, sparse generation ordering, delayed
minimums and discard, release prefix rejection, late descendant-versus-gap
errors, and genuine 10k-depth tests. Source preservation is not a substitute
for these checks or complete formal comparisons.

## Negative costs and limits

There are three published numeric/result buffers per root, not necessarily
three allocations overall. Empty buffers need not allocate, and measurement
gather, eligible indices, generic inputs, frame stack, leaf inputs and all-root
output ownership remain. The new general-size scratch can be another owner.

An E-entry record reserves an Option rectangle slot even for each final child,
unlike the former G-entry gap vector. Its discriminant/alignment may enlarge
stride; scalar-only scans now traverse wider records. Default initialization,
gap resets, repeated zero initialization, solved-value copying, Clone bandwidth,
scene resize-Arc gathering and peak live memory can cost more than the removed
owners save. Measurement-only NodeResult initialization remains the parent's
negative cost; it is not improved here. No allocation-byte saving, allocator
time share, throughput gain or goal progress is established.

Keep or reject only from root's complete source-bound qualification and paired
operation comparisons, including general arity, large roots, tails and four
views. This candidate is stationary and ready for independent source review;
it is not qualified.
