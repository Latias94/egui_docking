# Append shared-store attribution to the existing work probe

Status: TEMPORARY PATCH READY, 2026-11-07. No repository source edit, patch application, Cargo/compiler/test execution, benchmark or timing. Only this temporary proposed Rust file was formatted. Root should first measure/qualify export-reader independently, then combine this optional work-probe addition with candidate-copy.

`docking-work-storage.patch` changes only the body of the existing ignored `docking_cost::docking_work` test. Its exact input is `/tmp/export-reader/tree/crates/dockspace/src/docking_cost.rs`, after the leaf-reader and proposed export-reader changes. That source has SHA-256 `5874ffaf0a9f80e75d07b22ca28a031789bcbe865dda6613d6b93a6a159b6b83`. It is intentionally not based on the older currently live leaf-only file (`c5186bac…`). `base/`, `proposed/`, `base-sha256.json` and `proposed-sha256.json` retain the exact bytes.

Output source SHA-256: `28ecb77733c55d60c85704cd89e85e24ab41fb6d851cdfc00e8cc6fb217ddaac`.

Patch SHA-256: `ce38928cd72080e77526e63955ce5670e31063375e2348b2f16f8973002a1801`.

The patch requires candidate-copy's existing `StructuralWorkMetrics.workspace_storage` fields. The reviewed dependency is `candidate-copy/proposed/crates/dockspace/src/drop_resolver.rs`, SHA-256 `29f12e3077eb850875b977864d1130a892bfc1fbf8ad2e3873dc6cefa3feff8a`. It adds no counters, fallback zero values, new probe, configuration, dependency or test Framework.

## Schema and sample semantics

The original ten work columns remain in the same order and use the same expressions:

`panes,views,case,fingerprint_builds,fingerprint_node_visits,item_multiset_scans,item_multiset_item_visits,transaction_candidates,cloned_nodes,cloned_tab_items`

`cloned_nodes` and `cloned_tab_items` remain logical source inventory at explicit transaction-fork sites. Sharing does not zero those N-sized counts or convert them into physical Vec-copy counts.

Exactly ten columns are appended, in existing counter-field order:

| Appended column | Meaning |
| --- | --- |
| `node_store_forks` | Actual NodeStore Clone calls since reset. |
| `node_handle_clones` | Live Node Arc handles copied by those forks; not vacant slots or allocation bytes. |
| `mru_store_forks` | Actual TabMruStore Clone calls since reset. |
| `mru_handle_clones` | Live MRU Arc handles copied by those forks. |
| `node_payload_clones` | Actual Node::clone calls, including COW detachment, owned Builder returns or other explicit Node value clones in the sample. |
| `tab_item_copies` | Tab item elements copied by those Node Clone calls. |
| `split_child_copies` | Child ID elements copied by those Node Clone calls. |
| `split_weight_copies` | Weight elements copied by those Node Clone calls. |
| `mru_payload_clones` | Actual shared-store TabMru Clone calls; unique mutable access does not invoke Clone. |
| `mru_item_copies` | Elements copied by those shared-store MRU Clone calls. |

These fields do not count new payload construction, arbitrary domain Vec snapshots, fingerprint/output materialization, allocator events, reference-count decrements, whole SlotMap extent, map entries or placement-directory copying. They are exact counters for their named events, not a total memory-traffic metric or an inferred timing breakdown.

The existing fixture stays outside reset. The original `measure` call runs once per selected cell; snapshot remains immediately afterward and before validation, fixture destruction and expected-state checks. Consequently the new fields cover events during the same complete request/mutation/layout/export sample as the existing work counters, not mutation alone. With default size/view/case settings, the same loops still produce 21 cells (three sizes × three cases at one view plus four cases at four views). Environment filtering retains its old behavior.

The work probe still requires compilation **without** `DOCKSPACE_BENCH_NO_WORK_COUNTERS`. Its counters are separate attribution evidence; its elapsed fields are not a formal timing result. The formal `docking_cost` timing test, its CSV schema, compile-environment requirement, warmups/samples, timers, complete projection/export and all functions before `docking_work` are byte-identical to this export-reader input. No assertion or fixture size changes.

## Static checks and remaining verification

Read back the unified diff and checked that all bytes before `fn docking_work()` are unchanged; the header is the original ten-field prefix plus ten appended names. Existing reset, measure and snapshot expressions are unchanged. Direct rustfmt parsed this temporary source. No generated CSV or per-cell counter result is claimed. Root owns applying after the correct export/copy dependencies, ordinary serial compilation, executing the existing work probe and inspecting its actual 21-cell CSV.
