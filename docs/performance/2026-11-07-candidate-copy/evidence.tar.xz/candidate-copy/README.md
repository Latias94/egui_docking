# Candidate payload sharing with the existing generational allocator

Status: TEMPORARY PATCH READY, 2026-11-07. Based on A1 commit `ecf78bacbdffdfb51f4a57c3f95073a71898a826`. Repository source was only read. The concurrent leaf-reader changes are outside this file set. No patch was applied, and no Cargo, compiler, test, benchmark, timing or Git mutation was run. Direct rustfmt parsed/formatted only the temporary proposed copies; that does not establish type correctness or passing tests.

Root reports mutation around 76–79 µs at 1024 panes before this proposal. That result motivates the copy slice; it is not evidence of this unapplied candidate's performance. The complete 2× goal remains open.

## Recommendation and alternatives

Use one layer of immutable canonical Node/MRU payload sharing, while independently cloning the existing SlotMap allocator and small maps. Keep `Workspace::node/nodes/tab_mru` unchanged. Add two concrete internal stores so the existing graph owner can continue reading values and requesting mutable values; the stores own `Arc::make_mut`. This achieves Locality for isolation rather than exposing Arc handling across every writer, validator, reference solver and raw diagnostic fixture.

| Representation | What a candidate fork actually does | Choice |
| --- | --- | --- |
| Arc around all WorkspaceData or the whole node arena | Cheap fork, then the first ordinary mutation copies the complete shared container and all owned Vec payloads | Does not address this operation's first write. |
| Root-sized sharing | Copies the affected root's payload on edit; a one-view workload still copies essentially the whole graph | Wider ownership/locator work, weak leverage for the present case. |
| **Node/MRU payload sharing, stock SlotMap** | Copies allocator/map/directory metadata and live handles; clones only payloads requested mutably while shared | The proposed bounded slice. Preserves current generational allocation and the actual executor. |
| Paged persistent arena | Could avoid the remaining whole-slot metadata copy | Separate allocator/generation/drop design; unnecessary to establish this first result. |

The wrappers are typed NodeStore and TabMruStore, not a generic provider, reusable mutation protocol, completed-state cache or dirty bit. They contain the normative data itself. Workspace's closed publishing owner and A1 authority rules are unchanged.

## Concrete representation and Interface

`graph/shared_storage.rs` contains:

```rust
struct NodeStore {
    slots: SlotMap<NodeId, Arc<Node>>,
}

struct TabMru(Vec<ItemId>);
struct TabMruStore {
    entries: BTreeMap<NodeId, Arc<TabMru>>,
}
```

TabMru is a Vec newtype with the same runtime payload shape. It lets the existing test-only ledger count its actual Clone event. It adds no second Vec, shadow row, handle layer or allocation beyond the single Arc which an `Arc<Vec<ItemId>>` representation would require. Its only logical value is that one canonical MRU permutation.

NodeStore read/iteration methods yield `&Node`; TabMruStore yields `&Vec<ItemId>` so existing `Vec::as_slice`, validation and MRU consumers remain ordinary value readers. NodeStore's `get_mut` and TabMruStore's `get_mut` apply `Arc::make_mut` before returning the normal mutable value. Neither store exposes DerefMut to its underlying container or mutable Arc handles. All existing partial writes, including raw Builder fixtures, therefore copy a shared payload before writing it. The concrete owner still decides legality, placement and issuance; storage sharing does not authorize commands.

Only the map methods already needed by the owner/readers are present: get/get_mut, insert/replace/remove, read retain, iter/values/keys and node len/capacity/contains_key. NodeStore does not emulate all SlotMap APIs. The sole raw IndexMut fixture changes to `get_mut` rather than adding an indexing compatibility Interface. The sole `for &NodeStore` loop changes to `.iter()` rather than implementing another iterator family.

WorkspaceData's root/surface/contained maps, A1 root refs and normative placement directory remain as they are. No NodeId, root identity, public Node value shape, query signature, serialization format, command Interface, policy behavior or engine publication barrier changes.

## Ownership, retirement and replacement

`WorkspaceData::clone` clones each store's underlying allocator/map independently. Stock SlotMap Clone copies its slots and retains their complete generations, free head and element count (`slotmap-1.1.1/src/basic.rs:967`). It does not share allocator mutation between candidates. Only live immutable Node values and each MRU Vec share. Two branches may allocate the same numeric key exactly as before; A1 exact root issuance still distinguishes command authority. NodeId alone gains no cross-branch permission.

Removal returns `Arc<Node>` internally, so removing an empty source, flattened split or retired root does not first copy the values it is discarding. `remove_subtree_nodes` inspects a removed handle by reference and copies its child IDs into the existing iterative work stack. It does not unwrap/clone the entire removed payload. Root placement is still forgotten by the same owner helpers.

Whole-record replacement takes a new Node and swaps one handle. The canonicalizer has already constructed its complete replacement child/weight vectors; requesting `get_mut` merely to overwrite the old Node would copy a discarded shared split unnecessarily. Its one whole-record write therefore uses `replace`. The old `WorkspaceBuilder::replace_node -> Result<Node, ...>` owned-return contract remains: `Arc::unwrap_or_clone` returns the old Node directly when unique, or genuinely copies it when another owner must retain it. That required copy is counted by the actual Node Clone hook.

Both retain methods give their predicates immutable values. Canonical reachability sweeping thus drops unreachable handles without detaching every retained Node or MRU. Removing an MRU returns only presence because no production caller consumes its old Vec. The one raw generation fixture explicitly reads/clones its required value before removal; it no longer asks removal to materialize an old Vec which most callers discard.

Node/MRU handles never own descendant Node handles: children remain flat NodeIds. Clone and drop do not introduce a recursive Arc tree. The existing iterative 10k-depth behavior remains relevant for qualification.

## Exact patch scope and caller migration

Nine files, seven existing plus two new. At generation the main patch is +575/−39 lines; 306 added lines are seven real tests, and 141 are the two concrete stores.

| File under `crates/dockspace/src/` | Change |
| --- | --- |
| `graph.rs` | Replace raw node/MRU containers with their concrete stores; preserve value read methods; count actual Node Clone; return removed handles; retain Builder's owned replacement result; register the stores/tests. |
| `graph/shared_storage.rs` (new) | One shared normative Node allocation and one shared MRU allocation per record; private containers; actual COW and cheap retirement/replacement; immutable retain. |
| `graph/copy_tests.rs` (new) | Sharing/copy frontier, unique follow-up, Builder isolation/return, non-copying sweep/removal, rollback and complete-generation branch tests. |
| `canonical.rs` | Whole-record split replacement swaps a handle; one read loop uses `.iter()`; one malformed raw IndexMut fixture uses `get_mut`. Traversal, math, input/output gates, error ordering and root completion do not change. |
| `operation.rs` | Only retired-subtree consumption reads `Arc<Node>` and iterates borrowed child IDs. Every existing partial Node/MRU writer goes through the store's `get_mut` without individual executor rewrites. |
| `drop_resolver.rs` | Clarify legacy source-inventory semantics and add concrete store/payload counters. No resolver runtime behavior or baseline expectation changes. |
| `transaction.rs` | Clarify fork/sharing accounting documentation only. No prepared-report/candidate Interface change is included. |
| `operation/tests/local_selection.rs` | Raw slot-reuse fixture explicitly obtains its owned Node/MRU values. Original complete-generation and typed rejection assertions remain. |
| `operation/tests/owner_reference.rs` | Raw recycling fixture extracts a Node value from the removed handle. Original generation/membership/stale-index assertions remain. |

The unchanged `workspace.rs`, `validation.rs`, `layout/reference.rs`, graph authority and persistence read the same `&Node`/MRU values and existing container read methods. The partial raw writers in splitter/layout/compiler/engine fixtures still call the same `get_mut`, which now owns correct COW. No leaf-reader, layout, benchmark, persistence or output-lifecycle file is part of the patch. This is an internal representation change shared by all those callers, not a benchmark-only Adapter.

## Honest work ledger

Existing `workspace_deep_clones` / DeepCloneWork names are retained to avoid a broad baseline/schema migration. Their documented meaning is now **explicit Workspace fork count and logical source inventory**, not physical payload copying. N node occurrences and every source tab/child/MRU occurrence remain nonzero and retain the old expected values. The physical fork still traverses/copies metadata; it is not reported as O(1).

The new `StructuralWorkMetrics.workspace_storage` records concrete events:

| Field | Exact meaning |
| --- | --- |
| node_store_forks / mru_store_forks | Actual clone calls of those concrete stores since reset. |
| node_handle_clones / mru_handle_clones | Live Arc handles copied by those clones. Vacant slots and allocation capacity are not inferred from this number. |
| node_payload_clones | Actual Node::clone calls. Includes COW detachment, owned Builder returns, and explicit Node value clones after reset. |
| tab_item_copies / split_child_copies / split_weight_copies | Vec lengths copied by those actual Node Clone calls. |
| mru_payload_clones / mru_item_copies | Actual shared-store TabMru::clone calls and their copied Vec lengths. Unique `make_mut` does not trigger the hook. |

Counters sit in actual Clone implementations, rather than predicting copying from `strong_count` before an operation which might race with a reader dropping its handle. They include fixture copies made after a reset, so attribution setup must precede reset. MRU domain Vec snapshots, fingerprint materialization, newly constructed insertion/rewrite vectors, allocator events, authority/map/placement copies and temporary child-ID work stacks are outside these payload-detachment counters. They are not presented as absent or included in a total-byte metric.

All new hooks use the existing update closure and compile-environment bypass. In formal cost probes `DOCKSPACE_BENCH_NO_WORK_COUNTERS` remains required by the existing ignored timing test. No formal harness, CSV schema, workload, timer or bypass condition is modified here. Test counters are attribution evidence, not a timing substitute.

For the new populated-source center fixture, one public apply still forks N live node handles and four MRU handles. The prediction asserted by its unrun test is two Node payload clones (four original tab elements) and two MRU payload clones (four history elements), with untouched split/other-root payload pointers shared. A subsequent owned Select on that already unique target should copy no payload. This does not predict that all commands, no-ops, edge repairs or general programs have the same frontier. Existing equal reselection/resize writers may request mutable access even for an equal value, causing real local detachment which is honestly counted.

## Behavior and failure contracts

The normal checked executor, local finisher and cold/general paths are unchanged. Atomic batch, one-final-normalization, exact float errors, selected-first MRU, current policy, source/target independence, rootrefs and normative placement retain their existing owners. A failure drops only that candidate's copied maps/slots and modified shared payloads; the original allocator and payloads remain untouched. A prepared candidate can outlive or be discarded independently of live/other prepared candidates. Old WorkspaceSnapshots and output facts retain immutable values. No engine/native/presentation barrier is removed or replaced by storage sharing.

Builder raw input remains unissued; its COW mutation cannot modify a still-issued Workspace clone. Build/import still canonicalizes and validates through the original complete path, then issues fresh root authority. Missing/extra/malformed MRU remains representable because the separate MRU table is retained. Full value equality still compares exact live NodeIds and Node/MRU values, not Arc pointer identity as command authority. Immutable MRU handles can short-circuit exact Eq safely; command refs remain the A1 issuance protocol.

## Tests provided and qualification required

Seven proposed unit tests exercise the normal owner or raw Builder Seam:

1. A full Workspace fork keeps each Node/MRU address shared, reports N/four handle copies and zero payload copies.
2. A real Item center move copies exactly its two Node/MRU payloads, keeps unrelated payloads/authority, rejects an old affected-root ref, and leaves the original values intact. A real owned Select follow-up on the unique result copies none.
3. Raw Builder node selection and MRU edits detach shared values, leave the issued Workspace untouched, preserve unrelated sharing and receive fresh authority after build.
4. Canonical no-op plus actual immutable retain/removal copies no retained/discarded payload, while the original Workspace remains valid.
5. Builder replace preserves its owned previous Node result; the necessary old-value copy is recorded exactly once and unrelated payloads stay shared.
6. A real second-command batch failure after movement discards candidate payload changes; original values, addresses and exact refs survive, then the same move can be retried successfully.
7. A cloned Builder removes/reuses a slot while retaining the issued original; complete old/new generations remain independent, missing/stale capture behavior holds, unrelated payloads stay shared and both completed graphs validate.

These tests have not run. Root should first typecheck all features/tests, then execute these tests and the existing local Item/general report+MRU matrix, selection property cases, owner/index/stage/ABA tests, both exact-f32 witnesses and deep/layout reference oracles. Preserve full workspace/native/old-output/host-frame drop and prepared-candidate uniqueness coverage. Existing suites supply the broad barriers; no new engine harness is copied here. Then run the unchanged production-profile complete workload and allocations, including old-Workspace release during public apply, state exports and complete rich projection.

## Costs and remaining questions

- Each Node and MRU now has an extra Arc allocation/header; it is one allocation per normative payload, not one per reference. Building/importing an initially unique Workspace therefore has a real new resource cost, even when fixture setup is outside a particular kernel timer.
- Every live Node/MRU handle clone and drop performs reference-count work. The SlotMap slot buffer and BTreeMap structures still copy; root maps and SparseSecondaryMap placement still copy. SlotMap Clone follows initialized slot extent, including holes, not just the N live handles counted above.
- Reads add pointer indirection to graph and full layout/export traversal. Whether lower copy volume outweighs cache/pointer and atomic costs must be measured in the complete workload, not inferred from the two-Node frontier.
- Each live candidate owns a copied allocator/map/directory and retained old payload handles; only the first edited payloads duplicate their content. Memory accounting must include concurrent candidates and original snapshots, plus unreleased old vectors.
- Publication still drops the replaced Workspace in the existing public apply interval. No destruction is deferred to outside the timer to manufacture a win. Discard/drop is iterative with flat IDs; this proposal does not add recursively owned child Arcs.
- Full Workspace comparisons remain unless the separate prepared-report slice is applied. Cold value snapshots/carrier discovery, layout, leaf-reader work and all current checks are unchanged. No 2× result, numeric gain or allocator-byte reduction is claimed from source alone.

## Applying after the separate prepared-report slice

Use exactly one copy patch:

- `candidate-copy.patch` applies to the nine A1 base paths listed in `base-sha256.json` (null means the new file must be absent).
- `candidate-copy-after-prepared-report.patch` applies after the earlier prepared-report patch whose SHA-256 is `1b0a17402068d3b2d782bbe5e39538cb3366e30f6b0a45e95236293e815425b9`. Its exact input hashes are `after-prepared-report-base-sha256.json`.

The second variant was composed solely in temporary copies by comparing both slices to their exact shared base and merging nonoverlapping line edits. No overlapping edit was found. `after-prepared-report/` contains the nine combined outputs and `after-prepared-report-sha256.json` their bytes. This is source composition evidence, not a compiler or `git apply` check. New tests call public apply and do not depend on the old `into_parts(original)` contract. Leaf-reader files are outside both patches.

Primary copy patch SHA-256: `fc848142b380c6eeb7411c8da3e49b371f039127eae75c181ad05ff31e3ae1b4`.

Copy-after-report patch SHA-256: `9a4e41c222741a944e23ddaf5a45e21a27bd2cec9d76646abe9937116342e2dd`.

## A1 input hashes

| Path under `crates/dockspace/src/` | SHA-256 |
| --- | --- |
| `graph.rs` | `de1db6457502140b905691e5e3a31f8164d53132389a33200c76480a68947f23` |
| `canonical.rs` | `949fc41b6dc693ae809803f6d89fb906e040eecb0526ddf4fe41b8167488e584` |
| `operation.rs` | `1af34d0400c32d0649a563ceb5c0d147aec36eca543fc4dd1ce33671281e92a8` |
| `drop_resolver.rs` | `57d8c465dfca14388ab26b99d1c13be586522559e05bf5d42d277419b78c0f44` |
| `transaction.rs` | `08d3f1324d95b38350be32d88490db67c22aff5e8120896f2ffd94aeb5e8a065` |
| `operation/tests/local_selection.rs` | `08c90b17f9caed5f1a7c77b6339b30582c6b84faa3459b6d3c167da607d25e47` |
| `operation/tests/owner_reference.rs` | `7d0dd09f1404aa51b7c691297c286b9d5b85d1762f498899b7b125fc58a5174f` |
| `graph/shared_storage.rs` | New, must be absent. |
| `graph/copy_tests.rs` | New, must be absent. |

`base/` and `proposed/` retain exact copies. `proposed-sha256.json`, `contract-sha256.json` and `patch-stat.json` record proposed bytes, unchanged reader/authority dependencies and the file inventory. Only root may apply and qualify this slice after its current verification/frozen comparison.
