"""Apply the exact reviewed shared-payload slice after report qualification."""
from pathlib import Path
import hashlib,json,subprocess
base=Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
root=Path('/Users/frankorz/codes/rust/egui_docking')
copy=base/'candidate-copy'
for name,value in json.loads((copy/'after-prepared-report-base-sha256.json').read_text()).items():
 p=root/name
 assert (not p.exists()) if value is None else hashlib.sha256(p.read_bytes()).hexdigest()==value,name
for patch in (copy/'candidate-copy-after-prepared-report.patch',copy/'copy-tests-precise-late-failure.patch',copy/'work-csv/docking-work-storage.patch'):
 subprocess.run(['git','apply','--check',str(patch)],cwd=root,check=True)
 subprocess.run(['git','apply',str(patch)],cwd=root,check=True)
print('Reviewed copy slice and exact late-error/work-counter additions applied',flush=True)
