# Tabs-owned MRU vertical candidate

Status: **READY for root-owned source review, integration and serial qualification. Not compiled, tested, benchmarked or timed.** All candidate changes are confined to `/tmp/tabs-owned-mru/`; the repository and the previous RootStructure candidate were not edited. Source preparation is complete and stationary after this receipt.

## Frozen inputs and artifacts

This is a vertical patch against the actual repository snapshot captured in `base-hashes.json`: graph-owned RootStructure, the three successful-body-build counters, and the test-scope fully qualified Arc correction were already present. No NodeResult, numerical slab, frame or other temporary candidate is included. `base/` is the exact captured source; `tree/` is the complete candidate tree. The snapshot includes the workspace's Rust and manifest files so the public enum migration can be audited beyond one module.

- Patch: `tabs-owned-mru.patch`.
- Patch SHA-256: `1ea14af6f5cdcefea0bb170390dbad8270f3fd845c1cbe975a27d3830b13e9d8`.
- Patch size: 53,005 bytes across 23 existing Rust paths.
- Candidate changed-path set SHA-256: `c8a7a84b82b864ec9bad17a7e78058c4996d74809b72f865f2015ec7a7b45707`.
- `candidate-hashes.json` records the exact base/candidate hash of every changed file and the set-hash format.
- `scope-checks.json` records static unchanged-boundary checks; `patch-dry-run.txt` records zero-fuzz dry-run application to the captured baseline.
- At the source comparison, all 23 changed paths in the live repository matched the exact baseline. See `live-base-drift.json`; future writes require another hash check.

This is an independent candidate, not an instruction to overwrite complete files from `tree/`. Compose later overlapping work by hunks against verified bases.

## Feasibility and the single owner

The change is feasible without a compatibility layer. MRU is already part of the same durable Tabs semantics as visual order and selected state. The previous `BTreeMap<NodeId, Arc<TabMru>>` adds another allocator owner and a directory for a value that has exactly one owning Tabs node. Placing its Vec in that Node removes the second persistent representation and its node-to-history join.

The graph Module now owns this complete value:

```rust
pub enum Node {
    Tabs {
        items: Vec<ItemId>,
        selected: Option<ItemId>,
        mru: Vec<ItemId>,
    },
    Split {
        axis: Axis,
        children: Vec<NodeId>,
        weights: Vec<SplitWeight>,
    },
}
```

The existing `NodeStore: SlotMap<NodeId, Arc<Node>>` is the only COW channel. `WorkspaceData` has no MRU map. A clone of a Workspace copies the existing node handles, authority and placement collections; it no longer also clones a BTreeMap of MRU handles. A Tabs COW detaches items, selected and history together. Mutating one field cannot leave a separately owned history object behind.

The public Interface `Workspace::node(id) -> Option<&Node>` stays borrowed. The required `Workspace::tab_mru(tabs) -> Option<&[ItemId]>` stays available and performs one generational node lookup, returning the field for Tabs and `None` for missing/Split nodes. Exact `Node::Tabs` patterns gain the new field or use `..`; literals supply the full value. No compatibility alias or fallback MRU map is added.

The RootStructure Module is unchanged. Its Tabs row still retains only the complete NodeId, never a Tabs Arc. Select, nonempty center Item Move, rehome and other Tabs-only changes can continue sharing root structural bodies; the old geometry does not retain historical items or MRU. Split rows still share only actual Split Arcs. This preserves the architecture's Separation of structural ownership and current command binding.

## Concrete writes and Builder semantics

Select/approved-close successor selection borrows `selected` and `mru` from one mutable Tabs and performs the same promotion. Remove borrows items/selected/MRU together, removes the same visual item and history entry, and chooses the same surviving MRU head. Insert/merge uses one target Tabs borrow and preserves the existing target-local history rule. Merging into an empty central leaf still copies the source's entire history in its exact order. Clearing a merged source clears all three fields on that source value.

The existing transient `DetachedPayload::Node` still carries selected/history facts for the one checked command. It is not a second persistent authority or cache. Its existing domain Vec copies are not newly claimed as Node COW counts. Edge relocation still transfers the existing Node identity with its history; complete-root rehome changes no Tabs payload. Root-local repair, canonical split rewriting and exact issuance completion remain the existing executor.

The Builder Interface deliberately treats replacement as replacement of a complete value:

```rust
let mut draft = workspace.clone().into_builder();
let previous: Node = draft.replace_node(tabs, Node::Tabs {
    items: vec![a, b, c],
    selected: Some(b),
    mru: vec![b, c, a],
})?;
draft.set_tab_mru(tabs, [b, a, c])?;
let completed = draft.build()?;
```

`Node::tabs` and `tabs_with_selection` construct the same initial selected-first history previously constructed on insertion/replacement. The exact initial ordering helper is retained, including malformed-selection input behavior before validation. `insert_node` now installs the complete supplied Node directly. `replace_node` installs its full supplied history and returns the full previous history; it does not reconstruct or silently discard an explicit permutation. Callers wanting initial history use the constructors. This explicit public enum/value change is the intended breaking migration.

`set_tab_mru` remains a raw Builder edit accepting malformed history for the later validation pass. It uses the node COW channel, so changing only history in a shared Builder may now also copy the visual item Vec. A wrong-kind setter still returns `NodeIsNotTabs`; a missing/stale identity still returns `MissingNode`. A rejected wrong-kind edit may perform a payload COW before discovering the kind because it uses the same mutable lookup; durable values are unchanged and no sealed Workspace is published.

## Diagnostics and import protocol

The following representation errors are removed because the new type cannot express them:

- `WorkspaceValidationError::MissingTabMru`: every Tabs value contains a Vec, including an empty one.
- `WorkspaceValidationError::UnexpectedTabMru`: a Split/missing node cannot own a history field.
- `SnapshotCaptureError::MissingRuntimeTabMru`: capture destructures the field of the actual validated Tabs.

An empty history on a populated Tabs is still invalid. It produces the existing length/missing-member/selected-head diagnostics, rather than being treated as absent storage. Duplicates, foreign members, omitted items, wrong selected item, duplicate item ownership, empty noncentral leaves, topology, policy and presentation errors remain checked. The strict MRU diagnostic body after the short exact predicate is byte-for-byte unchanged: length, each duplicate/foreign entry in input order, each missing visual item, then selected/head. Selection/empty diagnostics still precede MRU diagnostics; global duplicate-item reporting follows them. The canonicalizer retains its prior selected-before-MRU-before-duplicate and split diagnostic ordering. Only the now-impossible detached-map validation/retention scans disappear.

The persistence Adapter keeps the existing Snapshot schema and version. `SnapshotNode::Tabs { items, selected, mru }`, serde tags/attributes, mandatory `mru` field and unknown-field rejection are unchanged. Capture reads all three fields from one Node. Restore constructs the complete Node directly, preserving the snapshot's exact history instead of making default history and then replacing a separate map entry. Existing identity/reference/scalar/item preflight is unchanged; malformed histories still reach strict validation. Missing persisted `mru` remains a serde error, and foreign history items still participate in the existing item preflight.

`WorkspaceData` equality now obtains MRU equality through `Node::PartialEq`; it no longer compares an independent history map. This retains complete Workspace value equality, including history differences used by general normalized-equal/no-op reporting. `RootReference`, source and target verification, strict ABA, batch failure ownership, staged capture barriers, native/close/rollback completion and selected provenance are unchanged. No unchecked production Workspace or second executor is introduced.

## Work attribution

Logical `WorkspaceCloneVolume::tab_mru_items` remains a sum of source history entries carried through the explicit Workspace fork. It is accumulated in the same node inventory loop as `tab_items`; it is not zeroed because the map disappeared. Logical inventory remains distinct from actual payload copying.

Physical `WorkspaceStorageWork::mru_item_copies` remains, but now runs inside the actual `Node::clone` hook and sums the Tabs MRU length copied by that full Node clone. This includes COW and an owned Builder return when shared payloads require a clone. It does not count arbitrary command-domain Vec copies, initial history construction, allocator calls, capacity, or bytes. A zero count cannot be used to assert zero history work or total allocation.

The independent `mru_store_forks`, `mru_handle_clones` and `mru_payload_clones` fields/hooks are deleted because those owners/events no longer exist. The ordinary work CSV removes exactly those three obsolete columns, going from the current 23 columns to 20 while retaining the remaining columns in order, including `mru_item_copies` and all three successful RootStructure output counters. No legacy zero-valued aliases remain. Consumers of the work CSV must read the new explicit header; archived older CSVs retain their original meaning.

The formal timing CSV is unchanged. The complete `docking_cost` function, its timing schema, fresh fixture, request/mutation/layout/export phase function and fresh N-leaf projection work compare unchanged. The measured exporter changes only its enum read pattern to ignore the new field; every output word and check is still produced inside the same boundaries. The old export oracle has the same mechanical pattern change. No input work is moved out of a timer, and no uniform constraint shortcut is introduced.

The existing test-ledger gate remains unchanged. The added MRU length accounting is inside `update`, so a disabled ledger does not traverse histories. None of these ordinary counters supplies a formal duration result.

## Source cost model and risks

The change deletes a whole BTreeMap clone per Workspace fork, its separately allocated map nodes, one Arc handle operation per Tabs, the separately allocated MRU Arc payload, and directory joins on MRU reads/writes. It also removes the raw map scan and retirement-filter pass. NodeStore arena/handle copying, authority-root map copying, placement copying and actual edited payload COW all remain.

The MRU Vec and its elements remain real storage. The Vec header moves into the Tabs variant; the independent Arc wrapper is removed. On a conventional 64-bit target a Vec header has three machine words, but the actual `Node` size depends on Rust enum layout, niches and padding. Adding the field can increase the size of every Node allocation, including Split allocations because enum size is shared. This candidate makes no measured size, allocation-count or latency claim. Root should inspect the pinned compiler's actual sizes when qualifying the candidate, without treating field sums as `size_of` evidence.

Source and target center Item Move still copy their real items and histories on COW; consolidation saves ownership/directory work rather than those Vec copies. A pure visual Reorder now copies history together with its Node even though the history order is unchanged; previously the separate MRU Arc could remain shared. A history-only Builder setter can similarly copy items. New owned `replace_node` returns now include history and can copy it. These tradeoffs are covered/documented rather than hidden as zero-copy behavior.

The expected asymptotic Workspace fork is still O(arena handles + placements + roots), with one fewer O(Tabs) BTreeMap clone. This could reduce fixed costs for 16 panes and larger center-move mutation costs, but the larger Node shape and coupled copies can offset it. There is no promise of an improvement or a twofold target. Normal resize uses no Workspace fork, so any resize effect would come through memory/layout locality, not a removed MRU-map clone in that operation. Phase medians must not be added into a synthetic total.

## Complete migration scope

All 23 files below are part of this patch; no changes to another crate are necessary because the remaining product consumers use the existing product views rather than exhaustively destructuring graph Tabs.

```text
crates/dockspace/src/canonical.rs
crates/dockspace/src/docking_cost.rs
crates/dockspace/src/drop_resolver.rs
crates/dockspace/src/engine/pointer_timed.rs
crates/dockspace/src/engine/tests/local_selection.rs
crates/dockspace/src/graph/copy_tests.rs
crates/dockspace/src/graph/shared_storage.rs
crates/dockspace/src/graph.rs
crates/dockspace/src/model/view.rs
crates/dockspace/src/operation/tests/local_selection.rs
crates/dockspace/src/operation/tests/logical_surfaces.rs
crates/dockspace/src/operation.rs
crates/dockspace/src/persistence.rs
crates/dockspace/src/scene/validation.rs
crates/dockspace/src/scene_compiler/future_layout.rs
crates/dockspace/src/scene_compiler/requirements.rs
crates/dockspace/src/scene_compiler/surface.rs
crates/dockspace/src/validation.rs
crates/dockspace/src/workspace.rs
crates/dockspace/tests/canonical_graph.rs
crates/dockspace/tests/command_sequences.rs
crates/dockspace/tests/open_gpui_drop_contract.rs
crates/dockspace/tests/persistence.rs
```

Deleted Implementation paths: `TabMru`, `TabMruStore`, its BTreeMap/Arc owner and all accessor/clone/retire/retain methods; `WorkspaceData.tab_mru`; map initialization/reset during insert/replace; separate removal during node retirement; unexpected-map-entry checks; fingerprint/selection/capture second MRU lookups; separate mutation helpers and the now-inlined `promote_tab_mru`; obsolete counter fields/hooks and CSV arguments. The private exact-MRU predicate takes a required slice, with no compatibility Option branch.

Scene compiler, view, pointer eligibility, scene validation and four existing behavior fixture files receive direct read-pattern migration. Stale/generation raw fixtures move the complete Node instead of manually transplanting the separate map entry. The two tests that removed MRU storage now install an empty, invalid history through the existing Builder setter; they still assert Builder rejection and preserve the staged/rollback assertions.

## Meaningful contract coverage

Existing registered graph copy tests are migrated to the actual new physical semantics. Workspace forks still prove shared payload identity and zero copied MRU elements; center Item Move still proves exactly the two edited Nodes and four history elements copied; a unique owned follow-up still proves zero Node/MRU copying; raw Builder writes, retirement, generation, exact stale issuance and late rollback keep their original assertions.

Two short registered graph tests are added:

- A three-item complete replacement with a non-default valid history proves replacement preserves supplied history, returns the exact previous history, supports an explicit later setter, and leaves the original Workspace's history intact.
- A real Reorder proves visual order changes, history order stays equal, one complete Tabs COW occurs, and its two history elements are honestly counted.

The existing explicit short-stack valid/invalid table and exact diagnostic vector remain, adapted only to a required slice/complete constructor. The registered `tests/tab_mru.rs` suite is unchanged and covers selection/reselection, close successor, reorder, Item moves, target-local merge, empty-central full-history merge, root rehome, and malformed histories. The serde behavior suite keeps mandatory/malformed history rejection, complete round-trip and deep import tests; its only file change is a read pattern. These files are registered by the actual `behavior_tests` module despite `autotests = false`; no claim relies on unregistered legacy tests.

Static checks preserve the complete independent layout oracle at SHA-256 `93afdf6e8ad79d81f2efdafc4814a4bb6076fd9f535129f82ce33f9ee12ddf4e`, all layout implementation/tests including the registered 10k test, `RootStructure`, owner references, transaction and command code. This MRU candidate does not share a new helper with the reference or alter any layout arithmetic.

## Verification and integration gate

Performed only: source audit, searches for removed owners/fields/callers, temporary-file rustfmt with module traversal disabled, static byte/block/hash comparisons and zero-fuzz patch dry-run. No Cargo, Rust/C++ compiler, behavior test, benchmark, timing, Git write, dependency, unsafe code or sub-agent was used. These checks establish patch/source shape, not successful typechecking or executed semantic equivalence. Root owns independent review, serial compilation/behavior/error/serde/native qualification and paired timing.

NodeResult remains separate. This patch does not modify layout result types or layout implementation. The expected overlap is mechanical enum patterns and the ordinary work CSV in `docking_cost.rs`, plus any simultaneous consumer migration. Compose by hunks and preserve both candidates' output and counter semantics; do not overwrite a newer complete file from this temporary tree.
