# Tabs-owned MRU rebased onto current single NodeResult

**READY / STOPPED — source preparation only, unapplied, uncompiled and untested.** All writes are under `/tmp/tabs-owned-mru-current/`. No repository, old candidate, cache or fork was modified. No Cargo, Rust compilation, behavior test, benchmark, timing, network, sub-agent or Git write was used. Rust best-practices was read in this session. Root owns verification; independent review of this rebase is pending.

## Exact inputs and deliverables

The base is the current repository's RootStructure + single NodeResult, including existing work counters and the test-scope Arc fix. No slab, frame, measurement-child-rows or fusion candidate is included. All 24 changed paths were captured before edits into `base/`, with their origins and hashes in `base-manifest.json`. `tree/` contains the matching complete outputs. Existing contracts are saved separately under `contracts/`.

- Original MRU patch: `/tmp/tabs-owned-mru/tabs-owned-mru.patch`, SHA-256 `1ea14af6f5cdcefea0bb170390dbad8270f3fd845c1cbe975a27d3830b13e9d8`, 23 paths / 53,005 bytes. Its original base and output files were checked against its frozen manifest before reuse. The original directory remains untouched.
- Rebased patch: `tabs-owned-mru-current.patch`, **24 paths, +318/-371, net -53**, 55,215 bytes. SHA-256: `9046e9d14bb92bdb7aab2e8935b08aa3f4f5849f135e1b0edef595f50f216c01`.
- Sorted 24-path input set: `e44e1de5699e9c436f79d04fdda74e7916d24b286949ec776fbd538662898d28`.
- Sorted 24-path output set: `7dde1e11eb8b9468b51d15570ba4848ab768a1706b7c1840559c127a3ad2cebd`.
- `manifest.json` gives every complete base/output hash, size and patch count. Set hashing is ascending UTF-8 path + NUL + per-file SHA-256 + newline.
- `rebase-hunks.json` records replay of the original 85 hunks and both explicit context resolutions. `scope-checks.json` records source comparisons. `READY.json` binds final receipts and the patch.

Apply the patch by hunks against these exact inputs or explicitly merge newer changes. Do not replace newer whole files with these copies.

## Only two context resolutions

The original patch has two failing hunks on the current base:

1. `docking_cost.rs`, original hunk at line 355: retain `projection.layout.nodes[&node].rect`, applying only the original Tabs pattern migration.
2. `scene_compiler/future_layout.rs`, original hunk at line 136: retain the current NodeResult lookup and its error context, applying only the original Tabs pattern migration.

All other hunks replayed with exact context. There are three changed baseline files, because `scene_compiler/surface.rs` also contains current SingleMap changes, although its MRU hunk applies directly. Twenty candidate files are byte-identical to the original MRU outputs. For the other three, the complete old-MRU-output to rebased-output difference is exactly the old-base to current-base SingleMap difference. This verifies retention of both changes rather than assuming that non-conflicting files were unchanged.

The captured unchanged layout sources explicitly exclude queued candidates: `layout.rs` is single-map SHA-256 `325f56f16cacbde46cce531461c8830417a6aa8ff4af06f6c87145a7528963df`; `layout/projection.rs` is `d86c008dd78c5f1ed805de76b71d102a29dd3dab4e6ee37ca8f3cb74839edfb0`. Production topology and RootStructure remain unchanged; the latter includes the existing completion counters.

## Supplied history-only regression

The one additional path is `crates/dockspace/src/operation/tests/owner_reference.rs`. Its previous complete source is unchanged; the supplied registered test is appended:

`staged_selection_roundtrip_publishes_history_only_change`

The three-item fixture selects `[3, 1]` through the actual stage. Selected returns to 1 while MRU becomes `[1, 3, 2]`. Existing supplied assertions require `changed=true`, both selected outcomes changed, unchanged visual order, exact new/old MRU, workspace inequality, rejection of the original source reference, and correct actual placement. No assertion or other non-whitespace source byte was changed. The containing `operation::tests::owner_reference` module is already registered.

- Supplied witness SHA-256: `3c2650549d3729f330a5b43cee013b26ac5f9e4b91bdef2afd7a6a3c09643fd9`.
- Formatted witness SHA-256: `e706198e5a8f0e996c6f6129b41a73f71f70d6a94d8a64a99d1f7265387d4bd6`, 53 lines plus one separating newline when appended.
- Both copies are included for exact review. No new helper, framework, generalized oracle or unrelated regression was added.

## Retained boundaries and remaining qualification

The MRU implementation is the original reviewed candidate: Tabs owns items/selected/history through the existing Node COW owner; no separate MRU map survives. Builder, persistence, validation, canonicalization, command operations and physical copy accounting retain all original candidate changes. This rebase adds no runtime behavior beyond that candidate.

Static byte comparisons preserve the entire fixture/request/fresh leaf projection prefix, complete current NodeResult owned exporter, phase timing function and formal `docking_cost` test/CSV. The entire ordinary `docking_work` function equals the original MRU output: 23 columns become 20 by removing only `mru_store_forks`, `mru_handle_clones` and `mru_payload_clones`. Logical inventory, `mru_item_copies`, and all three RootStructure output counters remain. Work-field removal is the original representation change, not a rebase simplification.

Direct rustfmt was limited to the two context-resolution copies and the supplied witness, with edition 2024 / `skip_children=true`. Static `git apply --check --whitespace=error` passed against this directory's `base/`; no patch was applied to the repository and no Git state was written. Exact hash, delta and source checks establish artifact shape, not successful typechecking or behavior.

The original candidate's cost tradeoffs still apply: deleting a persistent MRU map does not eliminate history elements, node-handle forks or actual Tabs payload COW. Reorder/history-only edits can copy items and history together; enum size can change. No allocation, latency or goal-attainment benefit is claimed. Root should obtain the independent rebase review and serial compilation/registered behavior/ownership/counter qualification before measurement. All source and patch bytes are now stationary.
