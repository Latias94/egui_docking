use dockspace::graph::Node;
use dockspace::layout::NodeResult;
fn main() {
    let node = Node::tabs([]);
    let Node::Tabs { items: _, selected: _, mru: _ } = node else { unreachable!() };
    println!("Node size={} align={}", std::mem::size_of::<Node>(), std::mem::align_of::<Node>());
    println!("NodeResult size={} align={}", std::mem::size_of::<NodeResult>(), std::mem::align_of::<NodeResult>());
}
