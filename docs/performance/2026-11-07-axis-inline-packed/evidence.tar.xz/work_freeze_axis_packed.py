"""Run the ordinary complete docking work probe, then freeze the verified candidate."""
import csv,datetime,json,os,subprocess
from pathlib import Path
root=Path('/Users/frankorz/codes/rust/egui_docking')
base=Path('/tmp/dockspace-imgui-twofold-20261107-ea4161e')
out=base/'axis-inline-packed-verified'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
env=dict(os.environ,CARGO_BUILD_JOBS='1',DOCKSPACE_DOCK_COST_OUT=str(out/'work.csv'))
env.pop('DOCKSPACE_BENCH_NO_WORK_COUNTERS',None)
command=['cargo','nextest','run','--package','dockspace','--lib','--all-features','--locked','--offline','-j1','-E','test(docking_work)','--run-ignored','only']
record={'command':command,'started_utc':now()}
with (out/'work.log').open('w') as f:r=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
record.update(returncode=r.returncode,finished_utc=now())
(out/'work-check.json').write_text(json.dumps(record,indent=2)+'\n')
assert r.returncode==0
with (out/'work.csv').open() as stream:
    rows=list(csv.DictReader(stream))
assert len(rows)==21 and len(rows[0])==20
assert (out/'work.csv').read_bytes()==(base/'exact-assigned-total-verified/work.csv').read_bytes()
assert all(int(row['completed_root_structures'])==int(row['case']=='edge_split') for row in rows)
summary={'ordinary_probe_21_cells':True,'expected_actual_root_builds_match':True,
         'actual_history_copy_counts_match':True,'complete_work_csv_matches_control':True,
         'work_csv_columns':20,'successful_bodies':sum(int(row['completed_root_structures']) for row in rows),
         'root_structure_rows':sum(int(row['root_structure_rows']) for row in rows),
         'scope':'logical successful graph-row and payload work; no allocator or capacity-byte claim'}
(out/'work-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert json.loads((out/'work-summary.json').read_text())==summary
subprocess.run(['python3',str(base/'freeze_axis_packed.py')],cwd=root,check=True)
