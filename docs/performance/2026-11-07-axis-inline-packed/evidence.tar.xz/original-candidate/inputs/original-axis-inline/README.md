# Axis-input validation with two ordinary inline hints

READY / source stationary / not qualified. This is a second measurable
implementation of the reviewed axis-input candidate, based entirely on
immutable `07f566ac8fbddfab819f46f613d55bc2069507dd`. It replays the complete
original two-file axis delta and adds only ordinary `#[inline]` hints to
`advance_split_projection` and `SplitMap::new`. It does not use inline(always).

Only this new temporary directory was written. No repository, fork, cache,
Git state, previous candidate, rejection report or evidence was changed.
No Cargo, compiler, formatter, test, runner, timing, benchmark, profiler,
network or child agent was used. Root owns independent review, execution,
qualification, comparison and retention.

## Exact source layers

The five complete files in `base/` were read from immutable 07f566a Git
blobs, not the live worktree. Every base hash matches the original reviewed
axis package's base. `base-manifest.json` records commit/path origins,
blob IDs, SHA-256 values and sizes.

The original axis patch is
`/tmp/committed-axis-inputs-unified/candidate.patch`,
SHA-256 `8098b3d4c0a6aa190c1d31ef38fc01efec8ee6954fb5018316c06b441943ff03`.
Its two changed files and fourteen hunks were replayed exactly in memory.
All five reconstructed files equal that package's tree byte for byte;
they are retained here under `axis/`.

`tree/` starts from that exact axis variant and adds the two attributes.
Both target functions were first checked to have no existing inline
attribute. Removing the added line at each precise declaration recreates
the complete original axis tree, including all whitespace and test bytes.

The copied original patch, manifest, READY, source review and README are
under `inputs/`, together with a frozen copy of the existing rejection
report. These copies preserve historical identities; they do not alter
the old retention decision or claim new performance evidence. This
package's own set digests explicitly sort UTF-8 relative-path strings.

Two patches make the comparison explicit:

- `candidate.patch` applies to `base/`: complete original axis delta plus
  the two hints, across three changed files, +233/-29.
- `inline-only.patch` applies to `axis/`: exactly two attribute additions,
  across two runtime files, +2/-0.

The combined runtime delta relative to immutable control is +32/-29;
the original test module remains +201/-0. No dependency, manifest, lock,
counter, Interface, data owner or buffer change is introduced.

## Original axis semantics and tests retained

The three private const parameters remain the original
`project_measurements -> project_subtree -> prepare_split_projection`
chain. Committed full-root and delayed measurements enter the false
route; successful checked raw topology enters true. Raw preparation or
an actual selected override performs the original full `validate_inputs`.
Committed preparation without a selected override retains extent checks
at the original position.

The local bound override lookup, binary/generic constraints and weights,
borrowed override f64 precision, min/max output writes, central route,
splitter geometry, available-extent subtraction and error priority all
remain exact original-axis bytes. The numerical executor, aggregates,
desired sizes, clamping, grow/shrink redistribution, both assigned-size
sums and error labels are unchanged. There is one numerical algorithm.

The whole original axis `layout.rs` is recovered after removing its one
new attribute. The entire projection module is likewise recovered after
removing the constructor's one attribute. Function bodies are not
rewritten. Topology, the independent reference and the test module are
complete unchanged original-axis files.

Both original semantic regressions remain exact:

- `committed_axis_inputs_keep_infinite_extent_and_delayed_error_priority`;
- `raw_axis_inputs_keep_earlier_geometry_before_later_bad_weights`.

This retains their extent, delayed-bound, full-override, zero-component,
raw-weight and geometry-order assertions against the independent
reference, along with the retained frame/central witnesses. Existing
raw DAG, old-output, deep-tree and complete-output coverage is not
weakened. No new mirror test or fixture is added. Previous successful
ordinary checks of the original variant do not qualify this new binary.

## Falsifiable code-generation choice

Root reported a symbol-shape difference in the frozen executables:
The control's matching rows contain project_measurements without separate
matching continuation/constructor symbols, while the original axis has those
additional symbols. Root also reported
large-cell regressions for that original implementation. This lane did
not rerun nm, disassemble, compile, profile or measure either executable.

The two ordinary hints are a bounded way to test whether the compiler's
placement/call decisions materially affect this implementation. They
do not guarantee inlining, a particular generated symbol set or an
improvement. Separate symbols alone do not quantify dynamic call cost,
instruction-cache effects, or the cause of the original regression.

Hints can be ignored. They can also increase code duplication or hot
instruction footprint, alter placement and optimization choices, and
regress other sizes or tails. No new dependency is added, but that is
not a zero-runtime-cost claim about the resulting code. The original
check reduction and its possible generated-code costs remain the
subject of measurement.

An improvement would support this combined treatment; it would not
uniquely attribute the original regression to either function or prove
that removing the checks alone is beneficial. A regression or no
material change would be valid negative evidence. Preserve the original
candidate, rejection and complete raw results independently.

## Source checks and handoff

`scope-checks.json` binds immutable base origins, exact fourteen-hunk
replay, exact original axis files, absence of prior target hints,
attribute-only variant difference, retained const/validation routes,
unchanged tests/reference/topology, and the bounded file/line scope.
Both patches reconstruct their complete target files exactly and pass
read-only `git apply --check --whitespace=error` in their respective
temporary source layers. No formatter or Rust execution was used.

`source-pairs.md` and `manifest.json` bind all five base/axis/tree triples.
READY binds the final patch and metadata hashes. Independent source
review should verify the original implementation is restored by
removing exactly the two attributes, then leave all validation and
measurement to Root.

Root should retain the original ordinary semantic qualification and
complete operation comparison protocol. New compiler/code-generation
inspection may test the supplied hypothesis, but must not replace
complete value checks or be presented as timed attribution. This
package is stationary and not applied or qualified.
