# Original axis boundary and two inline hints on retained packed output

READY / source stationary / not qualified. This is a context rebase of the
previous axis-inputs-inline mechanism to immutable
`eb94cb242722962c9e0d88074d81cf462d784357`. The parent includes retained packed
ChildProjection results. No live worktree, SmallVec, persistent NodeStore,
fused continuation or numerical-inline candidate is included.

Only this new temporary directory was written. No repository, fork, cache,
Git state, old candidate, rejection or historical evidence was changed.
No Cargo, compiler, formatter, test, runner, timing, nm, disassembler, profiler,
network or child agent was used. Root owns review, execution and retention.

## Exact prior treatment and bounded scope

The source mechanism is the frozen `/tmp/axis-inputs-inline/candidate.patch`,
SHA-256 `b792aae9f009f6848a802babfd896778399e1a637d70b387d61f399fe3475192`.
Its parent was immutable 07f566a. Copies of the original complete base/tree,
patch, manifest, READY, independent review and rejection context are under
inputs; their hashes are bound here without modifying those artifacts.

I expressed the existing layout delta as thirteen exact local substitutions.
Applying those to the copied old base reproduces the old layout tree byte for
byte. The same thirteen substitutions apply exactly once to the new immutable
base, producing this tree. The original constructor attribute and two original
semantic tests are likewise replayed. This is an exact mechanism rebase, not
an assertion that the complete old and packed files should be identical.

The main patch changes three paths, +233/-29:

- layout.rs: +31/-29 for the original static validation join, wrapper deletion
  and ordinary advance_split_projection attribute;
- layout/projection.rs: +1/-0, only ordinary inline on SplitMap::new;
- layout/topology_tests.rs: +201/-0, the original LogicalPoint import and
  exactly the original 200 appended regression lines.

There are two runtime paths, +32/-29. All nine complete base/tree pairs are
recorded; the other six files are byte-identical. No new helper, state,
dependency, counter, test framework or second numerical solver is introduced.

## Mechanism preserved

The original three private const-generic layers remain:
project_measurements -> project_subtree -> prepare_split_projection.
Committed full-root and delayed minimum projection enter false. Successfully
checked raw diagnostic topology enters true.

Prepare binds the selected override lookup once, retaining the exact borrowed
f64 values and original binary/generic input choices. At the previous checked
wrapper position, raw or an actually selected override invokes full
validate_inputs. Committed input without that override invokes validate_extent.
Extent finite then negative priority is unchanged. Both branches then call
the one unchanged solve_validated_axis_into.

The former sole-caller solve_axis_into wrapper is removed. Public solve_axis
still performs complete validation and calls the same numerical executor.
There is no inline hint on that executor in this package: its only two hints
are the original advance_split_projection and SplitMap::new attributes.
The independent `/tmp/numeric-inline/` package is a different treatment.

This route relies on the same closed committed graph/cardinality/weight
invariants as the reviewed original axis candidate. Raw malformed fixtures and
selected overrides keep full validation. The temporary override binding is a
single local lookup result, not a persistent cache, trust flag or new proof.

## Packed-context adaptations

`rebase-notes.md` and `rebase-operations.json` enumerate every adaptation:

1. Packed SplitMap::new takes only the topology Arc. The original inline hint
   is attached to this current declaration; its entire body stays unchanged.
   No bounds parameter or obsolete output storage is restored.
2. Packed prepare already initializes local binary sizes or the nary sizes
   scratch before the checked wrapper call. That initialization stays exactly
   where it is. The validation join occupies the old wrapper call position,
   after splitter geometry and sizes initialization.
3. The numerical call keeps the current `sizes` slice. The immediate ordered
   copy into every ChildProjection.extent, all minimum/maximum/gap writes,
   split outcome and continuation/gap geometry retain current parent bytes.
4. Original regressions append after the parent's current packed oracle
   assertions. Their bodies, source input order and expected errors are
   byte-identical to the original tests. Only the original import is added.

No slab, child-rows generic interface, removed three-extents API or former
splitter directory is reintroduced. The checked raw compiler, central scalar
frontier, release first-visit prefix, dynamic stack, measurement gathers,
fresh leaf order, reference traversal, numeric implementation and complete
fresh owned output remain the retained parent implementations.

The two registered original regressions remain:

- committed_axis_inputs_keep_infinite_extent_and_delayed_error_priority;
- raw_axis_inputs_keep_earlier_geometry_before_later_bad_weights.

Existing packed raw-DAG/parent-edge outcomes, last-write behavior, cloned old
outputs, late descendant-gap errors, delayed minimums and real deep projection
remain untouched. Test presence is not an executed qualification.

## Costs and measurement limits

The original axis treatment had negative complete-operation evidence. Rebase
and ordinary hints do not erase it or guarantee a different result. Root's
reported matching nm rows are symbol-shape observations, not proof of inline
body placement, dynamic call frequency or a unique regression cause.

The static split can duplicate projection code across checked and committed
instantiations. Hints may be ignored or change code footprint, liveness,
register pressure and placement unfavorably. The numerical reductions,
constraints gather, all materialized packed fields and nary/binary solved
extent copy remain. There is no allocator or complete-kernel speedup claim.

No benchmark code changes: capture, checked mutation, all-root fresh
measurement/projection and complete owned export retain their exact current
bytes and positions. Root should qualify this exact binary with the unchanged
oracles and formal comparison protocol, preserving all negative cells/tails.
It does not inherit prior ordinary checks or performance qualification.

`manifest.json`, `source-pairs.md`, `scope-checks.json` and READY bind exact
source/inputs/patch identities. Set digests use UTF-8 relative-path-string
ordering. This package is stationary and awaits independent review.
