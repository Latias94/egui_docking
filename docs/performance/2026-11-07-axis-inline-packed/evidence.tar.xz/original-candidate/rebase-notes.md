# Rebase correspondence

Original package: `/tmp/axis-inputs-inline/`.
Original combined patch SHA-256:
`b792aae9f009f6848a802babfd896778399e1a637d70b387d61f399fe3475192`.
Original immutable parent: 07f566a.
New immutable parent: `eb94cb242722962c9e0d88074d81cf462d784357`.

Thirteen layout substitutions reproduce the old tree exactly when applied to
the old base, then apply unchanged to the new base. Their exact fragment
hashes/match counts are in rebase-operations.json.

| Original mechanism | Retained packed context |
| --- | --- |
| Delete sole-caller solve_axis_into wrapper | The complete wrapper still exists at the parent and is deleted verbatim. |
| Full-root false / delayed false / raw true | Same three calls and same central-route arguments. |
| Three CHECK_AXIS_INPUTS declarations and two forwarding calls | Same declarations/forwarding; unrelated bodies stay current. |
| Bind override_weights once | Same exact local fragment and original input-selection branches. |
| Full raw/selected override, extent-only committed, then sole executor | Same checked call position. Current binary/nary sizes initialization precedes it, and current sizes slice remains the argument. |
| Extract validate_extent and reuse in full validator | Same original helper and unchanged remaining validator body. |
| Ordinary advance_split_projection inline | Same declaration and unchanged packed geometry body. |
| Ordinary SplitMap::new inline with old bounds parameter | Attribute on current topology-only declaration. No constructor-body change, no bounds or removed buffers restored. |
| Two semantic regressions and LogicalPoint import | Exact 200-line appended body plus original one-line import; current packed tests are otherwise unchanged. |

The numerical executor/desired/grow/shrink/redistribute/reduction bodies equal
both the new parent and original treatment. Actual min/max/gap initialization,
sizes initialization, solve arguments after extent, extent copy, outcome write,
continuation enum/stack and release prefix equal the new parent. Independent
reference, raw topology compiler, geometry, override tests, profile and complete
benchmark file remain byte-identical.

The original constructor parameter adaptation is an API-context change only.
The packed buffers/scene integration are baseline work, not attributed to this
candidate. No original rejection report or measured evidence was amended.
