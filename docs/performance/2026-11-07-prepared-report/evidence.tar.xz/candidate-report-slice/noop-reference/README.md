# Lock original command-reference reuse after local Item no-ops

Status: OPTIONAL TEMPORARY TEST PATCH READY, 2026-11-07. No repository edit, application, Cargo/compiler/test execution or timing. This closes the nonblocking coverage opportunity in the independent prepared-report review without adding a fixture or production Interface.

`noop-original-references.patch` adds one assertion block to the existing `local_item_moves_match_complete_normalization_and_exact_mru` matrix. After the actual local result has been compared with the general candidate/report oracle, each successful false-change result validates the **original** command's payload and target with the real `check_move` and existing policy. Source and target independently carry their old exact refs through that check. No new capture can replace them with fresh authority.

This supplements durable Workspace/report equality, which deliberately ignores issuance. It catches a no-op that silently renews a source or target ref even though values and `report.changed()` agree. The existing matrix already supplies same-pane Center, gap no-op and singleton self-edge cases across its axes, source/central/selection shapes and destinations. The assertion runs after the structural-work snapshot, so existing zero-work checks are unchanged. Non-noop paths, numeric rejection cases and strict net-zero multi-command ABA semantics are unchanged.

Exact input is `candidate-report-slice/proposed/crates/dockspace/src/operation/tests/local_item_move.rs`, SHA-256 `886bda45d417391c2f13eb86b0b74bb1e579889c6bf52197b25c576715a17b78`. It is an addition **after** the prepared-report patch; candidate-copy does not change this file. Its expected prepared-report patch SHA-256 remains `1b0a17402068d3b2d782bbe5e39538cb3366e30f6b0a45e95236293e815425b9`.

Output source SHA-256: `68020548cbdbd968b09cbfdcb0dbb5a43217074cd0c504f528546d2a243815d2`.

Patch SHA-256: `9f4eb5c095b53dfc3365ef84c10db215d10b5837275fe2553e0f6c47e5250349`.

`base/`, `proposed/` and both hash manifests retain exact copies. Only direct rustfmt and source/diff inspection ran. Root can combine this small test addition before prepared-report qualification and run the same registered matrix; no pass is inferred from source inspection.
