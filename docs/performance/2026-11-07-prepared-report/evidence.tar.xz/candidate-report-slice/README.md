# Prepared report ownership: remove the two common Item Move equality calls

Status: TEMPORARY PATCH READY, 2026-11-07. No repository source was edited. No Cargo, compiler, test, benchmark, timing or Git mutation was run. Only temporary Rust copies were formatted with direct rustfmt and `skip_children=true`; that is a syntax-format check, not typechecking. Root must finish the frozen A1 comparison before applying or verifying this independent slice. The 2× product goal is not claimed achieved.

## Deliverables and exact base

- `candidate-report.patch`: unified patch with repository-relative `a/` and `b/` paths.
- `base/`: the twelve exact stationary A1 input files.
- `proposed/`: the twelve complete proposed files.
- `base-sha256.json`: exact patch inputs, also listed below.
- `proposed-sha256.json`: exact proposed file bytes.
- `contract-sha256.json`: unchanged graph/authority/command/canonical source on which the local change proof depends.
- `patch-stat.json`: file inventory and changed-line counts.

Unified patch SHA-256: `1b0a17402068d3b2d782bbe5e39538cb3366e30f6b0a45e95236293e815425b9`.

The repository HEAD while copying was `91f42cebdad1ac8cb1551abe70f6d1972b19b61e`, **with the stationary A1 changes in its working tree**. The patch is against those working-tree bytes, not bare 91f42ce. The base hashes, not that commit alone, identify the apply target. All twelve repository files still matched their input hashes when the patch was generated. Do not force an application if a subsequent A1 repair changes them; rebase the affected hunk explicitly. No version/origin metadata or retained fingerprint is added to runtime state.

## Concrete ownership and Interface

Move the private PreparedTransaction into `operation.rs`, alongside its prepare owner. It owns private `candidate: Workspace` and `report: TransactionReport` fields. Its constructor is private to operation. The one report constructor in transaction is crate-private because a report is a plain output value; callers still cannot construct or independently replace a PreparedTransaction's pair.

```rust
// Private graph/operation Implementation; construction never escapes it.
fn new(candidate: Workspace, outcomes: Vec<CommandOutcome>, changed: bool)
    -> PreparedTransaction;

// Read-only preview and consuming conversions.
fn candidate(&self) -> &Workspace;
fn into_parts(self) -> (Workspace, TransactionReport);
fn into_snapshot_parts(self) -> (WorkspaceSnapshot, TransactionReport);
```

The existing private publish convenience consumes those same frozen parts and assigns the candidate. It still drops the replaced live Workspace during publication, inside public `apply`'s existing operation interval. Snapshot conversion still allocates the same outer Arc. The public WorkspaceTransaction / apply_with Interface does not change.

The report is fixed at successful preparation, relative to that preparation's input. No consumer supplies another `original` Workspace and recomputes it. The old original argument was only an equality input, not a current-base or engine-publication guard. Every pending presentation, lifecycle, recovery, activation and host-frame barrier remains in its existing place. Before consuming a prepared value, outside code has only `&Workspace`; it cannot mutate the candidate or replace its report. After consuming, further edits belong to the caller's composed operation, whose existing comparisons remain.

This is a deeper owner Interface, not a cached validity/dirty flag. It stores an immutable result after the real checks and finalizer have succeeded. There is one executor, no shadow edit program, no rollback route, no COW, no new dependency, and no whole-root inventory added to the hot path.

## Exact change classification: why no frontier comparison is needed here

The proof is restricted to the current **single policy Item Move against a sealed canonical Workspace**. A general transient prefix never enters this preparation branch; actual staging uses the existing general executor/finalizer. A future writer that reuses an old payload node must revisit this proof.

| Successful concrete Item branch | Final semantic change |
| --- | --- |
| Same-tabs Center | False. It returns before detach with no graph, selected, MRU or presentation write. |
| Same-tabs TabGap | Exactly the reorder result. `reorder_item` returns false when the computed old/new position agrees; otherwise tab order differs and local normalization cannot change that order. Selection/MRU are untouched. |
| Inner/Outer edge on the same noncentral singleton source tabs | False. The existing early return precedes detach/allocation. Outer-edge identity can equal that tabs only when it is the root node. |
| Center/TabGap into a different tabs | True. The moved item leaves one tabs membership and enters another; the validated Workspace's unique item ownership prevents that destination already containing it. Canonical removal of an empty source cannot undo destination membership. |
| Any actual Item edge transfer | True. `insert_payload_at_edge` allocates a new nonempty tabs node for the moved item **before** local canonical retirement. Item detach does not delete the old source arena node before this allocation. Its complete generational NodeId was not a live identity in the input. The local finisher removes an empty source and redundant split containers; it does not remove this nonempty payload tabs. Therefore the final candidate contains a new live node identity and cannot equal the input. |

Consequently there is no current successful detach/reinsert Item path that normalizes to the complete original NodeId/weight/tab/MRU state. Geometry equality alone is not Workspace equality. Even if the old source's singleton position and the exact split ratios reappear, the new tabs identity survives. An empty protected central source also remains distinct from the new nonempty payload. Slot generations prevent a vacant slot from imitating any original live key.

The pre-detach false branches issue no new root ref. Given canonical input, the local finisher has nothing to rewrite in these no-op cases. Removing the hot branch's old `retain_original_issuance` copy is therefore safe; there is no changed issuance to restore. Changed same-tabs reorder still issues normally. Actual movement and local completion keep their existing ownership updates and numeric gates.

The proposed branch reads the existing concrete Moved outcome **after successful local finishing**, backed by these membership/allocation facts. It does not assume that every command tag or raw `changed: true` is exact. Cold single Move and general programs still use one complete final comparison, and retain their existing single normalized-equal Move issuance restoration. No finite frontier shadow or full-root capture is necessary for this qualified Item writer.

The exact pre-existing source dependencies are: `move_item_within_same_tabs`, `reorder_item`, Item `detach_payload`, `insert_payload_at_edge`, `finish_item_move`, and durable WorkspaceData equality. Their unchanged copies/hashes are recorded where applicable. The new identity regression below locks the most tempting incorrect visual-no-op interpretation.

## Prepare/report behavior for every route

| Route | Final change computation in this proposal |
| --- | --- |
| Single policy Select | Existing actual Selected.changed. On a sealed selected-first MRU, reselecting the selected item is a true no-op. |
| Single policy Item Move | Existing exact concrete outcome after successful local finish, proved above. No Workspace equality in preparation or prepared consumption. |
| General literal batch / actual apply_with stage / typed recovery | One `candidate != original` after the existing prune/canonicalizer. Reuse that one result in the aggregate report and a lone Moved outcome. |
| General net-zero multi-command batch | Final semantic report remains false, even if actual intermediate edits issued new opaque refs. Never OR command flags or restore all initial refs for such a batch. |
| Empty general program | One final exact comparison yields false; existing normalization/check behavior remains. |
| Later engine delivery activation or recovery selection | Existing caller comparisons remain after those later edits; the frozen preparation report is not claimed to describe an arbitrarily changed candidate. |

The general equality happens before the same final item reconciliation as in the old lone-Move general route; failure still discards the candidate. For multi-command/other general routes the comparison moves from consuming `into_parts` into successful preparation. This can make a rejected later preview pay that comparison earlier; no speedup is assumed for that path. The cold value snapshots, whole candidate clone, strict checks and item reconciliation are unchanged.

The patch removes two **Workspace equality calls** from ordinary single Item Move: its local outcome rewrite and prepared consumption. Those calls could short-circuit in the old code; this source claim is not a measurement that two full N-node walks always occurred. Common Select also loses its consuming comparison. General completion keeps exactly one preparation-relative semantic comparison. No count or allocation baseline is changed.

## Complete caller migration

All paths below are under `crates/dockspace/src/`. Each old argument was the corresponding preparation base; no lifetime/publication predicate was deleted.

| File / original location | Migration |
| --- | --- |
| `operation.rs:609,660,788` | Three prepare exits construct the private candidate/report pair; common Select/Item use their exact result, general uses its single final comparison. |
| `transaction.rs:201` | Delete old mutable prepared fields and conversion-time equality; import the operation-owned type and provide the small report constructor. Public apply/apply_with still consume publish. |
| `drop_resolver.rs:938,948` | Preview uses `prepared.candidate()`; consume with no original argument. |
| `engine.rs:3457,5687` | Journal command and ordinary command snapshot conversion use the frozen report. |
| `engine/pointer_transaction.rs:3277,3871` | Drop and press/activation consumption use the same no-argument conversions. |
| `engine/pointer_timed.rs:731` | Timed pointer resize candidate conversion. |
| `engine/semantic_candidate.rs:313` | Combined contained Raise/Select candidate conversion. |
| `engine/surface_runtime.rs:2510,2733` | Recovery preparation consumption; post-selection comparison at 2753 remains exactly unchanged. |
| `engine/native_tear_off.rs:515` | Native-create future preflight consumes its preparation-relative report. |
| `transaction.rs` tests | Two conversion arguments removed; discard/retry and checked self-center no-op assertions retained. |
| `operation/tests/local_selection.rs` | Six conversion arguments removed; property/general oracle, rejection facts, rollback and mixed-batch checks retained. |
| `operation/tests/local_item_move.rs` | Five conversion arguments removed; complete local/general matrix and numeric/retirement/discard checks retained. One discriminating identity regression added. |
| `operation/tests/owner_reference.rs:454` | Two prepared candidate field reads use the shared accessor; actual stage net-zero/MRU/strict issuer behavior remains unchanged. |

No close payload redesign is included. PreparedContentCloseCommit is a separate type and retains its existing engine comparisons. The precise affected-root match, cold background 7/125 and native 9/9 limitations, layout compiler, leaf readers, proof authority and formal benchmark phases are not edited.

## Contract tests for root to run after applying

Reuse the existing suites rather than adding another harness:

1. Existing `local_item_moves_match_complete_normalization_and_exact_mru` compares every successful local candidate **and frozen report** with the complete general oracle across axes, source cardinality/selection/central status, center/gap/inner/outer and same/cross-root destinations. Its placement oracle and strict validation remain after the work snapshot.
2. Existing local-selection property/general cases cover changed and no-op Select, exact MRU, stale/wrong-root/recycled sources and mixed batches. No expected behavior is weakened.
3. Existing actual-stage net-zero owner test must still return false final report with two changed Select outcomes, exact original selected/MRU values and a newly issued strict root ref. The ignored failure and late-output rollback tests remain.
4. New `an_item_edge_move_restoring_the_same_shape_still_changes_node_identity`: singleton left source moves to a left edge of its right sibling at fraction 0.5. Final root, two-leaf shape, exact 0.5/0.5 weights and source leaf content/MRU match the old arrangement, but the old source identity retires and a new one survives. Candidate inequality, Moved.changed, final report, independent placement and strict validity are asserted. This is a real writer/normalizer counterexample to treating visual equality as semantic no-op.
5. Existing transaction self-center no-op, prepared discard/retry, original refs and source main/contained retirement cases cover the false outcomes and candidate independence without duplicating setup.
6. Keep both exact weight-sum witnesses, outer flatten/underflow failure, stale same-root target and forged policy facts, full general/close/recovery and real host/native publication/drop suites. Then perform the unchanged complete-operation timing/state export comparison, with the same work-counter compile environment.

No new work-counter Framework or test-only performance executor is proposed. The available static checks establish that the proposal has one general Workspace comparison and retains engine post-edit comparisons. They do not establish type correctness, passing behavior, machine-code cost, allocation count or a numeric improvement.

## Exact patch inputs

All rows below are SHA-256 of the A1 base, before this proposed patch. `base-sha256.json` is the machine-readable source of truth.

| Path under `crates/dockspace/src/` | Base SHA-256 |
| --- | --- |
| `operation.rs` | `1af34d0400c32d0649a563ceb5c0d147aec36eca543fc4dd1ce33671281e92a8` |
| `transaction.rs` | `08d3f1324d95b38350be32d88490db67c22aff5e8120896f2ffd94aeb5e8a065` |
| `drop_resolver.rs` | `57d8c465dfca14388ab26b99d1c13be586522559e05bf5d42d277419b78c0f44` |
| `engine.rs` | `344e39afb7da29dce45d868602e24f7e42ec9f0c0254ab91f3d39981df4f6565` |
| `engine/pointer_transaction.rs` | `b7268f8a0ada92d32f888ccc532b1365b037978e9f4ebef0d412efe7c0ffa9c7` |
| `engine/pointer_timed.rs` | `06fa61b1f8a56be2ead0bab2689e555b0ffd215311d420d28be031ffbd45c292` |
| `engine/semantic_candidate.rs` | `12e5a078c15f4fda6c7031263aa97f7ef4ac7b25a2b00befa02ac2ba420f81ee` |
| `engine/surface_runtime.rs` | `0ffdea46a2fbf595a991f7406618e9327fbec9e4368122b88cc0d00140b98e98` |
| `engine/native_tear_off.rs` | `315fcff123553e698c726416ea820d9f711924670b268ec87eed2eccdf1bff23` |
| `operation/tests/local_selection.rs` | `08c90b17f9caed5f1a7c77b6339b30582c6b84faa3459b6d3c167da607d25e47` |
| `operation/tests/local_item_move.rs` | `34a209018e34678d12b49503656450045fcaac8401607053d53e10bad1d0c148` |
| `operation/tests/owner_reference.rs` | `7d0dd09f1404aa51b7c691297c286b9d5b85d1762f498899b7b125fc58a5174f` |

The twelve-file patch is +157/−81 lines, including one 62-line regression and mechanical caller changes. The only substantive production logic files are operation/transaction; resolver adds the shared read and other production files only lose the now-unnecessary conversion argument. Root has sole authority to apply, compile, qualify, freeze and measure it after A1 pairing.
