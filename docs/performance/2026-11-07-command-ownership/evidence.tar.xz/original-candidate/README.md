# Combined concrete command-ownership candidate

READY / source stationary / temporary composition only. No Cargo,
compilation, tests, runner, benchmark, profile or timing was run. No
repository, fork, cache, Git, older candidate or review file was changed;
no network or child agent was used. Root alone owns actual source freeze,
normal qualification, comparison and retention. This package does not
claim behavioral or performance qualification.

## Exact parent and composition

The parent is the exact live snapshot at HEAD
f00442201db8206857a91d39ebe906a0b410c76d. Each of the six selected runtime
files was separately compared byte-for-byte with dc689a6 and f004422;
both comparisons match. Eight selected source files are captured, not a
whole-workspace source receipt. The current topology test already includes
the compact-frame 55-line witness. Its full body remains byte-identical
in the combined tree. Only the original raw-root COW statement changes
in that test module.

Apply only these four original frozen patches, in this exact order:

| Order | Slice | Original patch SHA-256 | Original source review SHA-256 |
| --- | --- | --- | --- |
| 1 | `root-record-sharing-current` | `239782753c25a34a83e4eda483f0f495f9ecadeed5e28c0d1e1d4bbb498f726e` | `6724a0d2ea4742d6be6c942373bdd937569ca857b7a254cea4b8b7518a8687b3` |
| 2 | `borrowed-root-verification` | `be1ebc96b46d0b018daf4994df967f593dbab81521941ab71a70b1ebf4f9be57` | `5d06933df4ae09c24ae0330c291385c247d22edce893a46228b63c33745d17e7` |
| 3 | `single-target-policy` | `cda0e49ebc069d89889db3074a7991d04ff5b745369953d99641297b441594dc` | `c1d28e0fb738f5211bd29c434093ba2fdc4a945adb021071a80794f559c6cf50` |
| 4 | `single-item-ownership` | `dfa2f5af3c198cc5e9152c6fc4b1422b7dce01a61c7cef8ae467c3ae9e3305c1` | `d941630e5b41ef6053a8296586428a0dcde637d10374b7e9da10630472487389` |

All 26 original old hunk bodies match exactly once at the stage where
they apply. No original added/deleted line, context body or design was
adapted. composition-receipt.json records every stage's complete selected
before/after file hashes, hunk hashes and original patch/manifest/READY/
review identities. inputs/ contains exact copies of those four patch
and receipt/review artifacts. All original directories remain unchanged.

The single-item independent review arrived during packaging; it was read,
reports no source blocker and is included rather than marked pending.
The other three recorded reviews also report no source blocker. Those
are individual frozen source reviews, not executed passes, approval of
an unseen combined Workspace, or independent performance results.

The consolidated patch contains exactly their union: eight paths,
six runtime and two test paths, +144/-57 total; runtime +83/-55. There is
no extra helper, dependency, counter, cache, provider, validator or other
candidate beyond what the original four patches explicitly contain.
In particular, it does not introduce binary inputs, allocator changes,
new layout arithmetic, a layout executor change, or future unified-value
work. Frame's existing witness belongs to the parent, not this delta.

## The four changes and preserved contracts

1. Durable root records become Arc<BTreeMap<RootId, RootRecord>>. All
   nine actual writers retain their original mutation/error phases and
   use COW. Builder equal replacement returns the old record and avoids
   detaching. Local/full canonical publication compares actual record.node;
   changed-subtree effects and issuance remain independent. Current Item
   frontier repair, final rows-only completion and capacity semantics are
   preserved. Authority roots, surfaces and contained maps do not change
   owner. Original sharing/discarded-wrapper test and raw COW migration
   are retained, with no additional test framework.
2. Successful exact reference verification borrows the current issuance.
   Captures still return owned RootReferences; stale diagnostics still
   own both expected and actual. Root-before-node-before-membership-before-
   issuance-error order stays. No command/output borrows a new lifetime,
   and no version/numeric ID substitutes for authority. Current target
   recapture and independent source/target verification remain.
3. Known-target Move policy derives only its actual retained/undocked
   inventory, then invokes the same extracted authorization steps and
   unique evaluator. Source, target and semantic checks still run first;
   facts precede TabGap authorization, then drop evaluation. Multi-target
   eligibility still keeps both inventories for real drag queries. No
   public facts/serde representation or forged-fact validation is changed.
   Policy-None recovery retains its original checks and policy bypass.
4. Singleton item duplicate checking avoids its redundant set; Item tabs
   insertion borrows a stack-local singleton slice; a freshly allocated
   Item Tabs uses the existing placement setter directly. Node payloads
   retain full subtree assignment. Empty-Root and length>=2 duplicate
   behavior, source/target restrictions, Node-shape validation, allocation,
   MRU, placement and error order are unchanged. The owned Moved item Vec,
   outcome roster and TransactionReport remain owned and intact.

The prepared candidate/report prefix and preparation, staged-prefix,
remembered failure, general finalization, recovery, follow-up and single
Move executor bodies stay byte-identical outside those original changes.
Candidates remain independently inspectable and discardable; engine
preview/native/host publication barriers remain outside preparation and
can still reject. Old snapshots/outputs and complete generations retain
their lifetime. True no-op issuance reuse, strict value ABA, source/target
independence, staged captures and late typed rollback are not replaced by
storage sharing. Existing work-counter sites are untouched.

## Negative costs and attribution limits

The new roots Arc allocates even for derived empty/default WorkspaceData.
apply_owned_draft_command still mem::takes the original valid-empty
placeholder, so follow-up success/error paths construct an additional
empty Arc owner. Actual shared root-table insert/remove/wrap/collapse or
unequal replacement still COWs the whole table. Transient writes can pay
that cost even when normalized values agree. Extra lookups, Arc reference
operations, read indirection, retained allocation lifetime and code layout
can offset saved table clones.

Borrowed verification retains all error/capture ownership and only removes
a successful temporary handle; stale errors still clone. Single-target
facts remove an unused opposite-undocks inventory, not required policy
inventory. The evaluator still processes actual facts. Singleton fast
branches add code/branches on other lengths; compiler optimization of
former temporaries and generic/multi-item costs remain relevant. No
allocator-count, bytes, sizeof, time-share or zero-allocation claim follows.

NodeStore/arena handle copies, authority metadata copying, true Node/MRU
payload COW, placement COW, root issuance, structural reconstruction,
fresh measurement/layout and complete owned export remain. The formal
bounds-only resize request differs from real ResizeSplits authorization;
reference verification can affect the latter. Do not describe every
resize path as bypassing the verifier.

Root may retain the combination and report only the complete combination's
qualified overall results. There are no within-combination single-slice
controls here, so no individual gain or allocator attribution is supported.
Preserve every paired cell and negative p50/p95/max result, complete vector
equality, normal counter-enabled checks and separately ledger-disabled
formal build. Any whole-workspace build/source receipt belongs to root's
actual integrated candidate, not this eight-file packaging receipt.

## Frozen files and source checks

| Source under crates/dockspace/src | Exact base SHA-256 | Combined tree SHA-256 | Delta |
| --- | --- | --- | --- |
| `canonical.rs` | `dda19b95f3a8c29aca4e262b9b4239e1409ca8aceaf85ef2c3432c881aea79be` | `b2f1ab4bd5b7e5933966c54792b30f4d257f823f172a75c8686f9260af0ea517` | +13/-8 |
| `graph.rs` | `dde95ddfa9e733448a4565404d9b6a612a3f614735bc39ba2cc4233066b80c2a` | `ea8aa5ffe7b4b7d67ad80cb289631e05b3da53a8cf01b6441d2d2de180f04951` | +6/-2 |
| `graph/copy_tests.rs` | `05e0cf43f8e16f4eab0808eab1c0dd67fe00a6ae49ac4ebe06f07175c260fda1` | `fa5478d74b3e851fa74f26dfeb6d0f1bd2176b091ceca0bd3048697cc1be39c4` | +57/-1 |
| `layout/topology_tests.rs` | `e7bacde83b6d7c957ee8d749cdaf70fb06ca6f85c5850515169e2bd279b1d729` | `c323b195ea2f2245e99e053b718516391c9a87044fbe16f811415c342910d62c` | +4/-1 |
| `operation.rs` | `b18c0f29b0561af1bbed80600d72d94825d5fb5ac1708abf1af7fe864d15c0b5` | `7586ec06b29b77a794133e0c554d4fcca7a6faa16b8c550b86034ad394175862` | +44/-35 |
| `policy.rs` | `2396080b0c30e5dc8e6cb4067956bc31a70b1422dbeb2185e1000e68510bf5d7` | `284df8a5daaf68c901fce6542b21aa3ed45d914dc08b7ab4ff0afa140cd83734` | +3/-0 |
| `validation.rs` | `bcbc2b79d3da167b101b40ae1683986d44f0b58bdcf3c7e865a64df081c02d79` | `44528551ff49edc30695560c2641ce43aa66b188758395189ed73fce0b7eb338` | +2/-2 |
| `workspace.rs` | `5cdb89c10b26f95695b9995e5c83e8cc3d2b34029b3213211d608b0c2cea0dd0` | `6cbcca776bfca60b1e767dc909121f06ae751110ea1f9fd265ea398da644aa36` | +15/-8 |

Combined patch: command-ownership-combined.patch, SHA-256
`621a4aa03bc5103210d139f8a358e9f9177722fdf48fcc3ec19377ed07350e1c`.
Selected base set: `e797ecf9c4e593f37ee82331e814d744dd894a6e231e3c59ca66fc004f27c1a1`.
Selected tree set: `c00f61c40a79066b784954cb3ff5a301803a610715abb31b2788ce06de1163a9`.
Set format: ascending UTF-8 relative path + NUL + file SHA-256 + newline.

The four copied original patches were independently reconstructed in
memory through every recorded stage. The consolidated patch was separately
reconstructed by exact old line positions; both reconstructions equal all
eight complete tree files. The combined patch passes read-only
`git apply --check --whitespace=error` against its own temporary base.
Relevant unchanged executor/report/frontier function bodies, current frame
witness and counter source lines were compared. No formatter or new Rust
implementation was needed; original frozen hunk text is preserved. Rust
best-practices was already read before the source composition.

These static checks do not compile Rust or execute behavior. Existing
owner-reference, policy/public-facts/serde, same-tabs/TabGap, central/
last-item, Item-versus-Node, recovery/close, staged/net-zero/ABA, numeric
frontier, old-output/clone and full kernel-oracle suites remain root's
qualification. No new tests merely mirror this combination.

base-manifest.json, composition-receipt.json, scope-checks.json,
manifest.json and READY.json bind stationary sources and input artifacts.
Apply exact matching hunks; complete files are for review and must not
replace later unrelated repository work.
