# Root-record sharing on the current frontier: source review

## Result

No source-level rebase blocker was found in the exact source pairs below. The 17 original hunks are unchanged, all nine durable-root writers use field-level copy-on-write at their actual mutation sites, and the current Item frontier, rows-only completion, capacity hint, Tabs-owned MRU, typed presentation, and authority issuance remain intact.

This is a read-only source review. It establishes neither compilation nor executed behavior, allocator counts, latency, or progress toward the performance target. Root owns execution and adoption. Only this review file was written; no Cargo, compiler, tests, timing, runner, archive script, network, child agent, repository, fork, cache, or candidate-source write was used.

## Exact source binding

`root-record-sharing-current.patch` is byte-identical to the original `root-record-sharing.patch`: SHA-256 `239782753c25a34a83e4eda483f0f495f9ecadeed5e28c0d1e1d4bbb498f726e`, 10,489 bytes, 17 hunks, six paths, total +91/-34. Its four runtime files contribute +30/-32.

| Source relative to `crates/dockspace/src/` | Base SHA-256 | Candidate SHA-256 |
| --- | --- | --- |
| `canonical.rs` | `dda19b95f3a8c29aca4e262b9b4239e1409ca8aceaf85ef2c3432c881aea79be` | `b2f1ab4bd5b7e5933966c54792b30f4d257f823f172a75c8686f9260af0ea517` |
| `graph.rs` | `dde95ddfa9e733448a4565404d9b6a612a3f614735bc39ba2cc4233066b80c2a` | `ea8aa5ffe7b4b7d67ad80cb289631e05b3da53a8cf01b6441d2d2de180f04951` |
| `graph/copy_tests.rs` | `05e0cf43f8e16f4eab0808eab1c0dd67fe00a6ae49ac4ebe06f07175c260fda1` | `fa5478d74b3e851fa74f26dfeb6d0f1bd2176b091ceca0bd3048697cc1be39c4` |
| `layout/topology_tests.rs` | `5863123fd6b1733f1ad1e0bfeb0d9f67b6c18e9b20703b9705079e3ae90cf5db` | `73a61c422cc700ae8e18237ddc4d87cd61f00cfaac72461f0662aa10134f33e2` |
| `operation.rs` | `b18c0f29b0561af1bbed80600d72d94825d5fb5ac1708abf1af7fe864d15c0b5` | `41b8ad7a8795d7b5cbbc2d68c7461a1f92d7d84812c8bbf36b8dec6d37e7aa4d` |
| `validation.rs` | `bcbc2b79d3da167b101b40ae1683986d44f0b58bdcf3c7e865a64df081c02d79` | `44528551ff49edc30695560c2641ce43aa66b188758395189ed73fce0b7eb338` |

The six-path base set is `cb63cb17e22d98aedcd67634ec9247f5597f3109084849bc647864ddb6906bbc`; tree set is `f203033cfa0670577bb77178b64814bd050ca0ae8335fa3a04e5e59f130aef80`. `manifest.json` hashes to `6b784f6118858e90fc027f8c3733b9d9ea182eaf1e8e6539a1f23b8c9cd2cf4d`; `base-manifest.json` to `4374e1d3130e638a3c92def79946e584161d14e115a8d4148166ef0e5eaa5458`. All complete file lengths/hashes, sorted path-set hashes, four artifact hashes, READY binding, and the frozen original review hash (`8b921a2189a1cd3588b8bb21aea1eaec0be424deac4f6bca9b21d6fd0735656e`) match.

I independently applied every hunk in memory, requiring exactly one old-body match, and reconstructed all six tree files exactly. The only new-tree versus original-tree difference is the current canonical tail's comment and two `complete_item_move_structure` calls. Every other target tree, including both test files, is byte-identical to the original reviewed tree. All six captured target bases also match immutable `e3c517195ddce2c7d1a6dbfd4328f152978968ec`.

The 14 unchanged contract snapshots match their manifest hashes and matched live source when initially read. The snapshots include childrows-era `layout.rs` and `layout/reference.rs`; they are context, not patch targets. Root subsequently reported rejecting and reversing childrows while starting new layout work. That later live state is not substituted for this frozen parent. The root-record patch does not touch any child-row statement, but a later actual application still needs its own source receipt; copying these complete files over subsequent WIP is not authorized by this review.

## Current frontier and capacity

The current `finish_item_move` tail from the retired-placement cleanup through return is byte-identical between this base and tree. It still forgets retired complete-generation placements, restores actual root placement, refreshes changed direct-child rosters, then calls `complete_item_move_structure` for source and, when distinct, target. The source/outer-root order, inserted/final-live split weight checks, full diagnostic fallbacks, EmptyRoot and missing-root error phases are unchanged.

`finish_item_target_root`, `rewrite_local_split`, `complete_runtime_rewrite`, `canonicalize_data`, `build_workspace`, `canonicalize_draft`, `validate_rewrite_input`, and `validate_split_weights` are individually byte-identical. Full canonicalization still records actual descendant effects independently of whether the root-node record changes, reconciles item ownership, strictly validates, and completes authority/structure. Avoiding a redundant record write does not suppress a subtree effect.

The unchanged authority snapshot is `89d0d337cdc2365caf62f5dd2d48d6f9132b21c2d4b882e9c24096cc6602a600`; root structure is `e80a74d1bdef525bd25a9a627bd1c826f41cd1def8fe05583dcea14372938632`. Editing retains only `previous_nodes`; begin/take/restore behavior is unchanged. Item completion still passes that hint to `build_after_item_move`, which uses old node count plus two only to reserve, performs the same complete traversal, and avoids split-array reserve for an actual leaf. No previous RootStructure Arc is added to the Editing state or retained by the new durable-root map. Birth/general/full-canonical completion keeps its full placement-installing builder. The row build, directory sorting, and new structure Arc costs remain.

## Nine writers and presentation boundaries

Candidate line references below refer to the frozen tree. No additional durable-root mutable facade, Entry/retain/iter_mut writer, weak owner, or interior-mutation route was introduced. The independent authority-root BTreeMap and other similarly named temporary maps are separate owners.

| Writer | Preserved behavior |
| --- | --- |
| Builder `set_root` (`graph.rs:678`) | Copies the complete previous record; avoids COW only on complete equality; returns `Some(previous)` even for equal replacement and `None` for insertion. Equality includes generational node and central identity. |
| Local repaired source (`canonical.rs:283`) | Requires the current record at the same phase and preserves `TraversalInvariant("publish repaired root")`; only an unequal current node causes COW, retaining current central metadata. |
| Full canonical publication (`canonical.rs:471`) | Records descendant changed effects first, separately guards the actual node assignment, and preserves strict validation/completion even when the table remains shared. |
| Empty surface birth (`operation.rs:2030`) | Root/surface collision checks, empty central creation, insertion, main carrier, then typed birth retain their order. |
| Surface root creation (`operation.rs:2095`) | Content validation/detach and donor processing remain before insertion, carrier, and birth. |
| Contained root creation (`operation.rs:2124`) | Floating/root checks and pre/post-detach surface/position checks remain; insertion precedes contained carrier, roster, and typed birth exactly as before. |
| Main-root install (`operation.rs:2179`) | Rootless-surface validation and post-detach MissingSurface/SurfaceMainOccupied checks remain before insertion and main-carrier publication. Disjoint field borrowing remains explicit. |
| Root target wrapping (`operation.rs:3389`) | Child wrapping changes only its parent slot. Root wrapping copies the current record, preserves MissingRoot then NodeOutsideRoot, and writes only the node field through COW. Wrapper creation keeps its original draft phase. |
| Root removal (`operation.rs:3576`) | Presentation lookup/detach remains before COW remove and MissingRoot, then unrooting and completion. No error is moved earlier to avoid an error-path allocation. |

There are exactly nine runtime `Arc::make_mut(...roots)` sites: two canonical, one Builder, and six operation sites. Read loops change only from implicit borrowed iteration to `.iter()`, keeping BTreeMap ordering and diagnostic order. Public root reads remain borrowed. Workspace equality remains by values, not allocation identity. Pointer identity is used only by the added storage-sharing test.

`RootPresentationOwner::{Main, Contained}`, issuance, birth, rehome, exact RootReference comparison, and complete-generation placement checks are unchanged contracts. Sharing durable RootRecord values cannot make a stale command current. Persistence still captures sorted values and restores through Builder validation/build, with the same schema. Atomic candidate publication, remembered staged failures, and discard on normalization failure are unchanged.

## Test boundary

This patch has two test paths, **one newly registered test and one existing raw-test migration**, not two new test functions. Their complete tree bytes equal the original candidate. Independently removing the new function and restoring its expanded import reproduces the old graph test file exactly. Replacing the single raw `Arc::make_mut` statement with its old direct central assignment reproduces the old topology module exactly.

The added `semantic_edits_share_root_records_and_discarded_root_wrapping_is_isolated` uses the current real Select/MRU and Item center-move executor, checks changed reports while retaining map sharing, preserves equal Builder setter return and no-op canonical sharing, then prepares a real outer wrapper and checks detachment plus original root/reference isolation when the candidate is discarded. Its fixture, default policy, module registration, and all existing graph-copy assertions remain intact. The current Item completion path is reached through these actual commands.

The existing `same_version_edits_own_new_rows_and_keep_the_original_output_body` changes only the raw central write to COW; all stale-index, fresh-index, reference-oracle, old-structure, and output assertions remain. No childrows, frame, unified-value, or oracle-body hunk was added. Current owner-reference staged rollback/history tests, graph-copy late failure/ABA tests, and the untouched canonical/local/import/strict/old-output suites remain relevant execution gates. This review did not run them or infer full writer coverage from the new sharing test.

## Costs and nonclaims

The README's negative boundaries are accurate. A candidate without a durable-root write clones one Arc handle instead of that map. A first actual insert/remove/wrap/collapse/central edit/unequal Builder replacement while shared still clones the complete map; transient changes can pay that cost even if final values agree. Reuse lasts only until another branch shares it. Equal writer avoidance adds lookups, and errors such as a missing root after presentation detach can still pay COW at the original point.

Derived default now allocates an empty roots Arc. The unchanged `apply_owned_draft_command` uses `mem::take(workspace)` at `operation.rs:855`, so follow-up success and error paths construct that additional valid-empty owner. The patch does not redesign the placeholder to hide this cost. Arc reference operations, read indirection, retained allocation lifetime, and peak memory also remain possible costs. Other metadata owners, NodeStore handle copying, authority-root copying, layouts, and export are unchanged; sharing this one table does not make candidate construction proportional to an edited frontier.

The captured formal request has one/four roots and two items per leaf; center and below-root edge cases can retain root-record sharing, while actual retirement/wrapping/collapse still detach. Its Resize request only replaces bounds and creates no Workspace candidate. These source paths identify where work may differ; they establish no net benefit. Logical copy ledgers do not measure BTreeMap allocations or bytes, and there is no one-allocation-per-root claim. No performance or allocator gain is approved by this report.
