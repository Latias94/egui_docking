# Independent source review: single-target Move policy facts

No source blocker was found in the one-file candidate. A known target now chooses its actual undocking classification and constructs one graph-derived payload inventory, then enters the same policy evaluator through a shared private dispatch helper. The reusable multi-target constructor retains both inventories and all indexed checks. The omitted constructor source invariant is unreachable for this closed graph-derived path, as detailed below. This is source review, not successful compilation, executed behavior or a performance result.

| Exact artifact | SHA-256 |
| --- | --- |
| Base `crates/dockspace/src/operation.rs` | `b18c0f29b0561af1bbed80600d72d94825d5fb5ac1708abf1af7fe864d15c0b5` |
| Candidate `crates/dockspace/src/operation.rs` | `d61f9557908995a4437a4f11ea55841eb16f6ac2d09a3f24334c559fc58bf33f` |
| `candidate.patch` | `cda0e49ebc069d89889db3074a7991d04ff5b745369953d99641297b441594dc` |

The patch exactly reproduces the complete pair diff (+23/-11, one path). Current operation.rs still equals the recorded base. Manifest, READY, artifact and path-set hashes match. All recorded policy/workspace/checked-move/recovery context hashes also match. The entire prefix through the multi-target fields, constructor, two inventories and indexed validation is byte-identical. The entire suffix beginning at the existing authorize_drop is byte-identical, including facts constructors, execution, target recapture, undocking classifier, counters, tests and registration. No patch or runner was invoked for this review.

The dispatch boundary is narrow (candidate operation.rs:1133-1140, 1201-1273). check_move still validates the source, independently validates the target, and validates move semantics/edge weights before the optional policy branch. With Some(policy), the unchanged move_undocks_source supplies one boolean to the existing move_payload_policy_facts_validated. The resulting kind, ordered items, source root/surface/presentation and actual undocks bit equal the variant formerly selected from the two-inventory object. The temporary facts remain owned during evaluation; none survives the command's immutable Workspace borrow.

authorize_move_target contains exactly the old operation selection, optional TabGap tab-bar authorization and authorize_drop call, parameterized without duplicating policy decisions. Both paths call it. The existing authorize_drop still derives target surface, rule and central facts and calls the sole policy.evaluate_drop_facts source call site. Reorder, opened-payload and other explicit-operation authorize_drop callers are unchanged. There is no second evaluator, shortcut based on a policy flag, or replacement of target fact validation.

The single-target returned-error sequence remains:

1. Exact source reference, membership, node/item shape and nonempty payload checks.
2. Exact target reference, recaptured target facts, scope and applicable index checks.
3. Source/target semantics, central-detachment constraints and edge-weight validation.
4. Actual source presentation-owner derivation and ordered item inventory.
5. TabGap tab-bar policy, where applicable.
6. Existing drop evaluation and its original policy error order.

move_undocks_source is unchanged and uses only safe, read-only matches/getters and optional lookups. Computing it before facts construction introduces no fallible operation, allocation or mutation before the existing facts errors. On the multi-target path, selection of an already-owned inventory moves before the helper's TabGap check; that selection is similarly infallible. Target semantic errors still precede that selection. Memory pressure or allocation timing from eliminating an unused inventory is not claimed to be equivalent.

The removed single-target constructor invariant is safe for the present production closure. MovePayload has exactly Item(ItemSource), Tabs(NodeSource) and Subtree(NodeSource), with no fresh/opened or arbitrary-policy-facts variant (command.rs:539-548). Their actual references and membership are checked before facts construction. In move_payload_policy_facts_validated (candidate operation.rs:1363-1389), all three exhaustive branches derive a kind and ordered items, and all successful branches converge on DockPayloadPolicyFacts::new after root_policy_owner succeeds. That constructor unconditionally installs Some(DockPayloadSourceFacts::new(...)) (policy.rs:1035-1053). Thus the former source().ok_or(Invariant { stage: "derive existing source facts for drop eligibility" }) could not return its error for any successful facts result on this path, including malformed or empty inventories. Real missing-owner, source, target and payload errors still occur at their original gates.

This conclusion is local to that call chain. DockPayloadPolicyFacts::opened and deserialized public facts may legitimately have source None, but check_move does not accept those objects and never calls opened. The public fresh-payload constructor, serde surface and evaluator behavior are unchanged. The multi-target constructor keeps its original source().ok_or check and stage string exactly. If a future graph-derived facts constructor permits source None, its caller contract would need reconsideration; the present patch adds no public input that can do so.

Policy remains centralized and unchanged (policy.rs:1470-1484, 1631-1755, 2083-2093). Drop evaluation still checks arrangement lock, operation permission, central-node policy, source/items and target rules in that order. Source validation still rejects duplicate/empty inventories before source restrictions, checks actual source root/surface and every item, and applies undocking restrictions only for the exact classifier result. Target surface, operation, payload kind and class filters remain unchanged. TabGap authorization remains before drop evaluation, including same-tabs no-ops; execution still begins after check_move. No new cache, proof, token, public facts API or policy logic is introduced.

The None recovery branch still runs the same source, target and semantic checks, then skips all policy facts/classification/dispatch. The private move executor, immutable check-before-mutation boundary, staged prefix handling, MRU/issuance repair, rollback and publication are in the unchanged suffix. Recovery therefore receives neither an accidental policy gate nor a target-validation bypass. Existing stale/forged targets do not gain authority.

For reusable multi-target eligibility, new_indexed still validates the source against the current index provenance, then builds retained facts and a complete copied undocked inventory. check_target_indexed still validates each target with its supplied index, then target semantics, then selects one of those two inventories. No repeated inventory optimization is claimed for that interface. No source proof is lent across candidate mutation or across a target check.

The only established cost change is removing the unused opposite-undocks payload inventory from a policy-governed known-target check. Needed inventory construction, duplicate-item validation, target recapture, command/report ownership, candidate fork and actual payload COW remain. An IntoIterator collect from an already-owned Vec may transfer its buffer, so collect spellings do not count allocator calls. No allocator share, byte saving, latency, macroscopic gain or resize/layout/export improvement is established. Code generation and runtime qualification remain Root-owned.

No tests were added merely to mirror this extraction. Existing meaningful oracles include no-undocking versus same-stack reorder, same-tabs TabGap policy, full TabGroup/Subtree item rules, central/source/target restrictions, forged target facts, indexed eligibility/preview behavior, and exact main-root recovery with stale target rejection. The named cases in README are present; no test was executed for this review.

Only this review file was written. Candidate source, patch, manifests and READY remain stationary. No Cargo, compilation, tests, timing, runner, repository/fork/cache writes or sub-agents were used.
