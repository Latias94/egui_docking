# Measurement directly from child rows

**READY / STOPPED — temporary candidate only, unapplied, uncompiled and untested.** Only `/tmp/measurement-child-rows/` was written. No repository or prior candidate edits, Cargo, Rust compilation, behavior tests, benchmark, timing, Git writes, network or sub-agents. Rust best-practices was read before source edits. Direct rustfmt formatted only the three temporary source files with edition 2024 and `skip_children=true`.

## Exact base and artifacts

Base is current RootStructure + single NodeResult, then only the frozen child-extents-slab-current patch. Before editing, live `layout.rs` was verified identical to that slab's input, and live `topology.rs` / `reference.rs` identical to their frozen single-map sources. The complete slab output supplies the new layout base. No frame, weight fusion, MRU, solver-aggregate or scratch-pooling candidate is included.

| Input | SHA-256 |
| --- | --- |
| RootStructure patch | `8dc1059d026310e0ef26a9ff5bcb1bca92cd8d00cff62a0bcf833a0c1404ad0b` |
| Single NodeResult patch | `274634d11c456f95515b8428917eb5f9bd439ec9ae96493165ce4408d1a86232` |
| Slab patch | `3cb323c6d799ce448e431c1944d040ada21c7bc4a55fba215cfcd3534eebbfee` |
| `layout.rs` base | `e4597343ab8b0f8d69f94bebf7e23e190905dace9e77b942b2187c2ef555d26c` |
| `layout/topology.rs` base | `d2d06077b9a5bfb03f764b0ed9c862de4e9aca3a65946059e480b8412f356f56` |
| `layout/reference.rs` base | `2b2eee151d88bdd83048f0dfe7a4931a769aff6616da59e060200819008b209a` |

Current RootStructure's test-only completion counters are preserved as an unchanged context snapshot: `de30fe16e4587efe9cc181f5d1ca46b66250fa082c5b4363efa5f1c9a1215a62`. The earlier frozen structural artifact lacks only that counter hook; this patch changes neither source. `contracts/` also retains the exact slab projection, geometry, existing topology/override tests and current benchmark source used during preparation.

- `measurement-child-rows.patch`: **3 paths, +26/-40, net -14**, 6,941 bytes; SHA-256 `3f826644008677c59c44917c4f38dda5542ccd3ccdca286d379c572a3a34322e`.
- `base/` and `tree/`: complete exact input/output copies of the three changed files.
- `base-manifest.json`: captured inputs, composition identities, unchanged context hashes and origins.
- `manifest.json`: per-file output hashes, patch hash and sorted path-set hashes. The set format is ascending path + NUL + per-file SHA-256 + newline.
- `scope-checks.json`: static equality boundaries and the actual composition call surface. `READY.json` binds the final artifacts.

Apply hunks only after the exact NodeResult + slab composition, or explicitly merge them into a newer base. Do not replace newer complete files with these copies; root-owned counters and other unrelated changes must remain.

## One implementation change

`compose_constraints`, `compose_minimum` and `compose_maximum` now accept `impl ExactSizeIterator<Item = Constraints> + Clone`. Production passes a standard slice/map iterator over child rows and the existing measurement Vec. Cloning these iterators copies traversal cursors and shared borrows; it does not clone measurements or allocate child storage. There is no custom iterator/provider type, new owner, cache, validity flag, unsafe initialization or second arithmetic implementation.

`measure_with_reader` removes its root-local child Vec and `clear/extend`. Its `contains_central` remains the same ordered short-circuit `any`, evaluated after successful constraint composition, reading the current child rows' booleans. Every leaf is still freshly queried at the same postorder position. Every measurement row is still freshly initialized and computed, and the final central reachability check is unchanged.

The minimum-only maximum-completion loop similarly reads current child constraints by row, then updates the parent after composition. It preserves the dependency on already completed child maxima. It does not alter root bounds, leaf maxima, splitter extent or the timing of projection.

The checked raw draft compiler retains its entire child gather, missing/active/completed checks, error sequence and central propagation. Only its composition argument becomes a slice/map iterator. `layout/reference.rs` has exactly two equivalent argument adaptations; its full traversal, checked child gathers and capture remain unchanged. This oracle already shared these composition helpers before this candidate: its independent traversal is retained, not presented as an independent arithmetic implementation.

## Exact numerical and diagnostic boundary

All minimum/maximum axis match arms are byte-identical, including separate width/height passes, child order, checked-sum quantity strings, `fold` initial values and the trailing splitter term. Cardinality rejection still precedes splitter extent; minimum still precedes maximum, followed by `Constraints::new`. Minimum-only measurement still skips the maximum pass until bounds are known. No reduction is fused or reused by the axis solver.

All actual callers are covered: three `compose_constraints` calls, one `compose_minimum` call and three `compose_maximum` calls across these three files. Raw/reference child-list copying is deliberately retained. Direct indexed numeric reads occur while measurements are immutable; parent writes follow successful composition. No new domain failure is introduced by these reads over graph-owned valid rows.

Static comparisons retain the complete public solver/entry prefix; output construction, override validation and leaf-measurement region; minimum/maximum arithmetic bodies; and the entire splitter-geometry/DFS/axis-validation/solver/inline-test suffix. Reversing one raw and two reference argument substitutions reproduces their prior complete implementations. Temporary `git apply --check --whitespace=error` passed against `base/`. These are source checks, not execution qualification.

No tests were added or weakened. Root should qualify using the retained dense/full-value oracle matrix, fresh-answer/metrics cases, minimum/override precedence, raw completed-subtree/cycle/missing-node ordering, sparse generation, owned-old-output/late-error and 10k-depth witnesses. Public output, RootStructure, slab ownership, fresh leaf collection, timer boundaries, complete owned export and formal/work CSV remain unchanged.

## Cost and limits

For a split root with E child edges, full production measurement removes one child-gather Vec and E materialized `SubtreeMeasurement` copies. The separate minimum-only maximum-completion path removes another gather buffer and E copies. A leaf-only root had no nonempty child buffer to save. Raw/reference diagnostic copies remain.

This is a source inventory, not measured allocation calls, bytes, RSS or time. The existing measurement Vec and every required fresh output remain. Composition still makes the same numeric passes but now rereads indexed rows instead of a contiguous child scratch; locality, bounds checks and generated code can change. No speedup, goal attainment or other performance victory is claimed. Root is the sole build/test/measurement owner. Candidate source and patch bytes are now stationary.
