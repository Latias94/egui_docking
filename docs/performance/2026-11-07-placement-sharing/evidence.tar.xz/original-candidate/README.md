# Shared placement ownership

**READY / STOPPED — temporary source candidate, unapplied, uncompiled and untested.** Only `/tmp/placement-owner-sharing/` was written. No repository, cache, fork, previous candidate, Cargo, Rust compiler, behavior test, benchmark, timing, network, sub-agent or Git state was modified or executed. Rust best-practices was read before source edits; direct rustfmt ran only on the temporary file with edition 2024 and `skip_children=true`. Root is the sole verification owner.

## Exact base and delivery

This is a one-file candidate against the current RootStructure authority, with Tabs-owned MRU WIP and committed single NodeResult captured as unchanged context. `base-manifest.json` records that source before edits and eight directly relevant dependency snapshots under `contracts/`. No root-frontier placement-install deletion, slab, frame, child-row or fusion candidate is included.

| Artifact | SHA-256 |
| --- | --- |
| Base `crates/dockspace/src/graph/authority.rs` | `c4542993266ad497b50cdd30e00bbf6fc656819925d8d52942290b54d7d121e2` |
| Candidate `crates/dockspace/src/graph/authority.rs` | `cae68a84471cc9fa64f74c7345c3566c8b7a3e8b84f870060b55ab2f4e44164a` |
| `placement-owner-sharing.patch` | `cfe9f0cb896c2db6aaa23de17d40328ae279a69038a6869698275fa84ec0e3c5` |

The patch is 7,188 bytes, **one path, +123/-10**. Runtime changes are **+13/-10, net +3**; the remaining addition is one registered 109-line test module plus its separating newline. `base/` and `tree/` contain complete before/after source. `manifest.json` binds the file pairs, patch and sorted path-set hashes; `scope-checks.json` records static checks and `READY.json` binds the final receipt. Apply hunks to the exact base or explicitly combine newer changes. Do not replace newer whole files with these copies.

## One existing owner, shared until a real write

`WorkspaceAuthority.placements` becomes `Arc<SparseSecondaryMap<NodeId, NodePlacement>>`. NodePlacement derives exact PartialEq/Eq over RootId and ParentLink; complete generational NodeIds and child indices remain unchanged. Derived Workspace/authority Clone shares this one directory while independently cloning the same existing storage/authority collections.

`place_node` retains the current live-node guard, then compares the entire existing placement before `Arc::make_mut`. `forget_placement` checks the exact map key before COW and removal. It deliberately does not call the live-filtered `placement()` accessor, because canonicalization can retire raw storage before forgetting its directory entry.

All original root-placement calls, concrete subtree/child-roster updates, reference issuance, selection provenance, no-op rules, staged completion, and strict ABA semantics remain. The three existing RootStructure::build entrances receive `Arc::make_mut` only within their existing Editing or birth branches. The full installer remains unchanged and still populates the actual directory. No generic store wrapper, provider, proof, cache, flag, public method, dependency or alternative executor is added.

## One registered behavior/ownership test

`graph::authority::tests::semantic_edits_share_placements_and_discarded_structure_edits_detach_them` uses one two-pane tree and the real checked transaction Interface. It verifies that a changed Select, populated-source Item center move, and root rehome all retain the original directory allocation while the old root reference becomes stale only in the changed workspace. The original Workspace retains its reference and MRU.

The same fixture then prepares an actual opposite-axis edge move without publishing it. The completed candidate has a separate directory and a changed real parent link. The live workspace still shares its original directory; dropping the prepared candidate leaves its complete values and original parent link intact. This covers candidate discard rollback rather than claiming a newly executed late-error scenario. Existing placement, prefix, close/recovery, generation and late-failure suites remain the broader behavior coverage.

Pointer comparisons stay inside the private owner test. There is no new production test accessor, protocol fixture, metadata validator or mirrored write implementation.

## Static verification and cost limits

Static reversal of only the approved field/default/derive, two guarded writes and three mutable build arguments reproduces the entire original runtime file byte for byte. The original reference and root-placement code is preserved. `git apply --check --whitespace=error` passed against this directory's exact `base/`, without patch application or Git writes. These checks do not establish successful compilation or passing behavior tests.

No-placement-write candidates can avoid a full placement-table clone. A first real write to a shared table still clones the whole SparseSecondaryMap/HashMap. Current full RootStructure installation also detaches it even for value-equal placements, so weight-only structural rebuild and cold installation retain that fallback. This patch does not claim O(frontier) candidate creation or remove arena handles, root BTreeMaps, surfaces, rosters or normalization costs.

Arc adds a directory allocation, reference operations and lookup indirection. Default/empty Workspace construction now allocates that Arc, including the existing `mem::take` follow-up path. Equality/presence guards add reads; sharing can change lifetime, clone timing and peak memory. Existing workspace-storage counters explicitly exclude placement-directory copying, so unchanged counters do not prove zero placement cost. No performance, allocation or twofold-goal victory is claimed.

Common's separate `/root_frontier_placement` slice overlaps this file's RootStructure completion calls. Root must explicitly compose those hunks; it is intentionally not incorporated here. Root should first review/qualify these exact bytes, then run the existing complete protocol and any combined comparison against its independently frozen base. Candidate source and patch bytes are now stationary.
