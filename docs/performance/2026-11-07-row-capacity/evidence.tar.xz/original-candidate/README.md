# Root-local row capacity candidate

Prepared by `design_minimal` for root-owned verification. This candidate is
confined to `graph/authority.rs` and `graph/root_structure.rs`. It is based
on the exact `/tmp/root-frontier-placement-current/tree` outputs: graph
RootStructure, Tabs-owned MRU, Arc placements, and terminal Item rows-only
completion. The parent patch is
`70cfba79fba97372f09fc4dcc8ae8ccc7d6e0ae396b922995aac125c4578b10d`.
It does not include root-record sharing or any layout candidate.

## Implementation

`RootStructureState::Editing` carries only `previous_nodes: usize`.
`begin_root_edit` copies `Ready.nodes.len()` and drops that owner's Ready
Arc just as before. Re-entering Editing preserves the count. Zero means
there is no prior body. No old RootStructure or Split payload is retained
by the hint. Ready still contains the same Arc; exact root references,
placement authority, selection provenance, and their validation do not
consume the hint.

Only `complete_item_move_structure` passes the scalar to the rows builder.
A checked Item move can add one tabs node and one split wrapper to an
existing root. With a prior count `n`, the builder uses `h = n.saturating_add(2)`
as a capacity estimate. Zero remains a disabled hint. At the first Enter,
after the existing root-record and node-presence checks, actual node kind
determines the reservations:

| Actual final root | Node directory reservations | Child/split reservations |
| --- | --- | --- |
| Split | `h` elements each for nodes, postorder, ordered_rows | `h - 1` for children; `(h - 1) / 2` for split_rows |
| Tabs | 1 element each for nodes, postorder, ordered_rows | None |

For a canonical tree, child edges number `N - 1`, and split count is at
most `(N - 1) / 2`. These relationships only choose reserve sizes. Every
Vec still grows normally if needed. No length is initialized from the
hint; no traversal, lookup, error, sorting, placement write, or output
range is bounded by it. The existing pending stack is unchanged. A final
leaf never allocates children or split_rows from the previous root size.

The ordinary `RootStructure::build` passes zero. Birth, Builder/import,
raw normalization, general command prefixes, and general terminal
completion keep that original no-hint builder. Raw structure extraction
and newly introduced Editing owners use zero. All existing missing-root,
missing-node, input/output numeric frontier, and strict checks remain.

## Costs and limits

The intended source-level saving is fewer growth reallocations while
rebuilding an Item-edited root. For an old 31-node root that grows to 33
nodes, the requested capacities are 33 for each node directory, 32 for
children, and 16 for split_rows. Vec and allocator behavior determine
actual allocation sizes; these counts are not measured allocator bytes.

The change has costs even outside that rebuild. The old Ready-Arc/unit-
Editing enum may fit in a pointer through a null niche. Carrying a usize
can enlarge RootStructureState and RootOwner, increasing authority map
storage and every whole-map candidate clone. No header-size preservation
is claimed. `begin_root_edit` reads a node count even for non-Item writers
that later ignore it. The shared builder also contains the hint branch;
elimination on the zero-hint path has not been inspected in generated
code. These costs can matter for small roots and many-root fixtures.

For a final root that remains split but shrinks, reservations can retain
more capacity than its final length requires. The final-leaf case avoids
that over-reservation and avoids new split arrays entirely. Hints do not
remove traversal, directory sorting, placements' first-write COW, or
pending-stack growth. Existing inclusive profile counts are not allocator
shares and establish no saving for this patch. No performance improvement
or O(frontier) total complexity is promised; paired results must decide
whether to keep the candidate. There is no unsafe tagging, Box owner,
new container, dependency, cache, proof, or validator.

## Ownership and existing qualification

Old workspaces and outputs keep their existing immutable structure and
Split payload Arcs. The hint adds no shared payload owner and therefore
cannot itself force an additional Node COW. Ready assignment still follows
successful reconstruction. Failed preparation and discarded candidates
leave the original workspace and outputs untouched. Repeated begin calls
only preserve a scalar, not an obsolete body or authority.

Root should run the existing behavior oracles rather than tests of Vec
storage form:

- `local_item_moves_match_complete_normalization_and_exact_mru`, including
  its independent actual-placement/rows checks, plus the last-item retire
  and discarded-candidate case.
- Both weight-sum witnesses and outer-flattening rollback failure.
- Staged transient-structure/late-error rollback, cross-root subtree and
  residue placement, new-root donor, exact no-op, generation, and ABA cases.
- `runtime_projection_rejects_an_unfinished_body_and_owns_the_completed_one`,
  nonempty-center structure sharing, and the unchanged placement-sharing
  semantic test.
- Dense-vs-frozen layout, owned old outputs, same-version edited bodies,
  raw DFS diagnostic order, and the 10,000-depth layout case.

No test was added or modified. Rust best-practices was read before editing.
Only these two temporary source files were formatted. Static patch and
source checks are recorded in `scope-checks.json`; compilation, behavior
tests, Cargo, benchmarks, and timing were not run in this lane.

`base/` and `tree/` contain complete changed-file pairs. `base-manifest.json`
binds the inputs captured before edits; `candidate.patch`, `manifest.json`,
and `READY.json` bind the final deliverable. Integration must preserve the
parent rows-only repair ordering and check exact base hashes first.
