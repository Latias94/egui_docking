# Committed axis-input validation on unified node values

READY / source stationary / tmp-only rebase. No Cargo, compiler, behavior
test, runner, profile, benchmark, timing, network or child agent was used.
Repository, fork, cache and every older candidate/review remain unchanged.
Root alone owns compilation, qualification and retention. The source
checks below are not behavior or performance qualification.

## Exact parent and original review

base/ contains all five exact files from
`/tmp/unified-node-values-retained/tree/`, including compact frames,
binary input arrays, unified NodeResults, scalar CentralRoute, all-build
first-visit prefix rejection, raw bool propagation and retained child
scratch gathering. Slab and childrows are absent. At initial read these
frozen files matched the live candidate on HEAD
59a498086caee70ec9e3d2403711f16bfff6dc09. Root had applied unified values
and was qualifying it. This package does not change that candidate or
claim its pending qualification succeeded. If root rejects unified, use
another explicit variant instead of replacing this frozen parent.

Original patch: `/tmp/committed-axis-inputs-simple/candidate.patch`,
SHA-256 `24e32ec7198d9e39335eb5585d61cd40be5689493ef11a365d4c0a0a970afee4`.
Its independent review, copied under inputs/, is SHA-256
`91c4c6897fa4fec1e4ed64da2b1b78cf042a6b1c287fb7c99cab4f9f28de75bb`.
That review reports no source blocker in the original variant, but is
not independent approval of this new rebase or executed qualification.
The copied input patch/manifest/READY/review identities are bound by
rebase-hunks.json. No old artifact was edited.

## Same private static wire

The original CHECK_AXIS_INPUTS constant is added only to the same three
private functions: project_measurements, project_subtree and
prepare_split_projection. Full public-root and delayed RootMeasurement
calls enter project_measurements::<false>; successful raw compilation
enters::<true>. No public function, output or RootMeasurement stores a
mode. No new stage, proof, provider, cache or generic framework is added.

At the existing prepare position, after the same scalar extent and
splitter calculation, the single override lookup is bound to a local
Option and used both for the original selected override slice and its
is_some test. That local binding is not a runtime answer cache. All
binary/nonbinary weight conversions, borrowed override f64 precision,
axis-constraint choices, min/max output writes and priorities are retained.
The existing axis_constraints slice replaces the old simple parent's
scratch.constraints borrow; actual numeric input order does not change.

Raw true or an actual selected override performs the original complete
validate_inputs call. Committed false without a selected override still
performs validate_extent. Both return at the same original prepare phase
and then join one unchanged solve_validated_axis_into call. The former
sole-caller solve_axis_into wrapper is deleted, with no references left.
The public arbitrary-f64 solve_axis continues to fully validate and call
the same numerical executor. There is still only one arithmetic algorithm.

The committed justification is the existing closed graph owner's positive
finite normalized weights, matching child roster, and actual central
position. Renderer geometry has a different contract: finite ordered
LogicalRect corners may have an infinite difference. Extent validation
therefore remains and is not moved into a preceding root-wide pass.
Full override validation remains necessary for internally forged scalar
shares; a selected negative share must retain NegativeWeight at the same
point, and an accepted zero component is not made strict-positive here.
Public zero/all-zero and raw malformed input behavior remain checked.

validate_extent and validate_inputs match the already reviewed original
variant byte for byte. Scalar order stays nonfinite extent, negative
extent, length, central index, per-weight scalar checks, checked weight
sum and conditional zero-total rejection. The remaining minimum/maximum
aggregate checks, feasibility exits, desired normalization, clamping,
both assigned sums and redistribution remain untouched.

## Unified/frame/reader/error ownership retained

The three-function static wire does not alter scalar CentralRoute predecessor
selection, raw all-true row membership, release visited_prefix assertion,
allowed old-row revisit, or final debug coverage. Private NodeMap row
access, in-place rect updates, complete output/Clone lifetime and raw DAG
last-write behavior remain. No persistent central field or proof is added.

The entire production measurement/gather and raw compiler live in unchanged
topology.rs. The delayed minimum-only maxima/gather body is unchanged
inside project_measurements apart from its static call wire. Every fresh
leaf is still read in the original order, maxima still wait for actual
bounds, and override validation retains the same public/delayed schedule.
The original slice compose constraints/min/max helpers, metrics, splitter
arithmetic, compact continuation, thickness, pending-child extent reread,
cursor additions and descendant-before-gap errors are byte-identical.
The entire independent reference.rs is unchanged. No solver aggregate,
leaf shortcut, export change, timer change or subset output is introduced.

All old frame and central tests remain byte-identical. The original two
axis tests transfer in full: 200 appended lines plus the needed single
LogicalPoint import, for +201/-0. Their assertions are unchanged:

- committed_axis_inputs_keep_infinite_extent_and_delayed_error_priority:
  both axes, infinite derived extent, fresh reader order, delayed maxima
  error, override-before-reader and minimum-before-override priorities,
  negative and zero internal override components, independent reference.
- raw_axis_inputs_keep_earlier_geometry_before_later_bad_weights:
  actual raw NaN share and child-order reversal, demonstrating geometry
  error versus NonFiniteWeight priority against the independent reference.

No third witness or framework was added. Removing only that import and
append recreates the complete unified parent test module, including the
existing 55-line frame and 139-line central additions. Existing complete
oracle, central/n-ary/mixed arity, sparse-generation, raw cycle/DAG,
override authority, public invalid-axis, old-output/clone, late geometry
and 10k-depth qualification remain root-owned and were not run here.

## Per-hunk context adaptations

The original fourteen changes are all accounted for below. Each applicable
old body matched once, or at the recorded module EOF for the test append.
No other source delta is authorized. rebase-hunks.json binds original and
applied old/new body hashes plus stage before/after file hashes.

| Original change | Header | Context handling |
| --- | --- | --- |
| 1 | `@@ -339,18 +339,6 @@` | Original old/new hunk body unchanged; only line offsets differ. |
| 2 | `@@ -508,7 +496,7 @@` | Unified values/central leaf route replaces the old measurements call context; false wire unchanged. |
| 3 | `@@ -580,7 +568,7 @@` | Delayed RootMeasurement retains values and scalar route in call context; false wire unchanged. |
| 4 | `@@ -591,7 +579,7 @@` | Unified buffer and concrete CentralRoute arguments retained; same private const parameter added. |
| 5 | `@@ -633,7 +621,7 @@` | Output-construction context uses unified from_values; same generic subtree wire. |
| 6 | `@@ -655,7 +643,7 @@` | Anchor after the successful raw all-true-row/value adapter; preserve adapter in full and add only original true wire. |
| 7 | `@@ -920,7 +908,7 @@` | Original old/new hunk body unchanged; only line offsets differ. |
| 8 | `@@ -933,7 +921,7 @@` | Use call-only exact anchor so unconditional release-prefix assertion and scalar frontier context remain untouched. |
| 9 | `@@ -955,7 +943,7 @@` | Compact frame already removed the layout lifetime; add only const parameter to the existing lifetime-free function. |
| 10 | `@@ -1008,7 +996,8 @@` | Use exact override-selection anchor above binary/generic weight match; preserve every conversion/fallback and bind the same single lookup. |
| 11 | `@@ -1029,8 +1018,15 @@` | Validate and solve with the existing binary-or-generic axis_constraints slice; unchanged input order and output slice. |
| 12 | `@@ -1139,18 +1135,23 @@` | Original old/new hunk body unchanged; only line offsets differ. |
| 13 | `@@ -1,4 +1,5 @@` | Original old/new hunk body unchanged; only line offsets differ. |
| 14 | `@@ -1098,3 +1099,203 @@` | Append the original exact 200-line test addition at the new module EOF after preserved frame/central witnesses; no assertion adaptation. |

## Costs, limits and source receipts

Only layout.rs changes at runtime, +30/-29, below the 50-added-line bound.
The test module is +201/-0. Projection/topology/reference are complete
unchanged context files, not patch targets. The removed source work is
redundant committed-axis validation, not desired weight normalization,
feasibility arithmetic, full fresh measurement, gather, scratch, output
or export work. No backing owner is removed by this axis slice.

Const specialization may duplicate code; branch/inlining/code layout can
outweigh very small binary scans. Selected overrides and raw projection
still execute full checks. Unified values retain the parent's negative
minimum-only/discard rect initialization and scratch-record costs. No
allocator count/bytes/share, speedup or target progress is established.
Do not combine this slice with an unqualified parent and then attribute
all changed timing to it. Root must bind the actual retained parent and
qualify/compare this separate variant.

| Source under crates/dockspace/src | Base SHA-256 | Candidate SHA-256 |
| --- | --- | --- |
| `layout.rs` | `478cf5a1f3c6cf41cd3f21f3dfdc301a350957f18f58f900376edb256e38c05e` | `dc32cdecddbb742f5d6d225d48e80c2170facb385364c7deefc724e709fc367a` |
| `layout/projection.rs` | `1a54741ad89e01e2011a35d1f60c4896f2af7fe5b375d4df4d105318b8b4cfa9` | `1a54741ad89e01e2011a35d1f60c4896f2af7fe5b375d4df4d105318b8b4cfa9` |
| `layout/reference.rs` | `2b2eee151d88bdd83048f0dfe7a4931a769aff6616da59e060200819008b209a` | `2b2eee151d88bdd83048f0dfe7a4931a769aff6616da59e060200819008b209a` |
| `layout/topology.rs` | `1dc1264af676b5a083a299332203057b02004d174c8d4e27e45c6074f513a26c` | `1dc1264af676b5a083a299332203057b02004d174c8d4e27e45c6074f513a26c` |
| `layout/topology_tests.rs` | `31c5e094b6c48cd58922de2642a08e223d1f5606f00463d1387e94a08ff93a2b` | `c02cc43844bc72a0b35186663c697e68b8838fc8f683fc8b80695f14b141974c` |

Primary patch SHA-256: `8098b3d4c0a6aa190c1d31ef38fc01efec8ee6954fb5018316c06b441943ff03`.
Five-file base set: `109d73f5d982031e413a70b3d4481330ed729de4f36b588587ec166f696cd9e3`.
Tree set: `42ae386dea13374a5643c95f7302136895de18e3513586bdd8631522c6367e97`.

Set format is ascending UTF-8 relative path + NUL + file SHA-256 + newline.
All 43 static preservation/reconstruction checks pass. The primary patch
exactly reconstructs complete outputs and passes read-only
`git apply --check --whitespace=error` in its temporary base. Only the two
temporary changed tree files were formatted, edition 2024 with
skip_children=true. Rust best-practices was read before edits. No Rust
compilation or behavior was executed. base-manifest.json, rebase-hunks.json,
scope-checks.json, manifest.json and READY.json bind stationary sources.
Apply matching hunks rather than overwriting later complete repo files.
