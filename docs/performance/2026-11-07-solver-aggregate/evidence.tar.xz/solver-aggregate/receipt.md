# Solver aggregate reuse: prepared patch receipt

Status: PREPARED IN /tmp ONLY; STOPPED pending root's decision after freezing A1 + linear references. No repository source edit, Cargo/build/test execution, benchmark or timing. No speedup is forecast or claimed.

## Artifacts and exact base

- `layout.rs`: complete candidate copy, including one registered error-boundary unit test.
- `base-layout.rs`: byte-for-byte copy of the current workspace file before this candidate.
- `solver-aggregate.patch`: unified patch with exact `a/crates/dockspace/src/layout.rs` and `b/crates/dockspace/src/layout.rs` paths; only that repository path would change if root applies it.
- Base SHA-256: `354f015c74a2e942d006d7c1e510a26df3f43ebf49e42bf0763687ab38fdd44f`.
- Candidate SHA-256: `f46c9e5c3d6659263995604fc4e28a1839ed3ae3f1bdbac4ba39f1b4d174d16b`.
- Patch SHA-256: `c1e9e5788c922d2042378b8dc22545cf373ca39be476e4c439d27441802b6937`.
- Patch size: 54 added and 11 removed lines. Workspace `layout.rs` was reread and still equals the preserved base when generating this patch.

## Exact implementation

The private `validate_inputs` now returns the already-computed finite `weight_total` after its unchanged zero-total check. Both owned and caller-owned solve entry points validate at their original point and pass that scalar through the private solve call. The feasible noncentral desired-size loop consumes it directly. The central branch still runs its original ordered sibling-only sum, scale, desired-size sum and residual assignment.

The first clamped assigned-size sum remains. Either grow/shrink branch performs its unchanged mutation and then recomputes assigned. If neither branch executes, the first scalar is retained for the existing residual/tolerance calculation.

No public signature, leaf input, topology, output layout, projection/solver scratch allocation, binary special case or timer changes. `layout/reference.rs` and all other repository files remain untouched.

## Arithmetic and error equivalence argument

1. The reused weight sum is the result of the same `checked_sum(weights.iter().copied(), "weight")` in the same validation call. Weights remain immutably borrowed until use. The deleted later noncentral sum reads the identical slice in the identical order; it cannot have a new error or a different result after validation succeeds. No reassociation or replacement numerical formula is introduced.
2. The first assigned sum is checked finite before branch selection. When neither comparison triggers, sizes are unchanged; the deleted second sum would repeat the same ordered inputs and reproduce the same scalar bits. After either branch, the original post-mutation checked sum still executes before tolerance/residuals.
3. All extent/cardinality/central/scalar/weight-aggregate checks remain in their original order. Validation still occurs before the public owned allocation and before caller-owned writes. Empty input still validates before its early return.
4. Both minimum and maximum checked sums remain before either infeasible exit, in their original order. Central behavior, min/max arithmetic, f32 conversion, water filling, eligible-set iteration, tolerance and residual formulas are unchanged.

## Coverage and validation status

Reuse the existing registered `layout::topology_tests::caller_owned_axis_matches_frozen_solver` property for owned-axis output bits and residual bits, plus `dense_layout_matches_frozen_traversal` for the actual caller-owned projection path and every rich output field. The active owned-output and 10k tests remain part of root's ordinary gate. No existing test or independent oracle is modified by this patch.

Added exactly one small registered test inside `layout.rs::tests`: `solver_aggregate_errors_precede_infeasible_minima`. For central and noncentral inputs with infeasible positive minima and overflowing finite maxima, it checks weight-aggregate overflow priority and maximum-aggregate overflow before the infeasible-minimum exit. It asserts expected errors against the unchanged frozen solver and the owned/caller-owned implementations; caller-owned sizes retain their sentinel values on failure. This adds the relevant error-boundary coverage absent from the existing finite-domain property, without another test framework or helper hierarchy.

Only direct `rustfmt --edition 2024 --config skip_children=true` ran on the temporary candidate. The unified diff was read back; its production hunks are confined to the private aggregate data flow and no-mutation sum reuse. Syntax formatting is not typechecking or executed correctness evidence. Root should retain the frozen A1 + linear binary, decide whether to apply this exact-base patch, then perform its serial compile/tests and unchanged paired comparison. This lane has stopped without applying it.
