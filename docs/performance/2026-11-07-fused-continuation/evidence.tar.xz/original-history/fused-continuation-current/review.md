# Independent review: fused continuation on the current packed-output parent

**Findings first.** No source blocker was found in this mechanical rebase. It reproduces the original two control-flow edits, preserves packed child-result writes and the current SmallVec stack, and retains the previously reviewed semantic event order. It is suitable for Root's separate qualification if that exact parent is selected.

The parent is immutable `eb94cb242722962c9e0d88074d81cf462d784357` plus the exact SmallVec overlay currently under qualification. This report does not claim that SmallVec is qualified or retained, nor that the fused slice is applied, tested, or beneficial. If SmallVec is rejected or the parent changes, this frozen review does not silently approve a new rebase.

Only this report was written. No repository, cache, fork, candidate, or other report was modified; no Cargo, compilation, formatting, test, runner, timing, profiler, network, or delegation was performed.

**Frozen identities and composition.**

| Artifact | SHA256 |
| --- | --- |
| Current `manifest.json` | `73a317419c05be075289f9973d4e52a32fa175c8e348a82194615ebe6ca2e0de` |
| Current `candidate.patch` | `70ab68c662bc7413bc6fd8320b7985366f69423429a2233d783ccd602946cf5f` |
| Immutable eb94 `layout.rs` | `ee0bbdadf60b10a3787539e89cdee41411301c3c774e66d53c0146ad1567eaec` |
| Frozen base `layout.rs`, including SmallVec | `b90c461b9c805463b4e355db58487f21ef0384ccd72ccb0913eef8236b65ee02` |
| Frozen candidate `layout.rs` | `57c32e5a6a20c2a9250ca4e5ace68d23097ce1431cef3d0155b5f35e7d9f1cd5` |
| Original reviewed fused patch | `770468faadc611c73934b92eadd7c8c0feeb234269dc3215aab37f2ef042c6d4` |

All recorded current source/patch hashes match. Independently applying the three literal SmallVec source edits to immutable eb94 exactly reconstructs the frozen base: import, stack initialization, and the advance helper's stack parameter. This also matches the layout source hash in `B/smallvec-stack-application.json`. The original SmallVec author snapshot remains based on 07f566a; its whole file is not substituted for the newer packed-output parent.

Applying the two original fused edits to that frozen base exactly reconstructs the candidate. Independently interpreting the current unified patch in memory produces the same bytes. The only runtime path is `crates/dockspace/src/layout.rs`, with two hunks and +1/−3 lines. The second hunk's context correctly uses `ChildResult.following_gap = Some(splitter)` rather than the original separate splitter array.

**Preparation and packed output are unchanged.** Candidate lines 981–991 retain the same Enter/prefix check and one call to `prepare_split_projection`. Only its successful Some(state) continuation is advanced immediately, instead of pushed and immediately popped on the next outer iteration. The old interval contains no reader callback, publication, validation, or other scheduled frame. A leaf and a preparation error follow their original paths.

The preparation body is byte-identical to this base. In particular, it still writes each child's minimum/maximum, resets `following_gap` to None, selects the actual override or durable weights, initializes binary/local or generic `scratch.sizes`, calls the same fully checked solver, and copies every solved size into the corresponding packed child extent before writing the split outcome (`1059–1134`). The existing sizes initialization, generic resize, and size-copy loop are neither removed nor moved across a failure point. This slice claims no saving from those copies.

**Descendant/gap/next-child ordering is preserved.** Candidate `advance_split_projection:1187–1237` still resumes only after the preceding descendant finishes. It clears pending, reads that parent's previous child extent, adds it to cursor, constructs the nonfinal child's following gap with the original fallible geometry calls, stores Some(splitter), and adds thickness. It then checks completion or constructs the next child's bounds before scheduling that Enter.

The removed pending-branch push/return only requeued the same cleared state. The original next iteration immediately popped it and reread immutable topology and the parent NodeMap rectangle. The intervening write is now a packed record's `following_gap` field; it does not modify that rectangle, any child extent, or topology. Eliminating the repeated prefix therefore changes no facts observed by the next-child block.

A descendant error still wins over its parent's late gap error. Gap construction/write still precedes the next child's cardinality/bounds checks and preparation. Cursor additions, solver overflow computation, Option-gap initialization/writes, final-child no-gap behavior, and all `?` propagation points remain ordered as before. No arithmetic or geometry check was hoisted.

**Raw DAG, depth, and ownership.** The remaining push order is unchanged: parent suspension, then child Enter. Thus actual Enter row/bounds sequences, including completed-subtree revisits, remain identical. Raw node/split last writes and distinct parent-edge extents/gaps retain the same behavior. A pending parent still obtains its extent from its own packed child range, not from a shared child's final rectangle.

The release first-visit-prefix guard still runs for every actual Enter; raw cycle/measurement diagnostics and central routing are unchanged. Direct advancement only schedules a child and returns. It does not recursively enter descendants, add a fixed depth limit, or change the current SmallVec's ordinary dynamic spill. State/enum/scratch definitions and all remaining pushes/pops retain their base representation.

The packed child owners, NodeMap, clone behavior, immutable topology sharing, and private-failure discard remain untouched. No returned old output acquires a mutable alias. The reference executor and semantic-test bodies are outside the one-file patch and unchanged by this slice.

**Cost boundary and handoff.** The source dispatch reduction remains the original one: for k children, ContinueSplit dispatch pairs go from `1 + 2k` to k and helper calls from `1 + 2k` to `1 + k`, while child Enter pushes remain k. These are source counts, not measured instruction or latency results.

The removed pushes do not avoid a SmallVec spill or growth. They restore a just-popped height, and pinned SmallVec 1.16.4 `pop` only reduces length and moves out the item; it does not shrink capacity or automatically unspill (`src/lib.rs:1245–1255`). Remaining peak-depth scheduling and storage costs persist. Code layout, inlining, branches, and live ranges may still make the experiment improve or regress.

This patch contains no timer, fresh-input Adapter, complete export, work-counter, dependency, lockfile, or runner change. Their existing work is not removed by fusing these transitions. Root should use the existing complete oracle/error-order, raw-sharing, old-output, and genuine deep-tree qualification, then the unchanged complete-operation comparison. No new mirrored transition test or performance attribution is supplied by this source review.
