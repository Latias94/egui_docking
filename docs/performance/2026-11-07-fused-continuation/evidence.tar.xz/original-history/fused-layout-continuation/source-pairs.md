# Complete immutable source pairs

Parent: `07f566ac8fbddfab819f46f613d55bc2069507dd`. All base files are exact immutable Git blobs; no live worktree source.
Only `layout.rs` changes. The remaining seven complete pairs are byte-identical context.

| Relative path | Base SHA-256 | Candidate SHA-256 | Bytes (base / candidate) | Role |
| --- | --- | --- | ---: | --- |
| `crates/dockspace/src/docking_cost.rs` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` | `01d8438fc79095aacae935170aff3ed7eb8b5e497aa368c9966889b789adf2d3` | 30626 / 30626 | unchanged_context |
| `crates/dockspace/src/geometry.rs` | `3f4912b953fbb5a39b12f718370be8b133354f7a155609896156680d3d7b6541` | `3f4912b953fbb5a39b12f718370be8b133354f7a155609896156680d3d7b6541` | 15560 / 15560 | unchanged_context |
| `crates/dockspace/src/layout.rs` | `478cf5a1f3c6cf41cd3f21f3dfdc301a350957f18f58f900376edb256e38c05e` | `d31989b6a63fcf7dd4235b11f50c17ec6231497233d3333b4ee7d49b3758abfd` | 50341 / 50276 | runtime |
| `crates/dockspace/src/layout/layout_cost.rs` | `420140d7cca7915966e0103c06ad27453d8b8fddba5f13a090dcab0d9691250e` | `420140d7cca7915966e0103c06ad27453d8b8fddba5f13a090dcab0d9691250e` | 7869 / 7869 | unchanged_context |
| `crates/dockspace/src/layout/projection.rs` | `1a54741ad89e01e2011a35d1f60c4896f2af7fe5b375d4df4d105318b8b4cfa9` | `1a54741ad89e01e2011a35d1f60c4896f2af7fe5b375d4df4d105318b8b4cfa9` | 11330 / 11330 | unchanged_context |
| `crates/dockspace/src/layout/reference.rs` | `2b2eee151d88bdd83048f0dfe7a4931a769aff6616da59e060200819008b209a` | `2b2eee151d88bdd83048f0dfe7a4931a769aff6616da59e060200819008b209a` | 28186 / 28186 | unchanged_context |
| `crates/dockspace/src/layout/topology.rs` | `1dc1264af676b5a083a299332203057b02004d174c8d4e27e45c6074f513a26c` | `1dc1264af676b5a083a299332203057b02004d174c8d4e27e45c6074f513a26c` | 8311 / 8311 | unchanged_context |
| `crates/dockspace/src/layout/topology_tests.rs` | `31c5e094b6c48cd58922de2642a08e223d1f5606f00463d1387e94a08ff93a2b` | `31c5e094b6c48cd58922de2642a08e223d1f5606f00463d1387e94a08ff93a2b` | 46445 / 46445 | unchanged_context |

Set hash format: sort complete UTF-8 relative path strings by encoded bytes, then
`SHA256(concat(path + NUL + per-file SHA-256 + newline))`.

Base set: `112fbfb6b4021434036140d4df6d402be33b372e45fff26640b96d8a12785217`.
Candidate set: `39ed835a418220c133a4fcb368feedaf259b8f40bee6731f76ec04fa14433d48`.

The primary patch is exactly two hunks, one runtime path, +1/-3 lines. Applying its
hunks in memory to the immutable base reconstructs the complete candidate exactly.
No source file was compiled, formatted or executed.
