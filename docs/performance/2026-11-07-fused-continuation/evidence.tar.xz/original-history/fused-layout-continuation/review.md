# Independent source review: fused layout continuation

**Findings first.** No source blocker was found. The two edits preserve preparation timing, descendant-before-gap order, gap-before-next-child geometry/error order, actual child Enter order, and raw DAG revisit behavior. This exact candidate is suitable for Root's ordinary qualification and complete-operation comparison. It is not compiled, behavior-qualified, or performance-qualified by this review.

The cost statement is appropriately narrow: the removed pushes cannot themselves grow the Vec, because each restores a height just popped from that same Vec. No allocation saving or share of the earlier RawVec samples follows from this patch. No corrective source change is requested.

This review read the frozen package and immutable Git objects. It did not change repository, cache, fork, candidate sources, or other reports; invoke Cargo, compilation, formatting, tests, runners, benchmarks, timing, or a profiler; use the network; or delegate work. Only this report was written.

**Exact evidence binding.**

| Artifact | Independently checked identity |
| --- | --- |
| Immutable parent | `07f566ac8fbddfab819f46f613d55bc2069507dd` |
| `manifest.json` SHA256 | `8b12b2842b00682e5da515e3ea2860cd36e93faf0a49beddaacfaca6f46c75cb` |
| `candidate.patch` SHA256 | `770468faadc611c73934b92eadd7c8c0feeb234269dc3215aab37f2ef042c6d4` |
| Base `layout.rs` SHA256 | `478cf5a1f3c6cf41cd3f21f3dfdc301a350957f18f58f900376edb256e38c05e` |
| Candidate `layout.rs` SHA256 | `d31989b6a63fcf7dd4235b11f50c17ec6231497233d3333b4ee7d49b3758abfd` |
| Eight-file base-set SHA256 | `112fbfb6b4021434036140d4df6d402be33b372e45fff26640b96d8a12785217` |
| Eight-file candidate-set SHA256 | `39ed835a418220c133a4fcb368feedaf259b8f40bee6731f76ec04fa14433d48` |

Every complete base source equals its recorded immutable Git blob, including blob ID, length, and SHA256. Both base/tree path sets exactly match the eight-path manifest. Seven context files are unchanged: geometry, projection, topology, reference, topology tests, layout cost probe, and the formal complete-operation probe. Every listed artifact/input hash matches. The candidate sources were independently reconstructed both from the two expected edits and by interpreting the unified patch in memory. Both reconstructions equal the frozen tree, with precisely two hunks, one runtime path, one added line, and three deleted lines.

This is the fully checked retained parent. No rejected axis specialization, packed-output representation, SmallVec, inline hints, or other source change is included. All test sources and the independent reference executor are byte-identical to parent.

**Preparation and first descent.** In candidate `tree/crates/dockspace/src/layout.rs:956–997`, the outer loop still pops an Enter, runs its release first-visit-prefix guard, and calls the unchanged `prepare_split_projection` once. That preparation still records the current rectangle, obtains constraints/actual overrides, performs the fully checked `solve_axis_into`, writes min/max/actual extents and outcome, updates central routing, and returns the same owned split state. Preparation errors propagate before advancement; a leaf still returns None.

At line 987, the candidate immediately calls the same advance helper. The original instead pushed ContinueSplit and immediately popped/dispatched it on the next iteration. No callback, validation, publication, counter, cancellation hook, or other frame can intervene: the newly pushed frame is the top of the same LIFO stack. The fresh leaf reader is consumed in the preceding measurement stage, not by this loop dispatch.

The helper creates the first child bounds at the same point relative to all fallible work, then still pushes the parent suspension followed by the child Enter. The next actual Enter has the same row and rectangle and executes the same guard and preparation. The change adds no native recursion: `advance_split_projection` schedules a child and returns; it does not enter that child itself or call itself.

**Return, gap, overflow, and next-child order.** Candidate lines 1167–1209 preserve the critical sequence after a descendant completes:

1. Pop the parent's pending continuation and read its immutable kind/children and current stored parent bounds.
2. Clear pending, read the preceding extent from this parent's output range, and add it to the cursor.
3. For a nonfinal child, construct the gap with the original axis/coordinates/thickness, propagate any geometry error, write the same gap slot, and add thickness to the cursor.
4. Return for the final child; otherwise check/get the next child, read its parent-specific extent, and construct its bounds before scheduling its Enter.

The deleted lines only pushed the cleared state and returned between steps 3 and 4. The old next iteration immediately popped that state, reread the same helper prefix, skipped pending, and executed step 4. In that interval topology is immutably borrowed and the only intervening result write was to the separate splitter-rectangle buffer. It cannot change the parent's NodeMap rectangle or kind. Thus eliminating the repeated prefix cannot lose a newly observable MissingNode result or change the bounds bits.

No geometry operation or floating addition moved across a descendant. A descendant failure still precedes its parent's late gap failure. A parent gap failure still precedes the next child's bounds failure and preparation. A final child still adds its extent but creates no following gap. Cursor overflow, `LogicalRect::new` checks, child-cardinality handling, and propagation through `?` remain at the same semantic positions. Private partial results are discarded on the same errors.

**Raw sharing and ownership.** The sequence of actual Enter rows/bounds is unchanged, including completed-subtree revisits. Consequently raw DAG node/split last-write semantics are unchanged. A pending parent still reads its own solved extent range, not an extent inferred from a shared child's later rectangle. Acyclicity prevents a descendant from overwriting that ancestor's own row/range; existing raw active-cycle and malformed/missing-node checks have not been altered.

The release prefix assertion still runs on every actual Enter, including allowed older-row revisits. The dynamic Vec, continuation enum/state/pending flag, remaining suspension/Enter pushes, and arbitrary-depth behavior remain. State fields have no user-defined destructor or borrowed stack storage whose observable lifetime depended on the deleted move/pop interval.

Owned NodeMap/SplitMap storage, initialization, arithmetic, writes, Clone implementation, and shared immutable topology/payload ownership are unchanged. No successful or failed new projection can mutate a previously returned projection through these edits. Reference measurement/projection remains its independent original implementation, rather than adopting the fused control flow.

**Cost and qualification limits.** For a successful prepared split with k children, source ContinueSplit dispatch pairs change from `1 + 2k` to `k`, and helper calls from `1 + 2k` to `1 + k`; actual child Enter pushes stay k. These source-event counts match the frozen event trace. They are not generated instruction counts or measured savings.

Each deleted push only restores the height of the Enter or ContinueSplit frame just popped, while Vec capacity remains unchanged. It therefore cannot trigger growth. The remaining child suspension pushes, allocation/growth behavior, all output owners, gather/numeric scratch, and fresh materialization remain. A compiler may already fold the original dispatch; the added call site and longer local live ranges may also change inlining, code placement, register pressure, or performance negatively. The prior selected growth samples provide no quantitative benefit estimate for this candidate.

No new mirrored control-flow test is necessary for this two-edit scope. Root's qualification should retain the existing oracle/property comparisons and semantic witnesses, especially `descendant_geometry_error_precedes_parent_gap_geometry_error`, `owned_node_rows_keep_previous_outputs_after_late_geometry_error`, `raw_shared_central_subtree_keeps_membership_in_both_parent_branches`, `completed_subtree_reuse_keeps_active_cycle_and_leaf_error_order`, minimum/override priority coverage, old-output/Clone ownership, and `projects_ten_thousand_nested_splits_without_call_stack_growth`. Their source bodies are preserved, but this review does not claim to have executed them. Retention still requires the unchanged full operation protocol and its negative cells.
