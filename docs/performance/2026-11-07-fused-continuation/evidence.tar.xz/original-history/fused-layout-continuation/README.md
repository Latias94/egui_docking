# Fuse immediate layout continuation dispatch

READY / source stationary / not qualified. The candidate has one runtime file,
`crates/dockspace/src/layout.rs`, with +1/-3 lines across two hunks. It changes
continuation control flow; it does not change storage, arithmetic or validation.

Only this new temporary directory was written. No repository, fork, cache,
Git state, dependency or previous candidate was changed. No Cargo, compiler,
formatter, test, runner, timing, benchmark, profiler, network or child agent was
used. Root owns source review, execution, qualification and retention.

## Exact immutable base and two edits

All eight complete base/tree context pairs come from immutable Git blobs of
`07f566ac8fbddfab819f46f613d55bc2069507dd`. No live worktree source, axis
specialization, inline hints, packed outputs or SmallVec change is included.
`base-manifest.json` records exact commit/path origins, blob IDs and hashes.

The runtime changes are exactly:

1. When an Enter's original prepare returns Some(state), call the existing
   advance_split_projection helper directly instead of pushing a ContinueSplit
   frame solely for the next loop iteration.
2. After the pending_child branch performs its original cursor update and
   late gap construction/write, fall through to the original terminal or
   next-child block instead of pushing the same cleared state and returning.

The original enum, state fields, pending flag, dynamic Vec, helper body
arithmetic, child ordering and remaining suspension/Enter pushes remain.
No new container, cache, provider, trait, executor, hint or proof is added.
Prepare, the original fully checked solve_axis_into entry, numerical solver,
validators, constraints gather, central routing, fresh inputs and complete
output representation are unchanged.

## Static semantic trace

`event-sequence.md` gives the exact original and candidate next events,
including first child, nonfinal/final return, errors, raw revisits and depth.
The old removed interval has no reader callback, publication, validation or
other semantic hook. It performs an immediate local state push/pop/dispatch.
The parent topology is immutable and gap writes cannot change NodeMap bounds,
so the eliminated second helper-prefix read would return identical values.

Gap construction still occurs after the preceding descendant returns and
before constructing the next child bounds. Every geometry operation, cursor
addition, error propagation point and actual child Enter remains ordered as
before. The helper does not recursively enter children: it pushes the same
suspension and child frames and returns to the outer loop. Arbitrary depth
continues to use the dynamic Vec.

The exact source trace preserves raw completed-subtree revisits and node/split
last-write behavior. No parent extent is inferred from a shared child's final
rect. Release first-visit prefix rejection, raw cycle errors, private failure
discard, old-output ownership and Clone remain.

For each prepared split with k>=1 children, source ContinueSplit dispatch
pairs change from 1+2k to k, and helper calls from 1+2k to 1+k. Actual child
Enter events, preparation, solve and output writes are unchanged. These are
source event identities, not executed instruction counts or timing results.

## Existing diagnostic sample, without performance attribution

The preexisting `B/layout-hotspot` sampling driver, receipt, source binding
and two sample files are copied unchanged under `inputs/layout-hotspot/`.
The driver materializes fresh leaf answers, builds all complete root outputs,
then consumes/disposes the complete returned Vec at each loop statement.
It is explicitly a sampling-only layout Adapter, not the formal complete
request/mutation/layout/export operation.

The selected project_measurements grow_one call-graph frame has 266 samples
against 2945 main-thread samples for one view, and 217 against 2887 for four
views. `diagnostic-observations.json` records the exact frame lines/hashes.
These are diagnostic counts, not formal time shares or exclusive allocator
attribution. Other grow_one appearances exist; they are not silently combined
with or assigned to this selected frame.

This lane did not run the sampling driver or a profiler. The inspected copied
core layout source hash matches immutable control. The diagnostic harness's
private-module visibility setup does not become part of this candidate.

The eliminated pushes only restore the frame height just popped; Vec capacity
has not shrunk. They therefore cannot themselves be the growth events shown
in the samples. This control-flow candidate should not be sold as eliminating
that sampled allocation cost, nor should its expected gain be estimated from
those counts.

## Costs, evidence and handoff

Fewer source dispatches may have little generated-code effect if optimization
already folds the roundtrip. A new helper call site can change inlining and
code placement; falling through can extend local live ranges. Instruction
footprint, register pressure and branch behavior may regress some cells.
The existing Vec allocation/growth, all result buffers, gather/input scratch,
full output disposal and fresh materialization remain. No dependency/allocator
byte saving or operation speedup is claimed.

`scope-checks.json` records exact two-edit whole-file reconstruction, immutable
source hashes, twenty unchanged numeric/boundary functions, unchanged enum/
state/scratch and semantic test bodies, absence of other candidate changes,
and all seven unchanged context files. There are no new tests or test hunks.
Exact primary patch reconstruction and read-only
`git apply --check --whitespace=error` pass in the temporary base. These
static checks do not compile or execute Rust.

The unchanged existing suite provides meaningful qualification: complete
reference/oracle comparisons; descendant-before-gap and late owned-output
geometry errors; raw central shared-subtree and active-cycle/leaf-priority
cases; sorted/recycled generational identity; delayed minimums/overrides;
Clone after owner destruction; and genuine 10k-depth projection. Root should
run that suite and the complete operation protocol before any retention claim.
No mirrored transition simulation or storage-form test is introduced.

`manifest.json`, `source-pairs.md` and READY bind the exact patch and complete
sources using UTF-8 relative-path-string ordering. `review-request.md` is the
independent review brief. All other temporary candidates remain stationary.
