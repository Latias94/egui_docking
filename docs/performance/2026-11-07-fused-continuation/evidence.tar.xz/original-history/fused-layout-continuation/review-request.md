# Independent source review request

Target: `/tmp/fused-layout-continuation/`.
Parent: immutable `07f566ac8fbddfab819f46f613d55bc2069507dd`.
Patch SHA-256:
`770468faadc611c73934b92eadd7c8c0feeb234269dc3215aab37f2ef042c6d4`.

The exact two-hunk layout.rs change is +1/-3: directly advance after an Enter
prepares a split; after a pending-child return and the original late gap work,
fall through instead of pushing an immediately re-popped cleared continuation.
No prepare, numeric, validator, enum, pending-flag, dynamic-container, input
or result representation change is included.

Please challenge the manual original/next-event trace in event-sequence.md:
late parent gaps must still follow descendant work, next-child geometry must
remain after that gap, raw DAG revisits/last writes and parent-specific extents
must persist, and 10k depth must not gain native recursion.

The deleted rounds have no semantic hook and cannot be Vec growth pushes:
they restore just-popped heights whose capacity already existed. Diagnostic
grow_one samples include complete output drop and do not estimate this
candidate's benefit. No execution, formatting or performance claim is made.
Root owns verification after independent source review.
