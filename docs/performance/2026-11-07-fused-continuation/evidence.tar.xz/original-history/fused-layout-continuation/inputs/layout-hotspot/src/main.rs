//! Sampling-only fresh layout workload; not a complete-operation benchmark.
use std::hint::black_box;
use dockspace::geometry::{Constraints, LogicalRect, LogicalSize};
use dockspace::graph::{Axis, Node, RootRecord, SurfacePresentation, Workspace, WorkspaceBuilder};
use dockspace::ids::{ItemId, NodeId, RootId, SurfaceId};
use dockspace::layout::{LayoutMetrics, LayoutProjection, project_root};
struct Fixture { workspace: Workspace, bounds: LogicalRect, metrics: LayoutMetrics }
struct RootProjection { ordinal: u64, root: RootId, layout: LayoutProjection }

fn opposite(axis: Axis) -> Axis {
    match axis {
        Axis::Horizontal => Axis::Vertical,
        Axis::Vertical => Axis::Horizontal,
    }
}

fn tree(builder: &mut WorkspaceBuilder, first: usize, count: usize, axis: Axis) -> NodeId {
    if count == 1 {
        let first = u64::try_from(first).unwrap() * 2 + 1;
        return builder.insert_node(Node::tabs([ItemId::new(first), ItemId::new(first + 1)]));
    }
    let half = count / 2;
    let left = tree(builder, first, half, opposite(axis));
    let right = tree(builder, first + half, half, opposite(axis));
    builder.insert_node(Node::equal_split(axis, [left, right]).unwrap())
}

fn bounds(width: u64) -> LogicalRect {
    LogicalRect::new(0.0, 0.0, f64::from(u32::try_from(width).unwrap()), 16_380.0).unwrap()
}

fn collect_constraints(
    workspace: &Workspace,
    node: NodeId,
    leaf: Constraints,
    constraints: &mut Vec<(NodeId, Constraints)>,
) {
    match workspace.node(node).unwrap() {
        Node::Tabs { .. } => {
            constraints.push((node, leaf));
        }
        Node::Split { children, .. } => {
            for &child in children {
                collect_constraints(workspace, child, leaf, constraints);
            }
        }
    }
}

fn project_all_roots(fixture: &Fixture) -> Vec<RootProjection> {
    let leaf = Constraints::new(
        LogicalSize::new(0.0, 0.0).unwrap(),
        LogicalSize::new(65_536.0, 65_536.0).unwrap(),
    )
    .unwrap();
    fixture
        .workspace
        .surfaces()
        .enumerate()
        .map(|(view, (_, presentation))| {
            assert!(
                presentation.contained.is_empty(),
                "primary matrix has no floating roots"
            );
            let root = presentation.main_root.unwrap();
            let mut constraints = Vec::new();
            collect_constraints(
                &fixture.workspace,
                fixture.workspace.root(root).unwrap().node,
                leaf,
                &mut constraints,
            );
            let mut constraints = constraints.into_iter().peekable();
            RootProjection {
                ordinal: u64::try_from(view + 1).unwrap(),
                root,
                layout: project_root(
                    &fixture.workspace,
                    root,
                    fixture.bounds,
                    |node| {
                        constraints
                            .next_if(|(id, _)| *id == node)
                            .map(|(_, constraints)| constraints)
                    },
                    fixture.metrics,
                )
                .unwrap(),
            }
        })
        .collect()
}

fn main() {
    let views: usize = std::env::args().nth(1).unwrap().parse().unwrap();
    let iterations: usize = std::env::args().nth(2).unwrap().parse().unwrap();
    let mut builder = Workspace::builder();
    for view in 0..views {
        let ordinal = u64::try_from(view + 1).unwrap();
        let node = tree(&mut builder, view * (16 / views), 16 / views, Axis::Horizontal);
        builder.set_root(RootId::new(ordinal), RootRecord::new(node));
        builder.set_surface(SurfaceId::new(ordinal), SurfacePresentation::with_main(RootId::new(ordinal)));
    }
    let mut fixture = Fixture { workspace: builder.build().unwrap(), bounds: bounds(16_380), metrics: LayoutMetrics::new(4.0).unwrap() };
    let witness = project_all_roots(&fixture);
    assert_eq!(witness.len(), views);
    assert_eq!(witness.iter().map(|p| p.layout.nodes.len()).sum::<usize>(), 32 - views);
    drop(witness);
    println!("ready: {views} views, {iterations} fresh layouts");
    for iteration in 0..iterations {
        fixture.bounds = bounds(if iteration % 2 == 0 { 16_380 } else { 16_444 });
        black_box(project_all_roots(black_box(&fixture)));
    }
    println!("completed");
}
