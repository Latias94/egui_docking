# Static event trace for fused projection continuation

This is manual source reasoning over immutable 07f566a and the two-edit
candidate, not a simulation or executed test. A semantic event means an
Enter/prefix check, preparation/solve, result write, fallible geometry operation,
or descent/return ordering visible through the owned result or LayoutError.
Instruction count and elapsed time are intentionally allowed to change.

Let T be the stack tail of suspended ancestors, E a child Enter, and
C(i,p) this split's continuation with next_child=i and pending_child=p.
Every existing parent/child push uses LIFO order: push C, then push E.
Let k be the direct child count of a prepared split.

## First child after Enter

Preparation, including its release prefix check, current node rectangle,
full checked axis solve and split outcome, is unchanged.

| Original next events | Candidate next events |
| --- | --- |
| Enter returns Some(C(0,false)); push C(0,false) above T. | Enter returns Some(C(0,false)); call the same advance helper immediately. |
| End match/iteration; pop that same C; dispatch ContinueSplit; call advance. | No intervening dispatch. |
| Decode the split; borrow children and stored parent bounds; skip pending branch; check next_child==k; read child/extent; construct first child bounds. | The same helper performs exactly these operations. |
| Increment next_child, set pending=true; push C(1,true), then E(child0). | The same statements produce the identical stack T,C(1,true),E(child0). |

The next Enter identity and bounds, visited-prefix behavior, result contents and
possible geometry error are identical. A preparation error propagates at the
same `?` before either path reaches advance. A leaf returns None and its Enter
branch remains unchanged. No second prepare/solve is introduced.

## Return from a child

Both versions pop C(i,true) only after the preceding descendant has finished.
They perform the same helper prefix and pending branch:

1. Decode immutable parent kind/axis/children and read its stored bounds.
2. Clear pending_child.
3. Read this parent's preceding child extent and add it to cursor.
4. If i<k, construct the following gap using the original coordinates/thickness,
   store it in the same slot, then add the original thickness to cursor.

The only difference after these operations is:

| Original next events | Candidate next events |
| --- | --- |
| Push C(i,false) above T; return to the loop. | Fall through inside the current helper. |
| Pop that same C; dispatch ContinueSplit; decode the same immutable parent and read the same bounds again; skip pending. | Reuse the already read parent facts/bounds; pending is already false. |
| If i==k, return; otherwise read child i and its stored extent, then construct its bounds. | Execute that same terminal/next-child block. |
| For another child, increment i, set pending=true, push C(i+1,true), then E(child i). | Execute the identical statements in identical order. |

For the final child, neither version makes a gap. Both finish the split before
the next ancestor frame in T can run. For a nonfinal child, both construct the
parent gap before the next child bounds and next Enter. A gap failure returns
at the same `?`; a next-child bounds failure remains after that gap write.
The existing descendant-before-parent-gap witness therefore keeps the same
ordered fallible events.

## Why the removed intervals carry no semantic observation

After an initial Enter, the removed interval contains only the push of the
new state, loop backedge, pop/match dispatch and the helper prefix. No callback,
publication, policy check, validator, progress/cancellation hook or ledger
operation runs between loop iterations. The fresh leaf reader is consumed in
measurement before projection, not by this continuation dispatch.

After a pending child, the repeated helper prefix cannot observe a different
parent. RootStructure and its payloads are immutably borrowed. The only write
since its preceding parent-bounds read is to the split-gap array; that cannot
change NodeMap's parent rectangle or topology. Cursor/pending are owned scalar
state carried unchanged through the old roundtrip. Hence the old second read
would return the same bounds bits, axis and child range. Its repeated split-kind
check cannot acquire a new MissingNode error in this interval.

The enum/state/geometry fields involved have no user destructor or reference
into the continuation stack. The original push/pop moves those owned values;
it performs no Clone, I/O or observable drop callback.

Each deleted push restores the height of the frame just popped:
Enter for the first roundtrip, ContinueSplit for the pending roundtrip.
Vec::pop has not shrunk capacity, so those particular pushes cannot grow the
buffer. This is not an allocator-saving hypothesis. The remaining suspension
pushes and child Enter pushes retain their original values and order.

Allocation exhaustion and machine-code effects are not measured here; the
claim is that no result/typed-error event, reader callback or publication is
removed from these source intervals.

## Raw sharing, depth and complete output

A raw completed subtree may be entered again with new bounds. The fused control
flow schedules the same sequence of actual Enter events, including revisits;
therefore node/split last-write behavior is unchanged. Distinct parent-edge
results remain in their original ranges. The pending extent is still read from
the parent output, not derived from a shared child's final rectangle.

Cycle rejection and central membership stay in the original checked/raw
paths. Active cycles are not made acceptable by fusing dispatch. The release
first-visit prefix guard still runs once for every Enter, including allowed
older-row revisits.

The helper only pushes a child Enter and returns to the outer loop. It does
not recursively enter the child or call itself. Call depth remains bounded;
workspace depth remains represented by the same dynamic Vec. The existing
genuine 10k witness still exercises the necessary dynamic stack behavior.

Every preparation, solver call, node/child/gap write and completed owned output
is retained. Failures still discard private partial output. No old returned
output or Clone is mutated.

## Source-level event count, not machine cost

For one successful prepared split with k>=1 children, excluding descendant
events:

| Source event | Original | Candidate |
| --- | ---: | ---: |
| ContinueSplit push/pop dispatch pairs | 1+2k | k |
| Calls to advance_split_projection | 1+2k | 1+k |
| Child Enter pushes | k | k |

Thus k+1 immediate continuation roundtrips and k helper calls disappear at
source level. For raw repeated visits, apply the count to each preparation.
No executed instruction count, latency ratio or whole-operation saving follows
from these identities. A compiler may already fold some old work; a new call
site or larger live range can also regress generated code.
