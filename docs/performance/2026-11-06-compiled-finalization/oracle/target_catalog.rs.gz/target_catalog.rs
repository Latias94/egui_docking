//! One sorted row inventory for duplicate checks, target joins, and final order.

use std::sync::Arc;

use crate::drop_target::{DropTargetId, DropTargetKind, DropTargetRecord};

pub(super) struct DropTargetCatalog<'a> {
    targets: &'a [Arc<DropTargetRecord>],
    entries: Vec<(DropTargetId, usize)>,
}

pub(super) struct DropTargetOrder(Vec<usize>);

// Mark the already joined catalog rows instead of sorting a second inventory
// of large identities. Repeated expected identities are naturally idempotent.
pub(super) struct MagneticTargetCoverage<'catalog, 'targets> {
    catalog: &'catalog DropTargetCatalog<'targets>,
    expected: Vec<bool>,
}

impl<'a> DropTargetCatalog<'a> {
    pub(super) fn new(
        targets: &'a [Arc<DropTargetRecord>],
        background: Option<&DropTargetRecord>,
    ) -> Result<Self, DropTargetId> {
        let mut entries = targets
            .iter()
            .enumerate()
            .map(|(row, target)| (target.id(), row))
            .collect::<Vec<_>>();
        entries.sort_unstable_by(|left, right| left.0.cmp(&right.0));
        let duplicate = entries.windows(2).find_map(|pair| {
            let first = pair[0].0;
            (first == pair[1].0).then_some(first)
        });
        let background_duplicate = background.and_then(|background| {
            let id = background.id();
            entries
                .binary_search_by(|(key, _)| key.cmp(&id))
                .ok()
                .map(|_| id)
        });
        // The old combined catalog reported the smallest duplicate, including
        // collisions with the separate rootless-background record.
        if let Some(id) = duplicate.into_iter().chain(background_duplicate).min() {
            return Err(id);
        }
        Ok(Self { targets, entries })
    }

    #[cfg(test)]
    fn get(&self, id: &DropTargetId) -> Option<&'a Arc<DropTargetRecord>> {
        self.entry_index(id)
            .map(|index| &self.targets[self.entries[index].1])
    }

    fn entry_index(&self, id: &DropTargetId) -> Option<usize> {
        self.entries.binary_search_by(|(key, _)| key.cmp(id)).ok()
    }

    #[cfg(test)]
    fn keys(&self) -> impl ExactSizeIterator<Item = DropTargetId> + '_ {
        self.entries.iter().map(|(id, _)| *id)
    }

    pub(super) fn into_order(self) -> DropTargetOrder {
        DropTargetOrder(self.entries.into_iter().map(|(_, row)| row).collect())
    }
}

impl<'catalog, 'targets> MagneticTargetCoverage<'catalog, 'targets> {
    pub(super) fn new(catalog: &'catalog DropTargetCatalog<'targets>) -> Self {
        Self {
            catalog,
            expected: vec![false; catalog.entries.len()],
        }
    }

    pub(super) fn get(&mut self, id: &DropTargetId) -> Option<&'targets Arc<DropTargetRecord>> {
        let index = self.catalog.entry_index(id)?;
        self.expected[index] = true;
        Some(&self.catalog.targets[self.catalog.entries[index].1])
    }

    pub(super) fn is_complete(self) -> bool {
        self.catalog
            .entries
            .iter()
            .zip(self.expected)
            .all(|((id, _), expected)| {
                expected
                    == matches!(
                        id.kind(),
                        DropTargetKind::Center
                            | DropTargetKind::InnerEdge
                            | DropTargetKind::OuterEdge
                    )
            })
    }
}

impl DropTargetOrder {
    pub(super) fn apply(mut self, targets: &mut [Arc<DropTargetRecord>]) {
        debug_assert_eq!(targets.len(), self.0.len());
        // Until this final permutation, validators observe the original input
        // order and guide targets keep the exact original catalog Arc owners.
        for start in 0..self.0.len() {
            let mut current = start;
            while self.0[current] != start {
                let source = self.0[current];
                targets.swap(current, source);
                self.0[current] = current;
                current = source;
            }
            self.0[current] = current;
        }
    }
}

