"""Sampling-only layout diagnosis; never a complete-operation score."""
import datetime, hashlib, json, os, subprocess
from pathlib import Path
root=Path('/Users/frankorz/codes/rust/egui_docking')
out=Path(__file__).resolve().parent
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
files=sorted((root/'crates/dockspace/src').rglob('*.rs'))+[root/'Cargo.toml',root/'Cargo.lock',root/'crates/dockspace/Cargo.toml']
hashes=lambda:{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
record={'started_utc':now(),'source_binding':json.loads((out/'source-binding.json').read_text()),'sources':hashes(),'runs':[]}
command=['cargo','build','--manifest-path',str(out/'Cargo.toml'),'--profile','production','--offline','--target-dir',str(root/'target')]
env=dict(os.environ,CARGO_BUILD_JOBS='1');env.pop('DOCKSPACE_BENCH_NO_WORK_COUNTERS',None)
record['build_command']=command
with (out/'build.log').open('w') as log:
 result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record['build_returncode']=result.returncode
(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
assert result.returncode==0,(out/'build.log').read_text()
exe=root/'target/production/dockspace-layout-hotspot'
record['binary_sha256']=hashlib.sha256(exe.read_bytes()).hexdigest()
for views in [1,4]:
 command=[str(exe),str(views),'4000000']
 entry={'views':views,'command':command,'started_utc':now()}
 with (out/f'views-{views}.stdout').open('w') as stdout,(out/f'views-{views}.stderr').open('w') as stderr:
  process=subprocess.Popen(command,cwd=root,stdout=stdout,stderr=stderr)
  sample=['sample',str(process.pid),'4','1','-file',str(out/f'views-{views}.sample.txt')]
  entry['sample_command']=sample
  try:
   result=subprocess.run(sample,capture_output=True,text=True,timeout=15)
   entry['sample_returncode']=result.returncode
   (out/f'views-{views}.sample.log').write_text(result.stdout+result.stderr)
   entry['workload_returncode']=process.wait(timeout=45)
  finally:
   if process.poll() is None:
    process.terminate();process.wait(timeout=5)
 entry['finished_utc']=now();record['runs'].append(entry)
 (out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
 assert entry['sample_returncode']==entry['workload_returncode']==0,entry
record.update(sources_unchanged=hashes()==record['sources'],finished_utc=now())
assert record['sources_unchanged']
(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
assert json.loads((out/'receipt.json').read_text())==record
print('Sampling-only workload completed; no complete-operation metric',flush=True)
