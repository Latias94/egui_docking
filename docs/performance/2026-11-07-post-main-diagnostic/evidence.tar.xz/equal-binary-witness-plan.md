# Equal-binary witness plan

Recommend one focused semantic test in `layout/topology_tests.rs`, reusing the archived boundary test's frozen-reference comparison rather than restoring its entire Cartesian product. A compact set of 31 direct solver invocations covers the proposed equal-binary branch, its arithmetic boundaries, correction behavior, fallback guards and validation precedence. Retain the existing property and topology tests unchanged. This is a source-only plan; no code was changed and no tests were run.

**What is reusable.** Current `crates/dockspace/src/layout/topology_tests.rs` is byte-identical to `validated-weight-total-source/actual-base/.../topology_tests.rs`, SHA-256 `67671850120413fbaec896b7eea930b7eb52086ccf4864b8486ab21ed8ea1ad2`. The archived candidate test file has SHA-256 `859bce05e75e7733f34db07744b5d064dbc89256b7e300350cebcc9a79be459a`; its only test-file change is the 70-line `binary_axis_scalar_boundaries_match_frozen_solver` insertion at lines 7–75. It runs 11 extents × 11 weight pairs × 6 constraint pairs × 4 central choices = 2,904 cases.

Reuse its calls to `reference::solve_axis` and `solve_axis`, successful-size `to_bits()` comparison, and bitwise comparison of both outcome scalars. The independent reference file remains SHA-256 `4b6ff84c9bed4b65a202e1c771b5f176b161bbb27b99dba25e4875c7b08c07c6`. Do not recover either rejected candidate's runtime changes or weight-total ABI.

The old matrix already supplies equal smallest-subnormal and maximum-half weights, zero weights, invalid weights, both central positions, infeasible constraints and aggregate overflow. Its gaps for this hypothesis are ordinary equal normal weights, the normal/subnormal boundary, the immediate overflowing equal-weight boundary, length mismatch, deterministic n-ary fallback, and a feasible desired-stage case at maximum extent. Much of its cross-product returns before desired generation; the total case count alone is not branch evidence.

**Fixed values and notation.** Use standard constants and `f64::from_bits`, already used by the archived test:

- `T = f64::from_bits(1)`, smallest positive subnormal.
- `S = f64::from_bits(f64::MIN_POSITIVE.to_bits() - 1)`, largest subnormal.
- `N = f64::MIN_POSITIVE`.
- `H = f64::MAX / 2.0`, largest weight whose doubling remains finite.
- `U = f64::from_bits(H.to_bits() + 1)`, the next weight, whose doubling overflows.
- `C = [(0, 1), (0, 1)]`, constructed through `AxisConstraint::new`.

These are input fixtures, not a floating-point emulator or another solver.

**Ten successful arithmetic-boundary calls.**

| Calls | Extent | Weights | Constraints | Purpose |
| --- | --- | --- | --- | --- |
| 5 | `1` | `[w, w]` for `w` in `T, S, N, 0.5, H` | `C` | Positive subnormal through maximum-finite-total equal inputs; includes the actual normalized binary case. |
| 2 | `-0.0`, `+0.0` | `[0.5, 0.5]` | `[(-0.0, 1), (-0.0, 1)]` | Keep zero signs observable in sizes; ordinary `PartialEq` is insufficient. |
| 2 | `T`, `3*T` | `[0.5, 0.5]` | `C` | Half-underflow and subnormal rounding before the unchanged correction tail. |
| 1 | `f64::MAX` | `[0.5, 0.5]` | `[(0, H), (0, H)]` | Feasible upper extent with finite maximum sum, so desired generation is actually reached. |

For the five weight-scale cases, minimum sum is zero and maximum sum is two, so extent one reaches desired generation. In the final case maximum sum equals `MAX`; using two `MAX` bounds instead would cause `"maximum"` overflow and would fail to witness this branch.

**Four constraint/correction calls.** Use weights `[0.5, 0.5]`, no central child:

| Extent | Constraints | Behavior that must match the reference |
| --- | --- | --- |
| `8` | `[(0, 2), (0, 8)]` | Maximum clamp followed by growth of the other child. |
| `8` | `[(6, 8), (0, 8)]` | Minimum clamp followed by shrinkage of the other child. |
| `1` | `[(2, 3), (2, 3)]` | Minimum-infeasible early outcome. |
| `8` | `[(0, 1), (0, 1)]` | Maximum-infeasible early outcome. |

The first two prevent an optimization from returning immediately after producing equal desired values. Expected results come from the frozen solver, not from reimplementing clamp or redistribution in the test.

**Four deterministic fallback calls.**

| Calls | Inputs | Reason |
| --- | --- | --- |
| 1 | Extent `1`; weights `[1, f64::from_bits(1.0_f64.to_bits() + 1)]`; `C`; no central | Adjacent unequal weights must not enter an approximate-equality guard. |
| 2 | Extent `8`; weights `[0.25, 0.25]`; both bounds `(0, 8)`; central `Some(0)` and `Some(1)` | Equal weights still have materially different central allocation, in both ordered positions. |
| 1 | Extent `9`; weights `[1, 1, 1]`; bounds `[(0, 1), (0, 9), (0, 9)]`; no central | Equal n-ary input must retain the generic path. The asymmetric cap helps expose an overbroad “all weights equal” half-allocation shortcut. |

The existing `caller_owned_axis_matches_frozen_solver` property test (`topology_tests.rs:54–87`) already varies counts from zero through fifteen, nonnegative weights, constraints and valid central positions, with bitwise successful outputs. It remains the broad fallback oracle; no second random generator is needed.

**Thirteen invalid-input/priority calls.** Default extent is one and bounds are `C`, except where specified. Match the frozen error and also name the expected variant/index or quantity for these adversarial rows.

| Inputs/competing failure | Required first error |
| --- | --- |
| NaN extent; weights `[-1, NaN]`; one constraint; central `Some(2)` | `NonFiniteExtent` |
| Extent `-1`; same other faults | `NegativeExtent` |
| Finite extent; weights `[-1, NaN]`; one constraint; central `Some(2)` | `LengthMismatch { weights: 2, constraints: 1 }` |
| Weights `[NaN, -1]`; central `Some(2)` | `CentralIndexOutOfBounds { index: 2, child_count: 2 }` |
| Weights `[-1, NaN]`; no central | `NegativeWeight { index: 0, .. }`, before the later NaN |
| Weights `[NaN, -1]`; no central | `NonFiniteWeight { index: 0, .. }` |
| Equal weights `[-1, -1]` | `NegativeWeight { index: 0, .. }` |
| Equal weights `[INFINITY, INFINITY]` | `NonFiniteWeight { index: 0, .. }` |
| Weights `[+0.0, -0.0]`; both bounds `(0, MAX)` | `ZeroWeightTotal`, before maximum aggregate overflow |
| Weights `[U, U]`; both bounds `(0, MAX)` | `NonFiniteAggregate { quantity: "weight" }`, before maximum overflow |
| Weights `[U, U]`; central `Some(0)`; ordinary `C` | `"weight"` overflow still wins although central allocation ignores one weight |
| Weights `[0.5, 0.5]`; both bounds `(MAX, MAX)` | `"minimum"` aggregate overflow before `"maximum"` |
| Weights `[0.5, 0.5]`; both bounds `(2, MAX)`; extent one | `"maximum"` aggregate overflow before returning the already-infeasible minima |

All these bounds are legal constructor inputs. No raw `AxisConstraint` corruption or extra validator is needed. `[U, U]` is a more precise overflow-edge witness than another `[MAX, MAX]` weight row; the broad historical test already exercised the latter.

**Minimal integration.** Add one test function near the existing scalar property test. Reuse the successful-result match body inside a local comparison closure; ordinary fixed arrays/slices are enough for the three-child and mismatched-length inputs. Build constraints with the existing constructor. For successful results compare size count, each size's bits, and both outcome bits. For ordinary errors use typed equality. For NaN-bearing errors, avoid blanket `Result` equality: NaN is unequal to itself. Match the concrete `NonFiniteExtent` or `NonFiniteWeight` variants and compare value bits, plus the weight index. These two small match arms are sufficient; the archived Debug comparison can supply failure context but should not be the sole payload check. Do not introduce a generic error serializer or parser.

The reference must remain unchanged, and assertions must not derive expected values from `extent * 0.5`. There is no need for a branch counter, timing assertion, allocator assertion, second solver, or an exhaustive cross-product. Code review establishes which feasible rows meet the guard.

Use the existing dense traversal/property tests, minimum-only tests and ownership regressions for the production `solve_axis_into` integration: `dense_layout_matches_frozen_traversal`, `dense_projection_keeps_identity_order_and_owned_old_outputs`, `central_ancestor_depths_keep_fresh_reader_order_and_delayed_minimum_projection`, and `owned_node_rows_keep_previous_outputs_after_late_geometry_error`. They already cover the richer graph/output contract and should not be duplicated for a local numeric guard.

This plan establishes a focused semantic witness, not complete mathematical proof or a performance retention decision. Ordinary qualification and the unchanged complete-operation/work/vector protocol remain Root's responsibility.
